package com.squareup.moshi;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import okio.Buffer;
import okio.BufferedSink;
import okio.ForwardingSink;
import okio.Okio;

/* JADX INFO: loaded from: classes9.dex */
final class JsonValueWriter extends JsonWriter {

    @Nullable
    private String deferredName;
    Object[] stack = new Object[32];

    JsonValueWriter() {
        pushScope(6);
    }

    public Object root() {
        int size = this.stackSize;
        if (size > 1 || (size == 1 && this.scopes[size - 1] != 7)) {
            throw new IllegalStateException("Incomplete document");
        }
        return this.stack[0];
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter beginArray() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Array cannot be used as a map key in JSON at path " + getPath());
        }
        if (this.stackSize == this.flattenStackSize && this.scopes[this.stackSize - 1] == 1) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        checkStack();
        List<Object> list = new ArrayList<>();
        add(list);
        this.stack[this.stackSize] = list;
        this.pathIndices[this.stackSize] = 0;
        pushScope(1);
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter endArray() throws IOException {
        if (peekScope() != 1) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.stackSize == (~this.flattenStackSize)) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        this.stackSize--;
        this.stack[this.stackSize] = null;
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter beginObject() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Object cannot be used as a map key in JSON at path " + getPath());
        }
        if (this.stackSize == this.flattenStackSize && this.scopes[this.stackSize - 1] == 3) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        checkStack();
        Map<String, Object> map = new LinkedHashTreeMap<>();
        add(map);
        this.stack[this.stackSize] = map;
        pushScope(3);
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter endObject() throws IOException {
        if (peekScope() != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.deferredName != null) {
            throw new IllegalStateException("Dangling name: " + this.deferredName);
        }
        if (this.stackSize == (~this.flattenStackSize)) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        this.promoteValueToName = false;
        this.stackSize--;
        this.stack[this.stackSize] = null;
        this.pathNames[this.stackSize] = null;
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter name(String name) throws IOException {
        if (name == null) {
            throw new NullPointerException("name == null");
        }
        if (this.stackSize == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        if (peekScope() != 3 || this.deferredName != null || this.promoteValueToName) {
            throw new IllegalStateException("Nesting problem.");
        }
        this.deferredName = name;
        this.pathNames[this.stackSize - 1] = name;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(@Nullable String value) throws IOException {
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(value);
        }
        add(value);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter nullValue() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("null cannot be used as a map key in JSON at path " + getPath());
        }
        add(null);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(boolean value) throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Boolean cannot be used as a map key in JSON at path " + getPath());
        }
        add(Boolean.valueOf(value));
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(@Nullable Boolean value) throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Boolean cannot be used as a map key in JSON at path " + getPath());
        }
        add(value);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(double value) throws IOException {
        if (!this.lenient && (Double.isNaN(value) || value == Double.NEGATIVE_INFINITY || value == Double.POSITIVE_INFINITY)) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
        }
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(Double.toString(value));
        }
        add(Double.valueOf(value));
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(long value) throws IOException {
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(Long.toString(value));
        }
        add(Long.valueOf(value));
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(@Nullable Number value) throws IOException {
        if ((value instanceof Byte) || (value instanceof Short) || (value instanceof Integer) || (value instanceof Long)) {
            return value(value.longValue());
        }
        if ((value instanceof Float) || (value instanceof Double)) {
            return value(value.doubleValue());
        }
        if (value == null) {
            return nullValue();
        }
        BigDecimal bigDecimalValue = value instanceof BigDecimal ? (BigDecimal) value : new BigDecimal(value.toString());
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(bigDecimalValue.toString());
        }
        add(bigDecimalValue);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public BufferedSink valueSink() {
        if (this.promoteValueToName) {
            throw new IllegalStateException("BufferedSink cannot be used as a map key in JSON at path " + getPath());
        }
        if (peekScope() == 9) {
            throw new IllegalStateException("Sink from valueSink() was not closed");
        }
        pushScope(9);
        final Buffer buffer = new Buffer();
        return Okio.buffer(new ForwardingSink(buffer) { // from class: com.squareup.moshi.JsonValueWriter.1
            @Override // okio.ForwardingSink, okio.Sink, java.io.Closeable, java.lang.AutoCloseable
            public void close() throws IOException {
                if (JsonValueWriter.this.peekScope() != 9 || JsonValueWriter.this.stack[JsonValueWriter.this.stackSize] != null) {
                    throw new AssertionError();
                }
                JsonValueWriter.this.stackSize--;
                Object value = JsonReader.of(buffer).readJsonValue();
                boolean serializeNulls = JsonValueWriter.this.serializeNulls;
                JsonValueWriter.this.serializeNulls = true;
                try {
                    JsonValueWriter.this.add(value);
                    JsonValueWriter.this.serializeNulls = serializeNulls;
                    int[] iArr = JsonValueWriter.this.pathIndices;
                    int i = JsonValueWriter.this.stackSize - 1;
                    iArr[i] = iArr[i] + 1;
                } catch (Throwable th) {
                    JsonValueWriter.this.serializeNulls = serializeNulls;
                    throw th;
                }
            }
        });
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        int size = this.stackSize;
        if (size > 1 || (size == 1 && this.scopes[size - 1] != 7)) {
            throw new IOException("Incomplete document");
        }
        this.stackSize = 0;
    }

    @Override // java.io.Flushable
    public void flush() throws IOException {
        if (this.stackSize == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public JsonValueWriter add(@Nullable Object newTop) {
        int scope = peekScope();
        if (this.stackSize == 1) {
            if (scope != 6) {
                throw new IllegalStateException("JSON must have only one top-level value.");
            }
            this.scopes[this.stackSize - 1] = 7;
            this.stack[this.stackSize - 1] = newTop;
        } else if (scope == 3 && this.deferredName != null) {
            if (newTop != null || this.serializeNulls) {
                Map<String, Object> map = (Map) this.stack[this.stackSize - 1];
                Object replaced = map.put(this.deferredName, newTop);
                if (replaced != null) {
                    throw new IllegalArgumentException("Map key '" + this.deferredName + "' has multiple values at path " + getPath() + ": " + replaced + " and " + newTop);
                }
            }
            this.deferredName = null;
        } else if (scope == 1) {
            List<Object> list = (List) this.stack[this.stackSize - 1];
            list.add(newTop);
        } else {
            if (scope == 9) {
                throw new IllegalStateException("Sink from valueSink() was not closed");
            }
            throw new IllegalStateException("Nesting problem.");
        }
        return this;
    }
}
