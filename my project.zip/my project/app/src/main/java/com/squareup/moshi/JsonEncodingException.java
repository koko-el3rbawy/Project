package com.squareup.moshi;

import java.io.IOException;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
public final class JsonEncodingException extends IOException {
    public JsonEncodingException(@Nullable String message) {
        super(message);
    }
}
