package com.squareup.moshi;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.JsonReader;
import com.squareup.moshi.internal.Util;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
final class ClassJsonAdapter<T> extends JsonAdapter<T> {
    public static final JsonAdapter.Factory FACTORY = new JsonAdapter.Factory() { // from class: com.squareup.moshi.ClassJsonAdapter.1
        @Override // com.squareup.moshi.JsonAdapter.Factory
        @Nullable
        public JsonAdapter<?> create(Type type, Set<? extends Annotation> set, Moshi moshi) {
            if (!(type instanceof Class) && !(type instanceof ParameterizedType)) {
                return null;
            }
            Class<?> rawType = Types.getRawType(type);
            if (rawType.isInterface() || rawType.isEnum() || !set.isEmpty()) {
                return null;
            }
            if (Util.isPlatformType(rawType)) {
                throwIfIsCollectionClass(type, List.class);
                throwIfIsCollectionClass(type, Set.class);
                throwIfIsCollectionClass(type, Map.class);
                throwIfIsCollectionClass(type, Collection.class);
                String str = "Platform " + rawType;
                if (type instanceof ParameterizedType) {
                    str = str + " in " + type;
                }
                throw new IllegalArgumentException(str + " requires explicit JsonAdapter to be registered");
            }
            if (rawType.isAnonymousClass()) {
                throw new IllegalArgumentException("Cannot serialize anonymous class " + rawType.getName());
            }
            if (rawType.isLocalClass()) {
                throw new IllegalArgumentException("Cannot serialize local class " + rawType.getName());
            }
            if (rawType.getEnclosingClass() != null && !Modifier.isStatic(rawType.getModifiers())) {
                throw new IllegalArgumentException("Cannot serialize non-static nested class " + rawType.getName());
            }
            if (Modifier.isAbstract(rawType.getModifiers())) {
                throw new IllegalArgumentException("Cannot serialize abstract class " + rawType.getName());
            }
            if (Util.isKotlin(rawType)) {
                throw new IllegalArgumentException("Cannot serialize Kotlin type " + rawType.getName() + ". Reflective serialization of Kotlin classes without using kotlin-reflect has undefined and unexpected behavior. Please use KotlinJsonAdapterFactory from the moshi-kotlin artifact or use code gen from the moshi-kotlin-codegen artifact.");
            }
            ClassFactory classFactory = ClassFactory.get(rawType);
            TreeMap treeMap = new TreeMap();
            for (Type genericSuperclass = type; genericSuperclass != Object.class; genericSuperclass = Types.getGenericSuperclass(genericSuperclass)) {
                createFieldBindings(moshi, genericSuperclass, treeMap);
            }
            return new ClassJsonAdapter(classFactory, treeMap).nullSafe();
        }

        private void throwIfIsCollectionClass(Type type, Class<?> collectionInterface) {
            Class<?> rawClass = Types.getRawType(type);
            if (collectionInterface.isAssignableFrom(rawClass)) {
                throw new IllegalArgumentException("No JsonAdapter for " + type + ", you should probably use " + collectionInterface.getSimpleName() + " instead of " + rawClass.getSimpleName() + " (Moshi only supports the collection interfaces by default) or else register a custom JsonAdapter.");
            }
        }

        private void createFieldBindings(Moshi moshi, Type type, Map<String, FieldBinding<?>> fieldBindings) {
            Class<?> rawType;
            Class<?> rawType2 = Types.getRawType(type);
            boolean platformType = Util.isPlatformType(rawType2);
            Field[] declaredFields = rawType2.getDeclaredFields();
            int length = declaredFields.length;
            int i = 0;
            while (i < length) {
                Field field = declaredFields[i];
                if (includeField(platformType, field.getModifiers())) {
                    Json jsonAnnotation = (Json) field.getAnnotation(Json.class);
                    if (jsonAnnotation == null || !jsonAnnotation.ignore()) {
                        Type fieldType = Util.resolve(type, rawType2, field.getGenericType());
                        Set<? extends Annotation> annotations = Util.jsonAnnotations(field);
                        String fieldName = field.getName();
                        JsonAdapter<Object> adapter = moshi.adapter(fieldType, annotations, fieldName);
                        field.setAccessible(true);
                        String jsonName = Util.jsonName(fieldName, jsonAnnotation);
                        FieldBinding<?> fieldBinding = new FieldBinding<>(jsonName, field, adapter);
                        rawType = rawType2;
                        FieldBinding<?> replaced = fieldBindings.put(jsonName, fieldBinding);
                        if (replaced != null) {
                            throw new IllegalArgumentException("Conflicting fields:\n    " + replaced.field + "\n    " + fieldBinding.field);
                        }
                    } else {
                        rawType = rawType2;
                    }
                } else {
                    rawType = rawType2;
                }
                i++;
                rawType2 = rawType;
            }
        }

        private boolean includeField(boolean platformType, int modifiers) {
            if (Modifier.isStatic(modifiers) || Modifier.isTransient(modifiers)) {
                return false;
            }
            return Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers) || !platformType;
        }
    };
    private final ClassFactory<T> classFactory;
    private final FieldBinding<?>[] fieldsArray;
    private final JsonReader.Options options;

    ClassJsonAdapter(ClassFactory<T> classFactory, Map<String, FieldBinding<?>> fieldsMap) {
        this.classFactory = classFactory;
        this.fieldsArray = (FieldBinding[]) fieldsMap.values().toArray(new FieldBinding[fieldsMap.size()]);
        this.options = JsonReader.Options.of((String[]) fieldsMap.keySet().toArray(new String[fieldsMap.size()]));
    }

    @Override // com.squareup.moshi.JsonAdapter
    public T fromJson(JsonReader reader) throws IOException {
        try {
            T result = this.classFactory.newInstance();
            try {
                reader.beginObject();
                while (reader.hasNext()) {
                    int index = reader.selectName(this.options);
                    if (index == -1) {
                        reader.skipName();
                        reader.skipValue();
                    } else {
                        this.fieldsArray[index].read(reader, result);
                    }
                }
                reader.endObject();
                return result;
            } catch (IllegalAccessException e) {
                throw new AssertionError();
            }
        } catch (IllegalAccessException e2) {
            throw new AssertionError();
        } catch (InstantiationException e3) {
            throw new RuntimeException(e3);
        } catch (InvocationTargetException e4) {
            throw Util.rethrowCause(e4);
        }
    }

    @Override // com.squareup.moshi.JsonAdapter
    public void toJson(JsonWriter writer, T value) throws IOException {
        try {
            writer.beginObject();
            for (FieldBinding<?> fieldBinding : this.fieldsArray) {
                writer.name(fieldBinding.name);
                fieldBinding.write(writer, value);
            }
            writer.endObject();
        } catch (IllegalAccessException e) {
            throw new AssertionError();
        }
    }

    public String toString() {
        return "JsonAdapter(" + this.classFactory + ")";
    }

    static class FieldBinding<T> {
        final JsonAdapter<T> adapter;
        final Field field;
        final String name;

        FieldBinding(String name, Field field, JsonAdapter<T> adapter) {
            this.name = name;
            this.field = field;
            this.adapter = adapter;
        }

        void read(JsonReader reader, Object value) throws IllegalAccessException, IOException {
            T fieldValue = this.adapter.fromJson(reader);
            this.field.set(value, fieldValue);
        }

        void write(JsonWriter jsonWriter, Object obj) throws IllegalAccessException, IOException {
            this.adapter.toJson(jsonWriter, (T) this.field.get(obj));
        }
    }
}
