package com.squareup.moshi;

import com.squareup.moshi.internal.Util;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
@CheckReturnValue
public final class Types {
    private Types() {
    }

    public static String generatedJsonAdapterName(Class<?> clazz) {
        if (clazz.getAnnotation(JsonClass.class) == null) {
            throw new IllegalArgumentException("Class does not have a JsonClass annotation: " + clazz);
        }
        return generatedJsonAdapterName(clazz.getName());
    }

    public static String generatedJsonAdapterName(String className) {
        return className.replace("$", "_") + "JsonAdapter";
    }

    @Nullable
    public static Set<? extends Annotation> nextAnnotations(Set<? extends Annotation> annotations, Class<? extends Annotation> jsonQualifier) {
        if (!jsonQualifier.isAnnotationPresent(JsonQualifier.class)) {
            throw new IllegalArgumentException(jsonQualifier + " is not a JsonQualifier.");
        }
        if (annotations.isEmpty()) {
            return null;
        }
        for (Annotation annotation : annotations) {
            if (jsonQualifier.equals(annotation.annotationType())) {
                Set<? extends Annotation> delegateAnnotations = new LinkedHashSet<>(annotations);
                delegateAnnotations.remove(annotation);
                return Collections.unmodifiableSet(delegateAnnotations);
            }
        }
        return null;
    }

    public static ParameterizedType newParameterizedType(Type rawType, Type... typeArguments) {
        if (typeArguments.length == 0) {
            throw new IllegalArgumentException("Missing type arguments for " + rawType);
        }
        return new Util.ParameterizedTypeImpl(null, rawType, typeArguments);
    }

    public static ParameterizedType newParameterizedTypeWithOwner(Type ownerType, Type rawType, Type... typeArguments) {
        if (typeArguments.length == 0) {
            throw new IllegalArgumentException("Missing type arguments for " + rawType);
        }
        return new Util.ParameterizedTypeImpl(ownerType, rawType, typeArguments);
    }

    public static GenericArrayType arrayOf(Type componentType) {
        return new Util.GenericArrayTypeImpl(componentType);
    }

    public static WildcardType subtypeOf(Type bound) {
        Type[] upperBounds;
        if (bound instanceof WildcardType) {
            upperBounds = ((WildcardType) bound).getUpperBounds();
        } else {
            upperBounds = new Type[]{bound};
        }
        return new Util.WildcardTypeImpl(upperBounds, Util.EMPTY_TYPE_ARRAY);
    }

    public static WildcardType supertypeOf(Type bound) {
        Type[] lowerBounds;
        if (bound instanceof WildcardType) {
            lowerBounds = ((WildcardType) bound).getLowerBounds();
        } else {
            lowerBounds = new Type[]{bound};
        }
        return new Util.WildcardTypeImpl(new Type[]{Object.class}, lowerBounds);
    }

    public static Class<?> getRawType(Type type) {
        if (type instanceof Class) {
            return (Class) type;
        }
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) type;
            Type rawType = parameterizedType.getRawType();
            return (Class) rawType;
        }
        if (type instanceof GenericArrayType) {
            Type componentType = ((GenericArrayType) type).getGenericComponentType();
            return Array.newInstance(getRawType(componentType), 0).getClass();
        }
        if (type instanceof TypeVariable) {
            return Object.class;
        }
        if (type instanceof WildcardType) {
            return getRawType(((WildcardType) type).getUpperBounds()[0]);
        }
        String className = type == null ? "null" : type.getClass().getName();
        throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + className);
    }

    public static Type collectionElementType(Type context, Class<?> contextRawType) {
        Type collectionType = getSupertype(context, contextRawType, Collection.class);
        if (collectionType instanceof WildcardType) {
            collectionType = ((WildcardType) collectionType).getUpperBounds()[0];
        }
        if (collectionType instanceof ParameterizedType) {
            return ((ParameterizedType) collectionType).getActualTypeArguments()[0];
        }
        return Object.class;
    }

    public static boolean equals(@Nullable Type a, @Nullable Type b) {
        Type[] aTypeArguments;
        Type[] bTypeArguments;
        if (a == b) {
            return true;
        }
        if (a instanceof Class) {
            if (b instanceof GenericArrayType) {
                return equals(((Class) a).getComponentType(), ((GenericArrayType) b).getGenericComponentType());
            }
            return a.equals(b);
        }
        if (a instanceof ParameterizedType) {
            if (!(b instanceof ParameterizedType)) {
                return false;
            }
            ParameterizedType pa = (ParameterizedType) a;
            ParameterizedType pb = (ParameterizedType) b;
            if (pa instanceof Util.ParameterizedTypeImpl) {
                aTypeArguments = ((Util.ParameterizedTypeImpl) pa).typeArguments;
            } else {
                aTypeArguments = pa.getActualTypeArguments();
            }
            if (pb instanceof Util.ParameterizedTypeImpl) {
                bTypeArguments = ((Util.ParameterizedTypeImpl) pb).typeArguments;
            } else {
                bTypeArguments = pb.getActualTypeArguments();
            }
            return equals(pa.getOwnerType(), pb.getOwnerType()) && pa.getRawType().equals(pb.getRawType()) && Arrays.equals(aTypeArguments, bTypeArguments);
        }
        if (a instanceof GenericArrayType) {
            if (b instanceof Class) {
                return equals(((Class) b).getComponentType(), ((GenericArrayType) a).getGenericComponentType());
            }
            if (!(b instanceof GenericArrayType)) {
                return false;
            }
            GenericArrayType ga = (GenericArrayType) a;
            GenericArrayType gb = (GenericArrayType) b;
            return equals(ga.getGenericComponentType(), gb.getGenericComponentType());
        }
        if (a instanceof WildcardType) {
            if (!(b instanceof WildcardType)) {
                return false;
            }
            WildcardType wa = (WildcardType) a;
            WildcardType wb = (WildcardType) b;
            return Arrays.equals(wa.getUpperBounds(), wb.getUpperBounds()) && Arrays.equals(wa.getLowerBounds(), wb.getLowerBounds());
        }
        if (!(a instanceof TypeVariable) || !(b instanceof TypeVariable)) {
            return false;
        }
        TypeVariable<?> va = (TypeVariable) a;
        TypeVariable<?> vb = (TypeVariable) b;
        return va.getGenericDeclaration() == vb.getGenericDeclaration() && va.getName().equals(vb.getName());
    }

    @Deprecated
    public static Set<? extends Annotation> getFieldJsonQualifierAnnotations(Class<?> clazz, String fieldName) {
        try {
            Field field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true);
            Annotation[] fieldAnnotations = field.getDeclaredAnnotations();
            Set<Annotation> annotations = new LinkedHashSet<>(fieldAnnotations.length);
            for (Annotation annotation : fieldAnnotations) {
                if (annotation.annotationType().isAnnotationPresent(JsonQualifier.class)) {
                    annotations.add(annotation);
                }
            }
            return Collections.unmodifiableSet(annotations);
        } catch (NoSuchFieldException e) {
            throw new IllegalArgumentException("Could not access field " + fieldName + " on class " + clazz.getCanonicalName(), e);
        }
    }

    static <T extends Annotation> T createJsonQualifierImplementation(final Class<T> annotationType) {
        if (!annotationType.isAnnotation()) {
            throw new IllegalArgumentException(annotationType + " must be an annotation.");
        }
        if (!annotationType.isAnnotationPresent(JsonQualifier.class)) {
            throw new IllegalArgumentException(annotationType + " must have @JsonQualifier.");
        }
        if (annotationType.getDeclaredMethods().length != 0) {
            throw new IllegalArgumentException(annotationType + " must not declare methods.");
        }
        return (T) Proxy.newProxyInstance(annotationType.getClassLoader(), new Class[]{annotationType}, new InvocationHandler() { // from class: com.squareup.moshi.Types.1
            /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
            /* JADX WARN: Removed duplicated region for block: B:17:0x0035  */
            @Override // java.lang.reflect.InvocationHandler
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public java.lang.Object invoke(java.lang.Object r4, java.lang.reflect.Method r5, java.lang.Object[] r6) throws java.lang.Throwable {
                /*
                    r3 = this;
                    java.lang.String r0 = r5.getName()
                    int r1 = r0.hashCode()
                    r2 = 0
                    switch(r1) {
                        case -1776922004: goto L2b;
                        case -1295482945: goto L21;
                        case 147696667: goto L17;
                        case 1444986633: goto Ld;
                        default: goto Lc;
                    }
                Lc:
                    goto L35
                Ld:
                    java.lang.String r1 = "annotationType"
                    boolean r1 = r0.equals(r1)
                    if (r1 == 0) goto Lc
                    r1 = r2
                    goto L36
                L17:
                    java.lang.String r1 = "hashCode"
                    boolean r1 = r0.equals(r1)
                    if (r1 == 0) goto Lc
                    r1 = 2
                    goto L36
                L21:
                    java.lang.String r1 = "equals"
                    boolean r1 = r0.equals(r1)
                    if (r1 == 0) goto Lc
                    r1 = 1
                    goto L36
                L2b:
                    java.lang.String r1 = "toString"
                    boolean r1 = r0.equals(r1)
                    if (r1 == 0) goto Lc
                    r1 = 3
                    goto L36
                L35:
                    r1 = -1
                L36:
                    switch(r1) {
                        case 0: goto L70;
                        case 1: goto L63;
                        case 2: goto L5e;
                        case 3: goto L3e;
                        default: goto L39;
                    }
                L39:
                    java.lang.Object r1 = r5.invoke(r4, r6)
                    return r1
                L3e:
                    java.lang.StringBuilder r1 = new java.lang.StringBuilder
                    r1.<init>()
                    java.lang.String r2 = "@"
                    java.lang.StringBuilder r1 = r1.append(r2)
                    java.lang.Class r2 = r1
                    java.lang.String r2 = r2.getName()
                    java.lang.StringBuilder r1 = r1.append(r2)
                    java.lang.String r2 = "()"
                    java.lang.StringBuilder r1 = r1.append(r2)
                    java.lang.String r1 = r1.toString()
                    return r1
                L5e:
                    java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
                    return r1
                L63:
                    r1 = r6[r2]
                    java.lang.Class r2 = r1
                    boolean r2 = r2.isInstance(r1)
                    java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
                    return r2
                L70:
                    java.lang.Class r1 = r1
                    return r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.squareup.moshi.Types.AnonymousClass1.invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[]):java.lang.Object");
            }
        });
    }

    static Type[] mapKeyAndValueTypes(Type context, Class<?> contextRawType) {
        if (context == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        Type mapType = getSupertype(context, contextRawType, Map.class);
        if (mapType instanceof ParameterizedType) {
            ParameterizedType mapParameterizedType = (ParameterizedType) mapType;
            return mapParameterizedType.getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    static Type getSupertype(Type context, Class<?> contextRawType, Class<?> supertype) {
        if (!supertype.isAssignableFrom(contextRawType)) {
            throw new IllegalArgumentException();
        }
        return Util.resolve(context, contextRawType, Util.getGenericSupertype(context, contextRawType, supertype));
    }

    static Type getGenericSuperclass(Type type) {
        Class<?> rawType = getRawType(type);
        return Util.resolve(type, rawType, rawType.getGenericSuperclass());
    }

    static Type arrayComponentType(Type type) {
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType) type).getGenericComponentType();
        }
        if (type instanceof Class) {
            return ((Class) type).getComponentType();
        }
        return null;
    }
}
