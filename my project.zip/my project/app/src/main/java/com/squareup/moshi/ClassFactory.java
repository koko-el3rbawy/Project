package com.squareup.moshi;

import com.squareup.moshi.internal.Util;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes9.dex */
abstract class ClassFactory<T> {
    abstract T newInstance() throws IllegalAccessException, InstantiationException, InvocationTargetException;

    ClassFactory() {
    }

    public static <T> ClassFactory<T> get(final Class<?> rawType) {
        try {
            final Constructor<?> constructor = rawType.getDeclaredConstructor(new Class[0]);
            constructor.setAccessible(true);
            return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.1
                @Override // com.squareup.moshi.ClassFactory
                public T newInstance() throws IllegalAccessException, InstantiationException, InvocationTargetException {
                    return (T) constructor.newInstance(null);
                }

                public String toString() {
                    return rawType.getName();
                }
            };
        } catch (NoSuchMethodException e) {
            try {
                Class<?> unsafeClass = Class.forName("sun.misc.Unsafe");
                Field f = unsafeClass.getDeclaredField("theUnsafe");
                f.setAccessible(true);
                final Object unsafe = f.get(null);
                final Method allocateInstance = unsafeClass.getMethod("allocateInstance", Class.class);
                return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.2
                    @Override // com.squareup.moshi.ClassFactory
                    public T newInstance() throws IllegalAccessException, InvocationTargetException {
                        return (T) allocateInstance.invoke(unsafe, rawType);
                    }

                    public String toString() {
                        return rawType.getName();
                    }
                };
            } catch (ClassNotFoundException e2) {
                try {
                    Method getConstructorId = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                    getConstructorId.setAccessible(true);
                    final int constructorId = ((Integer) getConstructorId.invoke(null, Object.class)).intValue();
                    final Method newInstance = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                    newInstance.setAccessible(true);
                    return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.3
                        @Override // com.squareup.moshi.ClassFactory
                        public T newInstance() throws IllegalAccessException, InvocationTargetException {
                            return (T) newInstance.invoke(null, rawType, Integer.valueOf(constructorId));
                        }

                        public String toString() {
                            return rawType.getName();
                        }
                    };
                } catch (IllegalAccessException e3) {
                    throw new AssertionError();
                } catch (NoSuchMethodException e4) {
                    try {
                        final Method newInstance2 = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
                        newInstance2.setAccessible(true);
                        return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.4
                            @Override // com.squareup.moshi.ClassFactory
                            public T newInstance() throws IllegalAccessException, InvocationTargetException {
                                return (T) newInstance2.invoke(null, rawType, Object.class);
                            }

                            public String toString() {
                                return rawType.getName();
                            }
                        };
                    } catch (Exception e5) {
                        throw new IllegalArgumentException("cannot construct instances of " + rawType.getName());
                    }
                } catch (InvocationTargetException e6) {
                    throw Util.rethrowCause(e6);
                }
            } catch (IllegalAccessException e7) {
                throw new AssertionError();
            } catch (NoSuchFieldException e8) {
                Method getConstructorId2 = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                getConstructorId2.setAccessible(true);
                final int constructorId2 = ((Integer) getConstructorId2.invoke(null, Object.class)).intValue();
                final Method newInstance3 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                newInstance3.setAccessible(true);
                return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.3
                    @Override // com.squareup.moshi.ClassFactory
                    public T newInstance() throws IllegalAccessException, InvocationTargetException {
                        return (T) newInstance3.invoke(null, rawType, Integer.valueOf(constructorId2));
                    }

                    public String toString() {
                        return rawType.getName();
                    }
                };
            } catch (NoSuchMethodException e9) {
                Method getConstructorId22 = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                getConstructorId22.setAccessible(true);
                final int constructorId22 = ((Integer) getConstructorId22.invoke(null, Object.class)).intValue();
                final Method newInstance32 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                newInstance32.setAccessible(true);
                return new ClassFactory<T>() { // from class: com.squareup.moshi.ClassFactory.3
                    @Override // com.squareup.moshi.ClassFactory
                    public T newInstance() throws IllegalAccessException, InvocationTargetException {
                        return (T) newInstance32.invoke(null, rawType, Integer.valueOf(constructorId22));
                    }

                    public String toString() {
                        return rawType.getName();
                    }
                };
            }
        }
    }
}
