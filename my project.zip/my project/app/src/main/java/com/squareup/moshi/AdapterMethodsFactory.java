package com.squareup.moshi;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.JsonReader;
import com.squareup.moshi.internal.Util;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
final class AdapterMethodsFactory implements JsonAdapter.Factory {
    private final List<AdapterMethod> fromAdapters;
    private final List<AdapterMethod> toAdapters;

    AdapterMethodsFactory(List<AdapterMethod> toAdapters, List<AdapterMethod> fromAdapters) {
        this.toAdapters = toAdapters;
        this.fromAdapters = fromAdapters;
    }

    @Override // com.squareup.moshi.JsonAdapter.Factory
    @Nullable
    public JsonAdapter<?> create(final Type type, final Set<? extends Annotation> annotations, final Moshi moshi) {
        final JsonAdapter<Object> delegate;
        final AdapterMethod toAdapter = get(this.toAdapters, type, annotations);
        final AdapterMethod fromAdapter = get(this.fromAdapters, type, annotations);
        if (toAdapter == null && fromAdapter == null) {
            return null;
        }
        if (toAdapter == null || fromAdapter == null) {
            try {
                JsonAdapter<Object> delegate2 = moshi.nextAdapter(this, type, annotations);
                delegate = delegate2;
            } catch (IllegalArgumentException e) {
                String missingAnnotation = toAdapter == null ? "@ToJson" : "@FromJson";
                throw new IllegalArgumentException("No " + missingAnnotation + " adapter for " + Util.typeAnnotatedWithAnnotations(type, annotations), e);
            }
        } else {
            delegate = null;
        }
        if (toAdapter != null) {
            toAdapter.bind(moshi, this);
        }
        if (fromAdapter != null) {
            fromAdapter.bind(moshi, this);
        }
        return new JsonAdapter<Object>() { // from class: com.squareup.moshi.AdapterMethodsFactory.1
            @Override // com.squareup.moshi.JsonAdapter
            public void toJson(JsonWriter writer, @Nullable Object value) throws IOException {
                if (toAdapter == null) {
                    delegate.toJson(writer, value);
                    return;
                }
                if (!toAdapter.nullable && value == null) {
                    writer.nullValue();
                    return;
                }
                try {
                    toAdapter.toJson(moshi, writer, value);
                } catch (InvocationTargetException e2) {
                    Throwable cause = e2.getCause();
                    if (!(cause instanceof IOException)) {
                        throw new JsonDataException(cause + " at " + writer.getPath(), cause);
                    }
                    throw ((IOException) cause);
                }
            }

            @Override // com.squareup.moshi.JsonAdapter
            @Nullable
            public Object fromJson(JsonReader reader) throws IOException {
                if (fromAdapter == null) {
                    return delegate.fromJson(reader);
                }
                if (!fromAdapter.nullable && reader.peek() == JsonReader.Token.NULL) {
                    reader.nextNull();
                    return null;
                }
                try {
                    return fromAdapter.fromJson(moshi, reader);
                } catch (InvocationTargetException e2) {
                    Throwable cause = e2.getCause();
                    if (cause instanceof IOException) {
                        throw ((IOException) cause);
                    }
                    throw new JsonDataException(cause + " at " + reader.getPath(), cause);
                }
            }

            public String toString() {
                return "JsonAdapter" + annotations + "(" + type + ")";
            }
        };
    }

    public static AdapterMethodsFactory get(Object adapter) {
        List<AdapterMethod> toAdapters = new ArrayList<>();
        List<AdapterMethod> fromAdapters = new ArrayList<>();
        for (Class<?> c = adapter.getClass(); c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.isAnnotationPresent(ToJson.class)) {
                    AdapterMethod toAdapter = toAdapter(adapter, m);
                    AdapterMethod conflicting = get(toAdapters, toAdapter.type, toAdapter.annotations);
                    if (conflicting != null) {
                        throw new IllegalArgumentException("Conflicting @ToJson methods:\n    " + conflicting.method + "\n    " + toAdapter.method);
                    }
                    toAdapters.add(toAdapter);
                }
                if (m.isAnnotationPresent(FromJson.class)) {
                    AdapterMethod fromAdapter = fromAdapter(adapter, m);
                    AdapterMethod conflicting2 = get(fromAdapters, fromAdapter.type, fromAdapter.annotations);
                    if (conflicting2 != null) {
                        throw new IllegalArgumentException("Conflicting @FromJson methods:\n    " + conflicting2.method + "\n    " + fromAdapter.method);
                    }
                    fromAdapters.add(fromAdapter);
                }
            }
        }
        if (toAdapters.isEmpty() && fromAdapters.isEmpty()) {
            throw new IllegalArgumentException("Expected at least one @ToJson or @FromJson method on " + adapter.getClass().getName());
        }
        return new AdapterMethodsFactory(toAdapters, fromAdapters);
    }

    static AdapterMethod toAdapter(Object adapter, Method method) {
        method.setAccessible(true);
        final Type returnType = method.getGenericReturnType();
        final Type[] parameterTypes = method.getGenericParameterTypes();
        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        if (parameterTypes.length < 2 || parameterTypes[0] != JsonWriter.class || returnType != Void.TYPE || !parametersAreJsonAdapters(2, parameterTypes)) {
            int i = 1;
            if (parameterTypes.length == i && returnType != Void.TYPE) {
                final Set<? extends Annotation> returnTypeAnnotations = Util.jsonAnnotations(method);
                final Set<? extends Annotation> qualifierAnnotations = Util.jsonAnnotations(parameterAnnotations[0]);
                boolean nullable = Util.hasNullable(parameterAnnotations[0]);
                return new AdapterMethod(parameterTypes[0], qualifierAnnotations, adapter, method, parameterTypes.length, 1, nullable) { // from class: com.squareup.moshi.AdapterMethodsFactory.3
                    private JsonAdapter<Object> delegate;

                    @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
                    public void bind(Moshi moshi, JsonAdapter.Factory factory) {
                        JsonAdapter<Object> jsonAdapterAdapter;
                        super.bind(moshi, factory);
                        if (Types.equals(parameterTypes[0], returnType) && qualifierAnnotations.equals(returnTypeAnnotations)) {
                            jsonAdapterAdapter = moshi.nextAdapter(factory, returnType, returnTypeAnnotations);
                        } else {
                            jsonAdapterAdapter = moshi.adapter(returnType, returnTypeAnnotations);
                        }
                        this.delegate = jsonAdapterAdapter;
                    }

                    @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
                    public void toJson(Moshi moshi, JsonWriter writer, @Nullable Object value) throws IOException, InvocationTargetException {
                        Object intermediate = invoke(value);
                        this.delegate.toJson(writer, intermediate);
                    }
                };
            }
            throw new IllegalArgumentException("Unexpected signature for " + method + ".\n@ToJson method signatures may have one of the following structures:\n    <any access modifier> void toJson(JsonWriter writer, T value) throws <any>;\n    <any access modifier> void toJson(JsonWriter writer, T value, JsonAdapter<any> delegate, <any more delegates>) throws <any>;\n    <any access modifier> R toJson(T value) throws <any>;\n");
        }
        return new AdapterMethod(parameterTypes[1], Util.jsonAnnotations(parameterAnnotations[1]), adapter, method, parameterTypes.length, 2, true) { // from class: com.squareup.moshi.AdapterMethodsFactory.2
            @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
            public void toJson(Moshi moshi, JsonWriter writer, @Nullable Object value) throws IOException, InvocationTargetException {
                invoke(writer, value);
            }
        };
    }

    private static boolean parametersAreJsonAdapters(int offset, Type[] parameterTypes) {
        int length = parameterTypes.length;
        for (int i = offset; i < length; i++) {
            if (!(parameterTypes[i] instanceof ParameterizedType) || ((ParameterizedType) parameterTypes[i]).getRawType() != JsonAdapter.class) {
                return false;
            }
        }
        return true;
    }

    static AdapterMethod fromAdapter(Object adapter, Method method) {
        method.setAccessible(true);
        final Type returnType = method.getGenericReturnType();
        final Set<? extends Annotation> returnTypeAnnotations = Util.jsonAnnotations(method);
        final Type[] parameterTypes = method.getGenericParameterTypes();
        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        if (parameterTypes.length < 1 || parameterTypes[0] != JsonReader.class || returnType == Void.TYPE || !parametersAreJsonAdapters(1, parameterTypes)) {
            Method method2 = method;
            if (parameterTypes.length == 1 && returnType != Void.TYPE) {
                final Set<? extends Annotation> qualifierAnnotations = Util.jsonAnnotations(parameterAnnotations[0]);
                boolean nullable = Util.hasNullable(parameterAnnotations[0]);
                return new AdapterMethod(returnType, returnTypeAnnotations, adapter, method2, parameterTypes.length, 1, nullable) { // from class: com.squareup.moshi.AdapterMethodsFactory.5
                    JsonAdapter<Object> delegate;

                    @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
                    public void bind(Moshi moshi, JsonAdapter.Factory factory) {
                        JsonAdapter<Object> jsonAdapterAdapter;
                        super.bind(moshi, factory);
                        if (Types.equals(parameterTypes[0], returnType) && qualifierAnnotations.equals(returnTypeAnnotations)) {
                            jsonAdapterAdapter = moshi.nextAdapter(factory, parameterTypes[0], qualifierAnnotations);
                        } else {
                            jsonAdapterAdapter = moshi.adapter(parameterTypes[0], qualifierAnnotations);
                        }
                        this.delegate = jsonAdapterAdapter;
                    }

                    @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
                    public Object fromJson(Moshi moshi, JsonReader reader) throws IOException, InvocationTargetException {
                        Object intermediate = this.delegate.fromJson(reader);
                        return invoke(intermediate);
                    }
                };
            }
            throw new IllegalArgumentException("Unexpected signature for " + method2 + ".\n@FromJson method signatures may have one of the following structures:\n    <any access modifier> R fromJson(JsonReader jsonReader) throws <any>;\n    <any access modifier> R fromJson(JsonReader jsonReader, JsonAdapter<any> delegate, <any more delegates>) throws <any>;\n    <any access modifier> R fromJson(T value) throws <any>;\n");
        }
        return new AdapterMethod(returnType, returnTypeAnnotations, adapter, method, parameterTypes.length, 1, true) { // from class: com.squareup.moshi.AdapterMethodsFactory.4
            @Override // com.squareup.moshi.AdapterMethodsFactory.AdapterMethod
            public Object fromJson(Moshi moshi, JsonReader reader) throws IOException, InvocationTargetException {
                return invoke(reader);
            }
        };
    }

    @Nullable
    private static AdapterMethod get(List<AdapterMethod> adapterMethods, Type type, Set<? extends Annotation> annotations) {
        int size = adapterMethods.size();
        for (int i = 0; i < size; i++) {
            AdapterMethod adapterMethod = adapterMethods.get(i);
            if (Types.equals(adapterMethod.type, type) && adapterMethod.annotations.equals(annotations)) {
                return adapterMethod;
            }
        }
        return null;
    }

    static abstract class AdapterMethod {
        final Object adapter;
        final int adaptersOffset;
        final Set<? extends Annotation> annotations;
        final JsonAdapter<?>[] jsonAdapters;
        final Method method;
        final boolean nullable;
        final Type type;

        AdapterMethod(Type type, Set<? extends Annotation> annotations, Object adapter, Method method, int parameterCount, int adaptersOffset, boolean nullable) {
            this.type = Util.canonicalize(type);
            this.annotations = annotations;
            this.adapter = adapter;
            this.method = method;
            this.adaptersOffset = adaptersOffset;
            this.jsonAdapters = new JsonAdapter[parameterCount - adaptersOffset];
            this.nullable = nullable;
        }

        public void bind(Moshi moshi, JsonAdapter.Factory factory) {
            JsonAdapter<?> jsonAdapterAdapter;
            if (this.jsonAdapters.length > 0) {
                Type[] parameterTypes = this.method.getGenericParameterTypes();
                Annotation[][] parameterAnnotations = this.method.getParameterAnnotations();
                int size = parameterTypes.length;
                for (int i = this.adaptersOffset; i < size; i++) {
                    Type type = ((ParameterizedType) parameterTypes[i]).getActualTypeArguments()[0];
                    Set<? extends Annotation> jsonAnnotations = Util.jsonAnnotations(parameterAnnotations[i]);
                    JsonAdapter<?>[] jsonAdapterArr = this.jsonAdapters;
                    int i2 = i - this.adaptersOffset;
                    if (Types.equals(this.type, type) && this.annotations.equals(jsonAnnotations)) {
                        jsonAdapterAdapter = moshi.nextAdapter(factory, type, jsonAnnotations);
                    } else {
                        jsonAdapterAdapter = moshi.adapter(type, jsonAnnotations);
                    }
                    jsonAdapterArr[i2] = jsonAdapterAdapter;
                }
            }
        }

        public void toJson(Moshi moshi, JsonWriter writer, @Nullable Object value) throws IOException, InvocationTargetException {
            throw new AssertionError();
        }

        @Nullable
        public Object fromJson(Moshi moshi, JsonReader reader) throws IOException, InvocationTargetException {
            throw new AssertionError();
        }

        @Nullable
        protected Object invoke(@Nullable Object a1) throws InvocationTargetException {
            Object[] args = new Object[this.jsonAdapters.length + 1];
            args[0] = a1;
            System.arraycopy(this.jsonAdapters, 0, args, 1, this.jsonAdapters.length);
            try {
                return this.method.invoke(this.adapter, args);
            } catch (IllegalAccessException e) {
                throw new AssertionError();
            }
        }

        protected Object invoke(@Nullable Object a1, @Nullable Object a2) throws InvocationTargetException {
            Object[] args = new Object[this.jsonAdapters.length + 2];
            args[0] = a1;
            args[1] = a2;
            System.arraycopy(this.jsonAdapters, 0, args, 2, this.jsonAdapters.length);
            try {
                return this.method.invoke(this.adapter, args);
            } catch (IllegalAccessException e) {
                throw new AssertionError();
            }
        }
    }
}
