package com.squareup.moshi.internal;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.JsonDataException;
import com.squareup.moshi.JsonReader;
import com.squareup.moshi.JsonWriter;
import java.io.IOException;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
public final class NonNullJsonAdapter<T> extends JsonAdapter<T> {
    private final JsonAdapter<T> delegate;

    public NonNullJsonAdapter(JsonAdapter<T> delegate) {
        this.delegate = delegate;
    }

    public JsonAdapter<T> delegate() {
        return this.delegate;
    }

    @Override // com.squareup.moshi.JsonAdapter
    @Nullable
    public T fromJson(JsonReader reader) throws IOException {
        if (reader.peek() == JsonReader.Token.NULL) {
            throw new JsonDataException("Unexpected null at " + reader.getPath());
        }
        return this.delegate.fromJson(reader);
    }

    @Override // com.squareup.moshi.JsonAdapter
    public void toJson(JsonWriter writer, @Nullable T value) throws IOException {
        if (value == null) {
            throw new JsonDataException("Unexpected null at " + writer.getPath());
        }
        this.delegate.toJson(writer, value);
    }

    public String toString() {
        return this.delegate + ".nonNull()";
    }
}
