package com.squareup.moshi;

import com.squareup.moshi.JsonReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import okio.Buffer;
import okio.BufferedSource;

/* JADX INFO: loaded from: classes9.dex */
final class JsonValueReader extends JsonReader {
    private static final Object JSON_READER_CLOSED = new Object();
    private Object[] stack;

    JsonValueReader(Object root) {
        this.scopes[this.stackSize] = 7;
        this.stack = new Object[32];
        Object[] objArr = this.stack;
        int i = this.stackSize;
        this.stackSize = i + 1;
        objArr[i] = root;
    }

    JsonValueReader(JsonValueReader copyFrom) {
        super(copyFrom);
        this.stack = (Object[]) copyFrom.stack.clone();
        for (int i = 0; i < this.stackSize; i++) {
            if (this.stack[i] instanceof JsonIterator) {
                this.stack[i] = ((JsonIterator) this.stack[i]).m6967clone();
            }
        }
    }

    @Override // com.squareup.moshi.JsonReader
    public void beginArray() throws IOException {
        List<?> peeked = (List) require(List.class, JsonReader.Token.BEGIN_ARRAY);
        JsonIterator iterator = new JsonIterator(JsonReader.Token.END_ARRAY, peeked.toArray(new Object[peeked.size()]), 0);
        this.stack[this.stackSize - 1] = iterator;
        this.scopes[this.stackSize - 1] = 1;
        this.pathIndices[this.stackSize - 1] = 0;
        if (iterator.hasNext()) {
            push(iterator.next());
        }
    }

    @Override // com.squareup.moshi.JsonReader
    public void endArray() throws IOException {
        JsonIterator peeked = (JsonIterator) require(JsonIterator.class, JsonReader.Token.END_ARRAY);
        if (peeked.endToken != JsonReader.Token.END_ARRAY || peeked.hasNext()) {
            throw typeMismatch(peeked, JsonReader.Token.END_ARRAY);
        }
        remove();
    }

    @Override // com.squareup.moshi.JsonReader
    public void beginObject() throws IOException {
        Map<?, ?> peeked = (Map) require(Map.class, JsonReader.Token.BEGIN_OBJECT);
        JsonIterator iterator = new JsonIterator(JsonReader.Token.END_OBJECT, peeked.entrySet().toArray(new Object[peeked.size()]), 0);
        this.stack[this.stackSize - 1] = iterator;
        this.scopes[this.stackSize - 1] = 3;
        if (iterator.hasNext()) {
            push(iterator.next());
        }
    }

    @Override // com.squareup.moshi.JsonReader
    public void endObject() throws IOException {
        JsonIterator peeked = (JsonIterator) require(JsonIterator.class, JsonReader.Token.END_OBJECT);
        if (peeked.endToken != JsonReader.Token.END_OBJECT || peeked.hasNext()) {
            throw typeMismatch(peeked, JsonReader.Token.END_OBJECT);
        }
        this.pathNames[this.stackSize - 1] = null;
        remove();
    }

    @Override // com.squareup.moshi.JsonReader
    public boolean hasNext() throws IOException {
        if (this.stackSize == 0) {
            return false;
        }
        Object peeked = this.stack[this.stackSize - 1];
        return !(peeked instanceof Iterator) || ((Iterator) peeked).hasNext();
    }

    @Override // com.squareup.moshi.JsonReader
    public JsonReader.Token peek() throws IOException {
        if (this.stackSize == 0) {
            return JsonReader.Token.END_DOCUMENT;
        }
        Object peeked = this.stack[this.stackSize - 1];
        if (peeked instanceof JsonIterator) {
            return ((JsonIterator) peeked).endToken;
        }
        if (peeked instanceof List) {
            return JsonReader.Token.BEGIN_ARRAY;
        }
        if (peeked instanceof Map) {
            return JsonReader.Token.BEGIN_OBJECT;
        }
        if (peeked instanceof Map.Entry) {
            return JsonReader.Token.NAME;
        }
        if (peeked instanceof String) {
            return JsonReader.Token.STRING;
        }
        if (peeked instanceof Boolean) {
            return JsonReader.Token.BOOLEAN;
        }
        if (peeked instanceof Number) {
            return JsonReader.Token.NUMBER;
        }
        if (peeked == null) {
            return JsonReader.Token.NULL;
        }
        if (peeked == JSON_READER_CLOSED) {
            throw new IllegalStateException("JsonReader is closed");
        }
        throw typeMismatch(peeked, "a JSON value");
    }

    @Override // com.squareup.moshi.JsonReader
    public String nextName() throws IOException {
        Map.Entry<?, ?> peeked = (Map.Entry) require(Map.Entry.class, JsonReader.Token.NAME);
        String result = stringKey(peeked);
        this.stack[this.stackSize - 1] = peeked.getValue();
        this.pathNames[this.stackSize - 2] = result;
        return result;
    }

    @Override // com.squareup.moshi.JsonReader
    public int selectName(JsonReader.Options options) throws IOException {
        Map.Entry<?, ?> peeked = (Map.Entry) require(Map.Entry.class, JsonReader.Token.NAME);
        String name = stringKey(peeked);
        int length = options.strings.length;
        for (int i = 0; i < length; i++) {
            if (options.strings[i].equals(name)) {
                this.stack[this.stackSize - 1] = peeked.getValue();
                this.pathNames[this.stackSize - 2] = name;
                return i;
            }
        }
        return -1;
    }

    @Override // com.squareup.moshi.JsonReader
    public void skipName() throws IOException {
        if (this.failOnUnknown) {
            JsonReader.Token peeked = peek();
            nextName();
            throw new JsonDataException("Cannot skip unexpected " + peeked + " at " + getPath());
        }
        Map.Entry<?, ?> peeked2 = (Map.Entry) require(Map.Entry.class, JsonReader.Token.NAME);
        this.stack[this.stackSize - 1] = peeked2.getValue();
        this.pathNames[this.stackSize - 2] = "null";
    }

    @Override // com.squareup.moshi.JsonReader
    public String nextString() throws IOException {
        Object peeked = this.stackSize != 0 ? this.stack[this.stackSize - 1] : null;
        if (peeked instanceof String) {
            remove();
            return (String) peeked;
        }
        if (peeked instanceof Number) {
            remove();
            return peeked.toString();
        }
        if (peeked == JSON_READER_CLOSED) {
            throw new IllegalStateException("JsonReader is closed");
        }
        throw typeMismatch(peeked, JsonReader.Token.STRING);
    }

    @Override // com.squareup.moshi.JsonReader
    public int selectString(JsonReader.Options options) throws IOException {
        Object peeked = this.stackSize != 0 ? this.stack[this.stackSize - 1] : null;
        if (!(peeked instanceof String)) {
            if (peeked != JSON_READER_CLOSED) {
                return -1;
            }
            throw new IllegalStateException("JsonReader is closed");
        }
        String peekedString = (String) peeked;
        int length = options.strings.length;
        for (int i = 0; i < length; i++) {
            if (options.strings[i].equals(peekedString)) {
                remove();
                return i;
            }
        }
        return -1;
    }

    @Override // com.squareup.moshi.JsonReader
    public boolean nextBoolean() throws IOException {
        Boolean peeked = (Boolean) require(Boolean.class, JsonReader.Token.BOOLEAN);
        remove();
        return peeked.booleanValue();
    }

    @Override // com.squareup.moshi.JsonReader
    @Nullable
    public <T> T nextNull() throws IOException {
        require(Void.class, JsonReader.Token.NULL);
        remove();
        return null;
    }

    @Override // com.squareup.moshi.JsonReader
    public double nextDouble() throws IOException {
        double result;
        Object peeked = require(Object.class, JsonReader.Token.NUMBER);
        if (peeked instanceof Number) {
            result = ((Number) peeked).doubleValue();
        } else if (peeked instanceof String) {
            try {
                result = Double.parseDouble((String) peeked);
            } catch (NumberFormatException e) {
                throw typeMismatch(peeked, JsonReader.Token.NUMBER);
            }
        } else {
            throw typeMismatch(peeked, JsonReader.Token.NUMBER);
        }
        if (!this.lenient && (Double.isNaN(result) || Double.isInfinite(result))) {
            throw new JsonEncodingException("JSON forbids NaN and infinities: " + result + " at path " + getPath());
        }
        remove();
        return result;
    }

    @Override // com.squareup.moshi.JsonReader
    public long nextLong() throws IOException {
        long result;
        Object peeked = require(Object.class, JsonReader.Token.NUMBER);
        if (peeked instanceof Number) {
            result = ((Number) peeked).longValue();
        } else if (peeked instanceof String) {
            try {
                result = Long.parseLong((String) peeked);
            } catch (NumberFormatException e) {
                try {
                    BigDecimal asDecimal = new BigDecimal((String) peeked);
                    long result2 = asDecimal.longValueExact();
                    result = result2;
                } catch (NumberFormatException e2) {
                    throw typeMismatch(peeked, JsonReader.Token.NUMBER);
                }
            }
        } else {
            throw typeMismatch(peeked, JsonReader.Token.NUMBER);
        }
        remove();
        return result;
    }

    @Override // com.squareup.moshi.JsonReader
    public int nextInt() throws IOException {
        int result;
        Object peeked = require(Object.class, JsonReader.Token.NUMBER);
        if (peeked instanceof Number) {
            result = ((Number) peeked).intValue();
        } else if (peeked instanceof String) {
            try {
                result = Integer.parseInt((String) peeked);
            } catch (NumberFormatException e) {
                try {
                    BigDecimal asDecimal = new BigDecimal((String) peeked);
                    int result2 = asDecimal.intValueExact();
                    result = result2;
                } catch (NumberFormatException e2) {
                    throw typeMismatch(peeked, JsonReader.Token.NUMBER);
                }
            }
        } else {
            throw typeMismatch(peeked, JsonReader.Token.NUMBER);
        }
        remove();
        return result;
    }

    @Override // com.squareup.moshi.JsonReader
    public void skipValue() throws IOException {
        if (this.failOnUnknown) {
            throw new JsonDataException("Cannot skip unexpected " + peek() + " at " + getPath());
        }
        if (this.stackSize > 1) {
            this.pathNames[this.stackSize - 2] = "null";
        }
        Object skipped = this.stackSize != 0 ? this.stack[this.stackSize - 1] : null;
        if (skipped instanceof JsonIterator) {
            throw new JsonDataException("Expected a value but was " + peek() + " at path " + getPath());
        }
        if (skipped instanceof Map.Entry) {
            Map.Entry<?, ?> entry = (Map.Entry) this.stack[this.stackSize - 1];
            this.stack[this.stackSize - 1] = entry.getValue();
        } else {
            if (this.stackSize > 0) {
                remove();
                return;
            }
            throw new JsonDataException("Expected a value but was " + peek() + " at path " + getPath());
        }
    }

    @Override // com.squareup.moshi.JsonReader
    public BufferedSource nextSource() throws IOException {
        Object value = readJsonValue();
        Buffer result = new Buffer();
        JsonWriter jsonWriter = JsonWriter.of(result);
        try {
            jsonWriter.jsonValue(value);
            if (jsonWriter != null) {
                jsonWriter.close();
            }
            return result;
        } catch (Throwable th) {
            if (jsonWriter != null) {
                try {
                    jsonWriter.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    @Override // com.squareup.moshi.JsonReader
    public JsonReader peekJson() {
        return new JsonValueReader(this);
    }

    @Override // com.squareup.moshi.JsonReader
    public void promoteNameToValue() throws IOException {
        if (hasNext()) {
            String name = nextName();
            push(name);
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        Arrays.fill(this.stack, 0, this.stackSize, (Object) null);
        this.stack[0] = JSON_READER_CLOSED;
        this.scopes[0] = 8;
        this.stackSize = 1;
    }

    private void push(Object newTop) {
        if (this.stackSize == this.stack.length) {
            if (this.stackSize == 256) {
                throw new JsonDataException("Nesting too deep at " + getPath());
            }
            this.scopes = Arrays.copyOf(this.scopes, this.scopes.length * 2);
            this.pathNames = (String[]) Arrays.copyOf(this.pathNames, this.pathNames.length * 2);
            this.pathIndices = Arrays.copyOf(this.pathIndices, this.pathIndices.length * 2);
            this.stack = Arrays.copyOf(this.stack, this.stack.length * 2);
        }
        Object[] objArr = this.stack;
        int i = this.stackSize;
        this.stackSize = i + 1;
        objArr[i] = newTop;
    }

    @Nullable
    private <T> T require(Class<T> type, JsonReader.Token expected) throws IOException {
        Object peeked = this.stackSize != 0 ? this.stack[this.stackSize - 1] : null;
        if (type.isInstance(peeked)) {
            return type.cast(peeked);
        }
        if (peeked == null && expected == JsonReader.Token.NULL) {
            return null;
        }
        if (peeked == JSON_READER_CLOSED) {
            throw new IllegalStateException("JsonReader is closed");
        }
        throw typeMismatch(peeked, expected);
    }

    private String stringKey(Map.Entry<?, ?> entry) {
        Object name = entry.getKey();
        if (name instanceof String) {
            return (String) name;
        }
        throw typeMismatch(name, JsonReader.Token.NAME);
    }

    private void remove() {
        this.stackSize--;
        this.stack[this.stackSize] = null;
        this.scopes[this.stackSize] = 0;
        if (this.stackSize > 0) {
            int[] iArr = this.pathIndices;
            int i = this.stackSize - 1;
            iArr[i] = iArr[i] + 1;
            Object parent = this.stack[this.stackSize - 1];
            if ((parent instanceof Iterator) && ((Iterator) parent).hasNext()) {
                push(((Iterator) parent).next());
            }
        }
    }

    static final class JsonIterator implements Iterator<Object>, Cloneable {
        final Object[] array;
        final JsonReader.Token endToken;
        int next;

        JsonIterator(JsonReader.Token endToken, Object[] array, int next) {
            this.endToken = endToken;
            this.array = array;
            this.next = next;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.next < this.array.length;
        }

        @Override // java.util.Iterator
        public Object next() {
            Object[] objArr = this.array;
            int i = this.next;
            this.next = i + 1;
            return objArr[i];
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX INFO: renamed from: clone, reason: merged with bridge method [inline-methods] */
        public JsonIterator m6967clone() {
            return new JsonIterator(this.endToken, this.array, this.next);
        }
    }
}
