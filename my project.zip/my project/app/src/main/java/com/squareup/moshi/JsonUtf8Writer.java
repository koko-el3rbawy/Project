package com.squareup.moshi;

import java.io.IOException;
import javax.annotation.Nullable;
import okio.Buffer;
import okio.BufferedSink;
import okio.Okio;
import okio.Sink;
import okio.Timeout;

/* JADX INFO: loaded from: classes9.dex */
final class JsonUtf8Writer extends JsonWriter {
    private static final String[] REPLACEMENT_CHARS = new String[128];
    private String deferredName;
    private String separator = ":";
    private final BufferedSink sink;

    static {
        for (int i = 0; i <= 31; i++) {
            REPLACEMENT_CHARS[i] = String.format("\\u%04x", Integer.valueOf(i));
        }
        REPLACEMENT_CHARS[34] = "\\\"";
        REPLACEMENT_CHARS[92] = "\\\\";
        REPLACEMENT_CHARS[9] = "\\t";
        REPLACEMENT_CHARS[8] = "\\b";
        REPLACEMENT_CHARS[10] = "\\n";
        REPLACEMENT_CHARS[13] = "\\r";
        REPLACEMENT_CHARS[12] = "\\f";
    }

    JsonUtf8Writer(BufferedSink sink) {
        if (sink == null) {
            throw new NullPointerException("sink == null");
        }
        this.sink = sink;
        pushScope(6);
    }

    @Override // com.squareup.moshi.JsonWriter
    public void setIndent(String indent) {
        super.setIndent(indent);
        this.separator = !indent.isEmpty() ? ": " : ":";
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter beginArray() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Array cannot be used as a map key in JSON at path " + getPath());
        }
        writeDeferredName();
        return open(1, 2, '[');
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter endArray() throws IOException {
        return close(1, 2, ']');
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter beginObject() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Object cannot be used as a map key in JSON at path " + getPath());
        }
        writeDeferredName();
        return open(3, 5, '{');
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter endObject() throws IOException {
        this.promoteValueToName = false;
        return close(3, 5, '}');
    }

    private JsonWriter open(int empty, int nonempty, char openBracket) throws IOException {
        if (this.stackSize == this.flattenStackSize && (this.scopes[this.stackSize - 1] == empty || this.scopes[this.stackSize - 1] == nonempty)) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        beforeValue();
        checkStack();
        pushScope(empty);
        this.pathIndices[this.stackSize - 1] = 0;
        this.sink.writeByte(openBracket);
        return this;
    }

    private JsonWriter close(int empty, int nonempty, char closeBracket) throws IOException {
        int context = peekScope();
        if (context != nonempty && context != empty) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.deferredName != null) {
            throw new IllegalStateException("Dangling name: " + this.deferredName);
        }
        if (this.stackSize == (~this.flattenStackSize)) {
            this.flattenStackSize = ~this.flattenStackSize;
            return this;
        }
        this.stackSize--;
        this.pathNames[this.stackSize] = null;
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        if (context == nonempty) {
            newline();
        }
        this.sink.writeByte(closeBracket);
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter name(String name) throws IOException {
        if (name == null) {
            throw new NullPointerException("name == null");
        }
        if (this.stackSize == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        int context = peekScope();
        if ((context != 3 && context != 5) || this.deferredName != null || this.promoteValueToName) {
            throw new IllegalStateException("Nesting problem.");
        }
        this.deferredName = name;
        this.pathNames[this.stackSize - 1] = name;
        return this;
    }

    private void writeDeferredName() throws IOException {
        if (this.deferredName != null) {
            beforeName();
            string(this.sink, this.deferredName);
            this.deferredName = null;
        }
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(String value) throws IOException {
        if (value == null) {
            return nullValue();
        }
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(value);
        }
        writeDeferredName();
        beforeValue();
        string(this.sink, value);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter nullValue() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("null cannot be used as a map key in JSON at path " + getPath());
        }
        if (this.deferredName != null) {
            if (this.serializeNulls) {
                writeDeferredName();
            } else {
                this.deferredName = null;
                return this;
            }
        }
        beforeValue();
        this.sink.writeUtf8("null");
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(boolean value) throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("Boolean cannot be used as a map key in JSON at path " + getPath());
        }
        writeDeferredName();
        beforeValue();
        this.sink.writeUtf8(value ? "true" : "false");
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(Boolean value) throws IOException {
        if (value == null) {
            return nullValue();
        }
        return value(value.booleanValue());
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(double value) throws IOException {
        if (!this.lenient && (Double.isNaN(value) || Double.isInfinite(value))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
        }
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(Double.toString(value));
        }
        writeDeferredName();
        beforeValue();
        this.sink.writeUtf8(Double.toString(value));
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(long value) throws IOException {
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(Long.toString(value));
        }
        writeDeferredName();
        beforeValue();
        this.sink.writeUtf8(Long.toString(value));
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public JsonWriter value(@Nullable Number value) throws IOException {
        if (value == null) {
            return nullValue();
        }
        String string = value.toString();
        if (!this.lenient && (string.equals("-Infinity") || string.equals("Infinity") || string.equals("NaN"))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
        }
        if (this.promoteValueToName) {
            this.promoteValueToName = false;
            return name(string);
        }
        writeDeferredName();
        beforeValue();
        this.sink.writeUtf8(string);
        int[] iArr = this.pathIndices;
        int i = this.stackSize - 1;
        iArr[i] = iArr[i] + 1;
        return this;
    }

    @Override // com.squareup.moshi.JsonWriter
    public BufferedSink valueSink() throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("BufferedSink cannot be used as a map key in JSON at path " + getPath());
        }
        writeDeferredName();
        beforeValue();
        pushScope(9);
        return Okio.buffer(new Sink() { // from class: com.squareup.moshi.JsonUtf8Writer.1
            @Override // okio.Sink
            public void write(Buffer source, long byteCount) throws IOException {
                JsonUtf8Writer.this.sink.write(source, byteCount);
            }

            @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
                if (JsonUtf8Writer.this.peekScope() != 9) {
                    throw new AssertionError();
                }
                JsonUtf8Writer jsonUtf8Writer = JsonUtf8Writer.this;
                jsonUtf8Writer.stackSize--;
                int[] iArr = JsonUtf8Writer.this.pathIndices;
                int i = JsonUtf8Writer.this.stackSize - 1;
                iArr[i] = iArr[i] + 1;
            }

            @Override // okio.Sink, java.io.Flushable
            public void flush() throws IOException {
                JsonUtf8Writer.this.sink.flush();
            }

            @Override // okio.Sink
            /* JADX INFO: renamed from: timeout */
            public Timeout getTimeout() {
                return Timeout.NONE;
            }
        });
    }

    @Override // java.io.Flushable
    public void flush() throws IOException {
        if (this.stackSize == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.sink.flush();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.sink.close();
        int size = this.stackSize;
        if (size > 1 || (size == 1 && this.scopes[size - 1] != 7)) {
            throw new IOException("Incomplete document");
        }
        this.stackSize = 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x002b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static void string(okio.BufferedSink r7, java.lang.String r8) throws java.io.IOException {
        /*
            java.lang.String[] r0 = com.squareup.moshi.JsonUtf8Writer.REPLACEMENT_CHARS
            r1 = 34
            r7.writeByte(r1)
            r2 = 0
            int r3 = r8.length()
            r4 = 0
        Ld:
            if (r4 >= r3) goto L36
            char r5 = r8.charAt(r4)
            r6 = 128(0x80, float:1.8E-43)
            if (r5 >= r6) goto L1c
            r6 = r0[r5]
            if (r6 != 0) goto L29
            goto L33
        L1c:
            r6 = 8232(0x2028, float:1.1535E-41)
            if (r5 != r6) goto L23
            java.lang.String r6 = "\\u2028"
            goto L29
        L23:
            r6 = 8233(0x2029, float:1.1537E-41)
            if (r5 != r6) goto L33
            java.lang.String r6 = "\\u2029"
        L29:
            if (r2 >= r4) goto L2e
            r7.writeUtf8(r8, r2, r4)
        L2e:
            r7.writeUtf8(r6)
            int r2 = r4 + 1
        L33:
            int r4 = r4 + 1
            goto Ld
        L36:
            if (r2 >= r3) goto L3b
            r7.writeUtf8(r8, r2, r3)
        L3b:
            r7.writeByte(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.moshi.JsonUtf8Writer.string(okio.BufferedSink, java.lang.String):void");
    }

    private void newline() throws IOException {
        if (this.indent == null) {
            return;
        }
        this.sink.writeByte(10);
        int size = this.stackSize;
        for (int i = 1; i < size; i++) {
            this.sink.writeUtf8(this.indent);
        }
    }

    private void beforeName() throws IOException {
        int context = peekScope();
        if (context == 5) {
            this.sink.writeByte(44);
        } else if (context != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        newline();
        replaceTop(4);
    }

    private void beforeValue() throws IOException {
        int nextTop;
        switch (peekScope()) {
            case 2:
                this.sink.writeByte(44);
            case 1:
                newline();
                nextTop = 2;
                replaceTop(nextTop);
                return;
            case 3:
            case 5:
            case 8:
            default:
                throw new IllegalStateException("Nesting problem.");
            case 4:
                nextTop = 5;
                this.sink.writeUtf8(this.separator);
                replaceTop(nextTop);
                return;
            case 7:
                if (!this.lenient) {
                    throw new IllegalStateException("JSON must have only one top-level value.");
                }
            case 6:
                nextTop = 7;
                replaceTop(nextTop);
                return;
            case 9:
                throw new IllegalStateException("Sink from valueSink() was not closed");
        }
    }
}
