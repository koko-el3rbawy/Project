package com.squareup.moshi;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.internal.Util;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;

/* JADX INFO: loaded from: classes9.dex */
public final class Moshi {
    static final List<JsonAdapter.Factory> BUILT_IN_FACTORIES = new ArrayList(5);
    private final List<JsonAdapter.Factory> factories;
    private final int lastOffset;
    private final ThreadLocal<LookupChain> lookupChainThreadLocal = new ThreadLocal<>();
    private final Map<Object, JsonAdapter<?>> adapterCache = new LinkedHashMap();

    static {
        BUILT_IN_FACTORIES.add(StandardJsonAdapters.FACTORY);
        BUILT_IN_FACTORIES.add(CollectionJsonAdapter.FACTORY);
        BUILT_IN_FACTORIES.add(MapJsonAdapter.FACTORY);
        BUILT_IN_FACTORIES.add(ArrayJsonAdapter.FACTORY);
        BUILT_IN_FACTORIES.add(RecordJsonAdapter.FACTORY);
        BUILT_IN_FACTORIES.add(ClassJsonAdapter.FACTORY);
    }

    Moshi(Builder builder) {
        List<JsonAdapter.Factory> factories = new ArrayList<>(builder.factories.size() + BUILT_IN_FACTORIES.size());
        factories.addAll(builder.factories);
        factories.addAll(BUILT_IN_FACTORIES);
        this.factories = Collections.unmodifiableList(factories);
        this.lastOffset = builder.lastOffset;
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Type type) {
        return adapter(type, Util.NO_ANNOTATIONS);
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Class<T> type) {
        return adapter(type, Util.NO_ANNOTATIONS);
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Type type, Class<? extends Annotation> annotationType) {
        if (annotationType == null) {
            throw new NullPointerException("annotationType == null");
        }
        return adapter(type, Collections.singleton(Types.createJsonQualifierImplementation(annotationType)));
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Type type, Class<? extends Annotation>... annotationTypes) {
        if (annotationTypes.length == 1) {
            return adapter(type, annotationTypes[0]);
        }
        Set<Annotation> annotations = new LinkedHashSet<>(annotationTypes.length);
        for (Class<? extends Annotation> annotationType : annotationTypes) {
            annotations.add(Types.createJsonQualifierImplementation(annotationType));
        }
        return adapter(type, Collections.unmodifiableSet(annotations));
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Type type, Set<? extends Annotation> annotations) {
        return adapter(type, annotations, null);
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> adapter(Type type, Set<? extends Annotation> set, @Nullable String str) {
        if (type == null) {
            throw new NullPointerException("type == null");
        }
        if (set == null) {
            throw new NullPointerException("annotations == null");
        }
        Type typeRemoveSubtypeWildcard = Util.removeSubtypeWildcard(Util.canonicalize(type));
        Object objCacheKey = cacheKey(typeRemoveSubtypeWildcard, set);
        synchronized (this.adapterCache) {
            JsonAdapter<T> jsonAdapter = (JsonAdapter) this.adapterCache.get(objCacheKey);
            if (jsonAdapter != null) {
                return jsonAdapter;
            }
            LookupChain lookupChain = this.lookupChainThreadLocal.get();
            if (lookupChain == null) {
                lookupChain = new LookupChain();
                this.lookupChainThreadLocal.set(lookupChain);
            }
            boolean z = false;
            JsonAdapter<T> jsonAdapterPush = lookupChain.push(typeRemoveSubtypeWildcard, str, objCacheKey);
            if (jsonAdapterPush != null) {
                return jsonAdapterPush;
            }
            try {
                try {
                    int size = this.factories.size();
                    for (int i = 0; i < size; i++) {
                        JsonAdapter<T> jsonAdapter2 = (JsonAdapter<T>) this.factories.get(i).create(typeRemoveSubtypeWildcard, set, this);
                        if (jsonAdapter2 != null) {
                            lookupChain.adapterFound(jsonAdapter2);
                            boolean z2 = true;
                            return jsonAdapter2;
                        }
                    }
                    throw new IllegalArgumentException("No JsonAdapter for " + Util.typeAnnotatedWithAnnotations(typeRemoveSubtypeWildcard, set));
                } catch (IllegalArgumentException e) {
                    throw lookupChain.exceptionWithLookupStack(e);
                }
            } finally {
                lookupChain.pop(z);
            }
        }
    }

    @CheckReturnValue
    public <T> JsonAdapter<T> nextAdapter(JsonAdapter.Factory factory, Type type, Set<? extends Annotation> set) {
        if (set == null) {
            throw new NullPointerException("annotations == null");
        }
        Type typeRemoveSubtypeWildcard = Util.removeSubtypeWildcard(Util.canonicalize(type));
        int iIndexOf = this.factories.indexOf(factory);
        if (iIndexOf == -1) {
            throw new IllegalArgumentException("Unable to skip past unknown factory " + factory);
        }
        int size = this.factories.size();
        for (int i = iIndexOf + 1; i < size; i++) {
            JsonAdapter<T> jsonAdapter = (JsonAdapter<T>) this.factories.get(i).create(typeRemoveSubtypeWildcard, set, this);
            if (jsonAdapter != null) {
                return jsonAdapter;
            }
        }
        throw new IllegalArgumentException("No next JsonAdapter for " + Util.typeAnnotatedWithAnnotations(typeRemoveSubtypeWildcard, set));
    }

    @CheckReturnValue
    public Builder newBuilder() {
        Builder result = new Builder();
        int limit = this.lastOffset;
        for (int i = 0; i < limit; i++) {
            result.add(this.factories.get(i));
        }
        int limit2 = this.factories.size() - BUILT_IN_FACTORIES.size();
        for (int i2 = this.lastOffset; i2 < limit2; i2++) {
            result.addLast(this.factories.get(i2));
        }
        return result;
    }

    private Object cacheKey(Type type, Set<? extends Annotation> annotations) {
        return annotations.isEmpty() ? type : Arrays.asList(type, annotations);
    }

    public static final class Builder {
        final List<JsonAdapter.Factory> factories = new ArrayList();
        int lastOffset = 0;

        public <T> Builder add(Type type, JsonAdapter<T> jsonAdapter) {
            return add(Moshi.newAdapterFactory(type, jsonAdapter));
        }

        public <T> Builder add(Type type, Class<? extends Annotation> annotation, JsonAdapter<T> jsonAdapter) {
            return add(Moshi.newAdapterFactory(type, annotation, jsonAdapter));
        }

        public Builder add(JsonAdapter.Factory factory) {
            if (factory == null) {
                throw new IllegalArgumentException("factory == null");
            }
            List<JsonAdapter.Factory> list = this.factories;
            int i = this.lastOffset;
            this.lastOffset = i + 1;
            list.add(i, factory);
            return this;
        }

        public Builder add(Object adapter) {
            if (adapter == null) {
                throw new IllegalArgumentException("adapter == null");
            }
            return add((JsonAdapter.Factory) AdapterMethodsFactory.get(adapter));
        }

        public <T> Builder addLast(Type type, JsonAdapter<T> jsonAdapter) {
            return addLast(Moshi.newAdapterFactory(type, jsonAdapter));
        }

        public <T> Builder addLast(Type type, Class<? extends Annotation> annotation, JsonAdapter<T> jsonAdapter) {
            return addLast(Moshi.newAdapterFactory(type, annotation, jsonAdapter));
        }

        public Builder addLast(JsonAdapter.Factory factory) {
            if (factory == null) {
                throw new IllegalArgumentException("factory == null");
            }
            this.factories.add(factory);
            return this;
        }

        public Builder addLast(Object adapter) {
            if (adapter == null) {
                throw new IllegalArgumentException("adapter == null");
            }
            return addLast((JsonAdapter.Factory) AdapterMethodsFactory.get(adapter));
        }

        @CheckReturnValue
        public Moshi build() {
            return new Moshi(this);
        }
    }

    static <T> JsonAdapter.Factory newAdapterFactory(final Type type, final JsonAdapter<T> jsonAdapter) {
        if (type == null) {
            throw new IllegalArgumentException("type == null");
        }
        if (jsonAdapter == null) {
            throw new IllegalArgumentException("jsonAdapter == null");
        }
        return new JsonAdapter.Factory() { // from class: com.squareup.moshi.Moshi.1
            @Override // com.squareup.moshi.JsonAdapter.Factory
            @Nullable
            public JsonAdapter<?> create(Type targetType, Set<? extends Annotation> annotations, Moshi moshi) {
                if (annotations.isEmpty() && Util.typesMatch(type, targetType)) {
                    return jsonAdapter;
                }
                return null;
            }
        };
    }

    static <T> JsonAdapter.Factory newAdapterFactory(final Type type, final Class<? extends Annotation> annotation, final JsonAdapter<T> jsonAdapter) {
        if (type == null) {
            throw new IllegalArgumentException("type == null");
        }
        if (annotation == null) {
            throw new IllegalArgumentException("annotation == null");
        }
        if (jsonAdapter == null) {
            throw new IllegalArgumentException("jsonAdapter == null");
        }
        if (!annotation.isAnnotationPresent(JsonQualifier.class)) {
            throw new IllegalArgumentException(annotation + " does not have @JsonQualifier");
        }
        if (annotation.getDeclaredMethods().length > 0) {
            throw new IllegalArgumentException("Use JsonAdapter.Factory for annotations with elements");
        }
        return new JsonAdapter.Factory() { // from class: com.squareup.moshi.Moshi.2
            @Override // com.squareup.moshi.JsonAdapter.Factory
            @Nullable
            public JsonAdapter<?> create(Type targetType, Set<? extends Annotation> annotations, Moshi moshi) {
                if (Util.typesMatch(type, targetType) && annotations.size() == 1 && Util.isAnnotationPresent(annotations, annotation)) {
                    return jsonAdapter;
                }
                return null;
            }
        };
    }

    final class LookupChain {
        boolean exceptionAnnotated;
        final List<Lookup<?>> callLookups = new ArrayList();
        final Deque<Lookup<?>> stack = new ArrayDeque();

        LookupChain() {
        }

        <T> JsonAdapter<T> push(Type type, @Nullable String str, Object obj) {
            int size = this.callLookups.size();
            for (int i = 0; i < size; i++) {
                Lookup<?> lookup = this.callLookups.get(i);
                if (lookup.cacheKey.equals(obj)) {
                    this.stack.add(lookup);
                    return lookup.adapter != null ? (JsonAdapter<T>) lookup.adapter : lookup;
                }
            }
            Lookup<?> lookup2 = new Lookup<>(type, str, obj);
            this.callLookups.add(lookup2);
            this.stack.add(lookup2);
            return null;
        }

        <T> void adapterFound(JsonAdapter<T> result) {
            this.stack.getLast().adapter = result;
        }

        void pop(boolean success) {
            this.stack.removeLast();
            if (this.stack.isEmpty()) {
                Moshi.this.lookupChainThreadLocal.remove();
                if (success) {
                    synchronized (Moshi.this.adapterCache) {
                        int size = this.callLookups.size();
                        for (int i = 0; i < size; i++) {
                            Lookup<?> lookup = this.callLookups.get(i);
                            JsonAdapter<T> jsonAdapter = (JsonAdapter) Moshi.this.adapterCache.put(lookup.cacheKey, lookup.adapter);
                            if (jsonAdapter != 0) {
                                lookup.adapter = jsonAdapter;
                                Moshi.this.adapterCache.put(lookup.cacheKey, jsonAdapter);
                            }
                        }
                    }
                }
            }
        }

        IllegalArgumentException exceptionWithLookupStack(IllegalArgumentException e) {
            if (this.exceptionAnnotated) {
                return e;
            }
            this.exceptionAnnotated = true;
            int size = this.stack.size();
            if (size == 1 && this.stack.getFirst().fieldName == null) {
                return e;
            }
            StringBuilder errorMessageBuilder = new StringBuilder(e.getMessage());
            Iterator<Lookup<?>> i = this.stack.descendingIterator();
            while (i.hasNext()) {
                Lookup<?> lookup = i.next();
                errorMessageBuilder.append("\nfor ").append(lookup.type);
                if (lookup.fieldName != null) {
                    errorMessageBuilder.append(' ').append(lookup.fieldName);
                }
            }
            return new IllegalArgumentException(errorMessageBuilder.toString(), e);
        }
    }

    static final class Lookup<T> extends JsonAdapter<T> {

        @Nullable
        JsonAdapter<T> adapter;
        final Object cacheKey;

        @Nullable
        final String fieldName;
        final Type type;

        Lookup(Type type, @Nullable String fieldName, Object cacheKey) {
            this.type = type;
            this.fieldName = fieldName;
            this.cacheKey = cacheKey;
        }

        @Override // com.squareup.moshi.JsonAdapter
        public T fromJson(JsonReader reader) throws IOException {
            if (this.adapter == null) {
                throw new IllegalStateException("JsonAdapter isn't ready");
            }
            return this.adapter.fromJson(reader);
        }

        @Override // com.squareup.moshi.JsonAdapter
        public void toJson(JsonWriter writer, T value) throws IOException {
            if (this.adapter == null) {
                throw new IllegalStateException("JsonAdapter isn't ready");
            }
            this.adapter.toJson(writer, value);
        }

        public String toString() {
            return this.adapter != null ? this.adapter.toString() : super.toString();
        }
    }
}
