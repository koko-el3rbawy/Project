package com.squareup.moshi;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;

/* JADX INFO: loaded from: classes9.dex */
public abstract class JsonReader implements Closeable {
    boolean failOnUnknown;
    boolean lenient;
    int[] pathIndices;
    String[] pathNames;
    int[] scopes;
    int stackSize;
    private Map<Class<?>, Object> tags;

    public enum Token {
        BEGIN_ARRAY,
        END_ARRAY,
        BEGIN_OBJECT,
        END_OBJECT,
        NAME,
        STRING,
        NUMBER,
        BOOLEAN,
        NULL,
        END_DOCUMENT
    }

    public abstract void beginArray() throws IOException;

    public abstract void beginObject() throws IOException;

    public abstract void endArray() throws IOException;

    public abstract void endObject() throws IOException;

    @CheckReturnValue
    public abstract boolean hasNext() throws IOException;

    public abstract boolean nextBoolean() throws IOException;

    public abstract double nextDouble() throws IOException;

    public abstract int nextInt() throws IOException;

    public abstract long nextLong() throws IOException;

    @CheckReturnValue
    public abstract String nextName() throws IOException;

    @Nullable
    public abstract <T> T nextNull() throws IOException;

    public abstract BufferedSource nextSource() throws IOException;

    public abstract String nextString() throws IOException;

    @CheckReturnValue
    public abstract Token peek() throws IOException;

    @CheckReturnValue
    public abstract JsonReader peekJson();

    public abstract void promoteNameToValue() throws IOException;

    @CheckReturnValue
    public abstract int selectName(Options options) throws IOException;

    @CheckReturnValue
    public abstract int selectString(Options options) throws IOException;

    public abstract void skipName() throws IOException;

    public abstract void skipValue() throws IOException;

    @CheckReturnValue
    public static JsonReader of(BufferedSource source) {
        return new JsonUtf8Reader(source);
    }

    JsonReader() {
        this.scopes = new int[32];
        this.pathNames = new String[32];
        this.pathIndices = new int[32];
    }

    JsonReader(JsonReader copyFrom) {
        this.stackSize = copyFrom.stackSize;
        this.scopes = (int[]) copyFrom.scopes.clone();
        this.pathNames = (String[]) copyFrom.pathNames.clone();
        this.pathIndices = (int[]) copyFrom.pathIndices.clone();
        this.lenient = copyFrom.lenient;
        this.failOnUnknown = copyFrom.failOnUnknown;
    }

    final void pushScope(int newTop) {
        if (this.stackSize == this.scopes.length) {
            if (this.stackSize == 256) {
                throw new JsonDataException("Nesting too deep at " + getPath());
            }
            this.scopes = Arrays.copyOf(this.scopes, this.scopes.length * 2);
            this.pathNames = (String[]) Arrays.copyOf(this.pathNames, this.pathNames.length * 2);
            this.pathIndices = Arrays.copyOf(this.pathIndices, this.pathIndices.length * 2);
        }
        int[] iArr = this.scopes;
        int i = this.stackSize;
        this.stackSize = i + 1;
        iArr[i] = newTop;
    }

    final JsonEncodingException syntaxError(String message) throws JsonEncodingException {
        throw new JsonEncodingException(message + " at path " + getPath());
    }

    final JsonDataException typeMismatch(@Nullable Object value, Object expected) {
        if (value == null) {
            return new JsonDataException("Expected " + expected + " but was null at path " + getPath());
        }
        return new JsonDataException("Expected " + expected + " but was " + value + ", a " + value.getClass().getName() + ", at path " + getPath());
    }

    public final void setLenient(boolean lenient) {
        this.lenient = lenient;
    }

    @CheckReturnValue
    public final boolean isLenient() {
        return this.lenient;
    }

    public final void setFailOnUnknown(boolean failOnUnknown) {
        this.failOnUnknown = failOnUnknown;
    }

    @CheckReturnValue
    public final boolean failOnUnknown() {
        return this.failOnUnknown;
    }

    @Nullable
    public final Object readJsonValue() throws IOException {
        switch (peek()) {
            case BEGIN_ARRAY:
                List<Object> list = new ArrayList<>();
                beginArray();
                while (hasNext()) {
                    list.add(readJsonValue());
                }
                endArray();
                return list;
            case BEGIN_OBJECT:
                Map<String, Object> map = new LinkedHashTreeMap<>();
                beginObject();
                while (hasNext()) {
                    String name = nextName();
                    Object value = readJsonValue();
                    Object replaced = map.put(name, value);
                    if (replaced != null) {
                        throw new JsonDataException("Map key '" + name + "' has multiple values at path " + getPath() + ": " + replaced + " and " + value);
                    }
                }
                endObject();
                return map;
            case STRING:
                return nextString();
            case NUMBER:
                return Double.valueOf(nextDouble());
            case BOOLEAN:
                return Boolean.valueOf(nextBoolean());
            case NULL:
                return nextNull();
            default:
                throw new IllegalStateException("Expected a value but was " + peek() + " at path " + getPath());
        }
    }

    @CheckReturnValue
    public final String getPath() {
        return JsonScope.getPath(this.stackSize, this.scopes, this.pathNames, this.pathIndices);
    }

    @CheckReturnValue
    @Nullable
    public final <T> T tag(Class<T> cls) {
        if (this.tags == null) {
            return null;
        }
        return (T) this.tags.get(cls);
    }

    public final <T> void setTag(Class<T> clazz, T value) {
        if (!clazz.isAssignableFrom(value.getClass())) {
            throw new IllegalArgumentException("Tag value must be of type " + clazz.getName());
        }
        if (this.tags == null) {
            this.tags = new LinkedHashMap();
        }
        this.tags.put(clazz, value);
    }

    public static final class Options {
        final okio.Options doubleQuoteSuffix;
        final String[] strings;

        private Options(String[] strings, okio.Options doubleQuoteSuffix) {
            this.strings = strings;
            this.doubleQuoteSuffix = doubleQuoteSuffix;
        }

        public List<String> strings() {
            return Collections.unmodifiableList(Arrays.asList(this.strings));
        }

        @CheckReturnValue
        public static Options of(String... strings) {
            try {
                ByteString[] result = new ByteString[strings.length];
                Buffer buffer = new Buffer();
                for (int i = 0; i < strings.length; i++) {
                    JsonUtf8Writer.string(buffer, strings[i]);
                    buffer.readByte();
                    result[i] = buffer.readByteString();
                }
                return new Options((String[]) strings.clone(), okio.Options.of(result));
            } catch (IOException e) {
                throw new AssertionError(e);
            }
        }
    }
}
