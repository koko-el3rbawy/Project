package com.squareup.moshi;

import androidx.core.view.MotionEventCompat;
import java.io.IOException;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Source;
import okio.Timeout;

/* JADX INFO: loaded from: classes9.dex */
final class JsonValueSource implements Source {
    private final Buffer buffer;
    private boolean closed;
    private long limit;
    private final Buffer prefix;
    private final BufferedSource source;
    private int stackSize;
    private ByteString state;
    static final ByteString STATE_JSON = ByteString.encodeUtf8("[]{}\"'/#");
    static final ByteString STATE_SINGLE_QUOTED = ByteString.encodeUtf8("'\\");
    static final ByteString STATE_DOUBLE_QUOTED = ByteString.encodeUtf8("\"\\");
    static final ByteString STATE_END_OF_LINE_COMMENT = ByteString.encodeUtf8("\r\n");
    static final ByteString STATE_C_STYLE_COMMENT = ByteString.encodeUtf8("*");
    static final ByteString STATE_END_OF_JSON = ByteString.EMPTY;

    JsonValueSource(BufferedSource source) {
        this(source, new Buffer(), STATE_JSON, 0);
    }

    JsonValueSource(BufferedSource source, Buffer prefix, ByteString state, int stackSize) {
        this.limit = 0L;
        this.closed = false;
        this.source = source;
        this.buffer = source.getBuffer();
        this.prefix = prefix;
        this.state = state;
        this.stackSize = stackSize;
    }

    private void advanceLimit(long byteCount) throws IOException {
        while (this.limit < byteCount && this.state != STATE_END_OF_JSON) {
            if (this.limit == this.buffer.size()) {
                if (this.limit > 0) {
                    return;
                } else {
                    this.source.require(1L);
                }
            }
            long index = this.buffer.indexOfElement(this.state, this.limit);
            Buffer buffer = this.buffer;
            if (index == -1) {
                this.limit = buffer.size();
            } else {
                byte b = buffer.getByte(index);
                if (this.state == STATE_JSON) {
                    switch (b) {
                        case MotionEventCompat.AXIS_GENERIC_3 /* 34 */:
                            this.state = STATE_DOUBLE_QUOTED;
                            this.limit = 1 + index;
                            break;
                        case MotionEventCompat.AXIS_GENERIC_4 /* 35 */:
                            this.state = STATE_END_OF_LINE_COMMENT;
                            this.limit = 1 + index;
                            break;
                        case MotionEventCompat.AXIS_GENERIC_8 /* 39 */:
                            this.state = STATE_SINGLE_QUOTED;
                            this.limit = 1 + index;
                            break;
                        case MotionEventCompat.AXIS_GENERIC_16 /* 47 */:
                            this.source.require(index + 2);
                            byte b2 = this.buffer.getByte(index + 1);
                            if (b2 == 47) {
                                this.state = STATE_END_OF_LINE_COMMENT;
                                this.limit = 2 + index;
                            } else if (b2 == 42) {
                                this.state = STATE_C_STYLE_COMMENT;
                                this.limit = 2 + index;
                            } else {
                                this.limit = 1 + index;
                            }
                            break;
                        case 91:
                        case 123:
                            this.stackSize++;
                            this.limit = 1 + index;
                            break;
                        case 93:
                        case 125:
                            this.stackSize--;
                            if (this.stackSize == 0) {
                                this.state = STATE_END_OF_JSON;
                            }
                            this.limit = 1 + index;
                            break;
                    }
                } else if (this.state == STATE_SINGLE_QUOTED || this.state == STATE_DOUBLE_QUOTED) {
                    if (b == 92) {
                        this.source.require(index + 2);
                        this.limit = 2 + index;
                    } else {
                        this.state = this.stackSize > 0 ? STATE_JSON : STATE_END_OF_JSON;
                        this.limit = 1 + index;
                    }
                } else if (this.state == STATE_C_STYLE_COMMENT) {
                    this.source.require(index + 2);
                    if (this.buffer.getByte(index + 1) == 47) {
                        this.limit = 2 + index;
                        this.state = STATE_JSON;
                    } else {
                        this.limit = 1 + index;
                    }
                } else if (this.state == STATE_END_OF_LINE_COMMENT) {
                    this.limit = 1 + index;
                    this.state = STATE_JSON;
                } else {
                    throw new AssertionError();
                }
            }
        }
    }

    public void discard() throws IOException {
        this.closed = true;
        while (this.state != STATE_END_OF_JSON) {
            advanceLimit(8192L);
            this.source.skip(this.limit);
        }
    }

    @Override // okio.Source
    public long read(Buffer sink, long byteCount) throws IOException {
        if (this.closed) {
            throw new IllegalStateException("closed");
        }
        if (byteCount == 0) {
            return 0L;
        }
        if (!this.prefix.exhausted()) {
            long prefixResult = this.prefix.read(sink, byteCount);
            long byteCount2 = byteCount - prefixResult;
            if (this.buffer.exhausted()) {
                return prefixResult;
            }
            long suffixResult = read(sink, byteCount2);
            return suffixResult != -1 ? suffixResult + prefixResult : prefixResult;
        }
        advanceLimit(byteCount);
        if (this.limit == 0) {
            if (this.state == STATE_END_OF_JSON) {
                return -1L;
            }
            throw new AssertionError();
        }
        long result = Math.min(byteCount, this.limit);
        sink.write(this.buffer, result);
        this.limit -= result;
        return result;
    }

    @Override // okio.Source
    /* JADX INFO: renamed from: timeout */
    public Timeout getTimeout() {
        return this.source.getTimeout();
    }

    @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.closed = true;
    }
}
