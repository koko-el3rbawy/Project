package com.squareup.moshi;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import okio.BufferedSink;
import okio.BufferedSource;

/* JADX INFO: loaded from: classes9.dex */
public abstract class JsonWriter implements Closeable, Flushable {
    String indent;
    boolean lenient;
    boolean promoteValueToName;
    boolean serializeNulls;
    private Map<Class<?>, Object> tags;
    int stackSize = 0;
    int[] scopes = new int[32];
    String[] pathNames = new String[32];
    int[] pathIndices = new int[32];
    int flattenStackSize = -1;

    public abstract JsonWriter beginArray() throws IOException;

    public abstract JsonWriter beginObject() throws IOException;

    public abstract JsonWriter endArray() throws IOException;

    public abstract JsonWriter endObject() throws IOException;

    public abstract JsonWriter name(String str) throws IOException;

    public abstract JsonWriter nullValue() throws IOException;

    public abstract JsonWriter value(double d) throws IOException;

    public abstract JsonWriter value(long j) throws IOException;

    public abstract JsonWriter value(@Nullable Boolean bool) throws IOException;

    public abstract JsonWriter value(@Nullable Number number) throws IOException;

    public abstract JsonWriter value(@Nullable String str) throws IOException;

    public abstract JsonWriter value(boolean z) throws IOException;

    @CheckReturnValue
    public abstract BufferedSink valueSink() throws IOException;

    @CheckReturnValue
    public static JsonWriter of(BufferedSink sink) {
        return new JsonUtf8Writer(sink);
    }

    JsonWriter() {
    }

    final int peekScope() {
        if (this.stackSize == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        return this.scopes[this.stackSize - 1];
    }

    final boolean checkStack() {
        if (this.stackSize != this.scopes.length) {
            return false;
        }
        if (this.stackSize == 256) {
            throw new JsonDataException("Nesting too deep at " + getPath() + ": circular reference?");
        }
        this.scopes = Arrays.copyOf(this.scopes, this.scopes.length * 2);
        this.pathNames = (String[]) Arrays.copyOf(this.pathNames, this.pathNames.length * 2);
        this.pathIndices = Arrays.copyOf(this.pathIndices, this.pathIndices.length * 2);
        if (this instanceof JsonValueWriter) {
            ((JsonValueWriter) this).stack = Arrays.copyOf(((JsonValueWriter) this).stack, ((JsonValueWriter) this).stack.length * 2);
            return true;
        }
        return true;
    }

    final void pushScope(int newTop) {
        int[] iArr = this.scopes;
        int i = this.stackSize;
        this.stackSize = i + 1;
        iArr[i] = newTop;
    }

    final void replaceTop(int topOfStack) {
        this.scopes[this.stackSize - 1] = topOfStack;
    }

    public void setIndent(String indent) {
        this.indent = !indent.isEmpty() ? indent : null;
    }

    @CheckReturnValue
    public final String getIndent() {
        return this.indent != null ? this.indent : "";
    }

    public final void setLenient(boolean lenient) {
        this.lenient = lenient;
    }

    @CheckReturnValue
    public final boolean isLenient() {
        return this.lenient;
    }

    public final void setSerializeNulls(boolean serializeNulls) {
        this.serializeNulls = serializeNulls;
    }

    @CheckReturnValue
    public final boolean getSerializeNulls() {
        return this.serializeNulls;
    }

    public final JsonWriter value(BufferedSource source) throws IOException {
        if (this.promoteValueToName) {
            throw new IllegalStateException("BufferedSource cannot be used as a map key in JSON at path " + getPath());
        }
        BufferedSink sink = valueSink();
        try {
            source.readAll(sink);
            if (sink != null) {
                sink.close();
            }
            return this;
        } catch (Throwable th) {
            if (sink != null) {
                try {
                    sink.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public final JsonWriter jsonValue(@Nullable Object value) throws IOException {
        String str;
        if (value instanceof Map) {
            beginObject();
            for (Map.Entry<?, ?> entry : ((Map) value).entrySet()) {
                Object key = entry.getKey();
                if (!(key instanceof String)) {
                    if (key == null) {
                        str = "Map keys must be non-null";
                    } else {
                        str = "Map keys must be of type String: " + key.getClass().getName();
                    }
                    throw new IllegalArgumentException(str);
                }
                name((String) key);
                jsonValue(entry.getValue());
            }
            endObject();
        } else if (value instanceof List) {
            beginArray();
            for (Object element : (List) value) {
                jsonValue(element);
            }
            endArray();
        } else if (value instanceof String) {
            value((String) value);
        } else if (value instanceof Boolean) {
            value(((Boolean) value).booleanValue());
        } else if (value instanceof Double) {
            value(((Double) value).doubleValue());
        } else if (value instanceof Long) {
            value(((Long) value).longValue());
        } else if (value instanceof Number) {
            value((Number) value);
        } else if (value == null) {
            nullValue();
        } else {
            throw new IllegalArgumentException("Unsupported type: " + value.getClass().getName());
        }
        return this;
    }

    public final void promoteValueToName() throws IOException {
        int context = peekScope();
        if (context != 5 && context != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        this.promoteValueToName = true;
    }

    @CheckReturnValue
    public final int beginFlatten() {
        int context = peekScope();
        if (context != 5 && context != 3 && context != 2 && context != 1) {
            throw new IllegalStateException("Nesting problem.");
        }
        int token = this.flattenStackSize;
        this.flattenStackSize = this.stackSize;
        return token;
    }

    public final void endFlatten(int token) {
        this.flattenStackSize = token;
    }

    @CheckReturnValue
    public final String getPath() {
        return JsonScope.getPath(this.stackSize, this.scopes, this.pathNames, this.pathIndices);
    }

    @CheckReturnValue
    @Nullable
    public final <T> T tag(Class<T> cls) {
        if (this.tags == null) {
            return null;
        }
        return (T) this.tags.get(cls);
    }

    public final <T> void setTag(Class<T> clazz, T value) {
        if (!clazz.isAssignableFrom(value.getClass())) {
            throw new IllegalArgumentException("Tag value must be of type " + clazz.getName());
        }
        if (this.tags == null) {
            this.tags = new LinkedHashMap();
        }
        this.tags.put(clazz, value);
    }
}
