package com.google.accompanist.permissions;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;
import kotlin.annotation.AnnotationRetention;

/* JADX INFO: compiled from: PermissionsUtil.kt */
/* JADX INFO: loaded from: classes9.dex */
@Retention(RetentionPolicy.CLASS)
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0087\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"}, d2 = {"Lcom/google/accompanist/permissions/ExperimentalPermissionsApi;", "", "permissions_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
@kotlin.annotation.Retention(AnnotationRetention.BINARY)
public @interface ExperimentalPermissionsApi {
}
