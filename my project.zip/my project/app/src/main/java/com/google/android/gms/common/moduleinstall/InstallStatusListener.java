package com.google.android.gms.common.moduleinstall;

/* JADX INFO: compiled from: com.google.android.gms:play-services-base@@18.4.0 */
/* JADX INFO: loaded from: classes9.dex */
public interface InstallStatusListener {
    void onInstallStatusUpdated(ModuleInstallStatusUpdate moduleInstallStatusUpdate);
}
