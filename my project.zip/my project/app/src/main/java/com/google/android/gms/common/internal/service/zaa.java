package com.google.android.gms.common.internal.service;

import android.os.RemoteException;

/* JADX INFO: compiled from: com.google.android.gms:play-services-base@@18.4.0 */
/* JADX INFO: loaded from: classes9.dex */
public class zaa extends zaj {
    @Override // com.google.android.gms.common.internal.service.zak
    public void zab(int i) throws RemoteException {
    }
}
