package com.google.accompanist.permissions;

/* JADX INFO: loaded from: classes2.dex */
public final class R {
    private R() {
    }
}
