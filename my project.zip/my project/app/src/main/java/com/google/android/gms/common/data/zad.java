package com.google.android.gms.common.data;

/* JADX INFO: compiled from: com.google.android.gms:play-services-base@@18.4.0 */
/* JADX INFO: loaded from: classes9.dex */
public final class zad extends RuntimeException {
    public zad(String str) {
        super("Could not add the value to a new CursorWindow. The size of value may be larger than what a CursorWindow can handle.");
    }
}
