package com.google.android.gms.common.config;

import com.google.android.gms.common.internal.Preconditions;

/* JADX INFO: compiled from: com.google.android.gms:play-services-basement@@18.3.0 */
/* JADX INFO: loaded from: classes9.dex */
final class zzd extends GservicesValue {
    zzd(String str, Float f) {
        super(str, f);
    }

    @Override // com.google.android.gms.common.config.GservicesValue
    protected final /* bridge */ /* synthetic */ Object zza(String str) {
        Preconditions.checkNotNull(null);
        throw null;
    }
}
