package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.GoogleApi;

/* JADX INFO: compiled from: com.google.android.gms:play-services-base@@18.4.0 */
/* JADX INFO: loaded from: classes9.dex */
public final class zach {
    public final zai zaa;
    public final int zab;
    public final GoogleApi zac;

    public zach(zai zaiVar, int i, GoogleApi googleApi) {
        this.zaa = zaiVar;
        this.zab = i;
        this.zac = googleApi;
    }
}
