package com.google.android.gms.common.internal;

/* JADX INFO: compiled from: com.google.android.gms:play-services-basement@@18.3.0 */
/* JADX INFO: loaded from: classes9.dex */
public final class AccountType {
    public static final String GOOGLE = "com.google";
    public static final String[] zza = {GOOGLE, "com.google.work", "cn.google"};

    private AccountType() {
    }
}
