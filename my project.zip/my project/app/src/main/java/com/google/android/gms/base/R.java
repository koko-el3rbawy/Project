package com.google.android.gms.base;

/* JADX INFO: loaded from: classes2.dex */
public final class R {

    public static final class attr {
        public static int buttonSize = 0x7f010003;
        public static int circleCrop = 0x7f010004;
        public static int colorScheme = 0x7f010005;
        public static int imageAspectRatio = 0x7f010018;
        public static int imageAspectRatioAdjust = 0x7f010019;
        public static int scopeUris = 0x7f010028;

        private attr() {
        }
    }

    public static final class color {
        public static int common_google_signin_btn_text_dark = 0x7f030005;
        public static int common_google_signin_btn_text_dark_default = 0x7f030006;
        public static int common_google_signin_btn_text_dark_disabled = 0x7f030007;
        public static int common_google_signin_btn_text_dark_focused = 0x7f030008;
        public static int common_google_signin_btn_text_dark_pressed = 0x7f030009;
        public static int common_google_signin_btn_text_light = 0x7f03000a;
        public static int common_google_signin_btn_text_light_default = 0x7f03000b;
        public static int common_google_signin_btn_text_light_disabled = 0x7f03000c;
        public static int common_google_signin_btn_text_light_focused = 0x7f03000d;
        public static int common_google_signin_btn_text_light_pressed = 0x7f03000e;
        public static int common_google_signin_btn_tint = 0x7f03000f;

        private color() {
        }
    }

    public static final class drawable {
        public static int common_full_open_on_phone = 0x7f050001;
        public static int common_google_signin_btn_icon_dark = 0x7f050002;
        public static int common_google_signin_btn_icon_dark_focused = 0x7f050003;
        public static int common_google_signin_btn_icon_dark_normal = 0x7f050004;
        public static int common_google_signin_btn_icon_dark_normal_background = 0x7f050005;
        public static int common_google_signin_btn_icon_disabled = 0x7f050006;
        public static int common_google_signin_btn_icon_light = 0x7f050007;
        public static int common_google_signin_btn_icon_light_focused = 0x7f050008;
        public static int common_google_signin_btn_icon_light_normal = 0x7f050009;
        public static int common_google_signin_btn_icon_light_normal_background = 0x7f05000a;
        public static int common_google_signin_btn_text_dark = 0x7f05000b;
        public static int common_google_signin_btn_text_dark_focused = 0x7f05000c;
        public static int common_google_signin_btn_text_dark_normal = 0x7f05000d;
        public static int common_google_signin_btn_text_dark_normal_background = 0x7f05000e;
        public static int common_google_signin_btn_text_disabled = 0x7f05000f;
        public static int common_google_signin_btn_text_light = 0x7f050010;
        public static int common_google_signin_btn_text_light_focused = 0x7f050011;
        public static int common_google_signin_btn_text_light_normal = 0x7f050012;
        public static int common_google_signin_btn_text_light_normal_background = 0x7f050013;
        public static int googleg_disabled_color_18 = 0x7f050014;
        public static int googleg_standard_color_18 = 0x7f050015;

        private drawable() {
        }
    }

    public static final class id {
        public static int adjust_height = 0x7f060026;
        public static int adjust_width = 0x7f060027;
        public static int auto = 0x7f06002a;
        public static int dark = 0x7f06002f;
        public static int icon_only = 0x7f060038;
        public static int light = 0x7f06003d;
        public static int none = 0x7f060041;
        public static int standard = 0x7f06004a;
        public static int wide = 0x7f060063;

        private id() {
        }
    }

    public static final class string {
        public static int common_google_play_services_enable_button = 0x7f0a000b;
        public static int common_google_play_services_enable_text = 0x7f0a000c;
        public static int common_google_play_services_enable_title = 0x7f0a000d;
        public static int common_google_play_services_install_button = 0x7f0a000e;
        public static int common_google_play_services_install_text = 0x7f0a000f;
        public static int common_google_play_services_install_title = 0x7f0a0010;
        public static int common_google_play_services_notification_channel_name = 0x7f0a0011;
        public static int common_google_play_services_notification_ticker = 0x7f0a0012;
        public static int common_google_play_services_unsupported_text = 0x7f0a0014;
        public static int common_google_play_services_update_button = 0x7f0a0015;
        public static int common_google_play_services_update_text = 0x7f0a0016;
        public static int common_google_play_services_update_title = 0x7f0a0017;
        public static int common_google_play_services_updating_text = 0x7f0a0018;
        public static int common_google_play_services_wear_update_text = 0x7f0a0019;
        public static int common_open_on_phone = 0x7f0a001a;
        public static int common_signin_button_text = 0x7f0a001b;
        public static int common_signin_button_text_long = 0x7f0a001c;

        private string() {
        }
    }

    public static final class styleable {
        public static int LoadingImageView_circleCrop = 0x00000000;
        public static int LoadingImageView_imageAspectRatio = 0x00000001;
        public static int LoadingImageView_imageAspectRatioAdjust = 0x00000002;
        public static int SignInButton_buttonSize = 0x00000000;
        public static int SignInButton_colorScheme = 0x00000001;
        public static int SignInButton_scopeUris = 0x00000002;
        public static int[] LoadingImageView = {com.aistudio.supervisor.kxqpmz.R.attr.circleCrop, com.aistudio.supervisor.kxqpmz.R.attr.imageAspectRatio, com.aistudio.supervisor.kxqpmz.R.attr.imageAspectRatioAdjust};
        public static int[] SignInButton = {com.aistudio.supervisor.kxqpmz.R.attr.buttonSize, com.aistudio.supervisor.kxqpmz.R.attr.colorScheme, com.aistudio.supervisor.kxqpmz.R.attr.scopeUris};

        private styleable() {
        }
    }

    private R() {
    }
}
