package com.google.android.gms.actions;

/* JADX INFO: compiled from: com.google.android.gms:play-services-basement@@18.3.0 */
/* JADX INFO: loaded from: classes9.dex */
public class ItemListIntents {
    public static final String ACTION_ACCEPT_ITEM = "com.google.android.gms.actions.ACCEPT_ITEM";
    public static final String ACTION_APPEND_ITEM_LIST = "com.google.android.gms.actions.APPEND_ITEM_LIST";
    public static final String ACTION_CREATE_ITEM_LIST = "com.google.android.gms.actions.CREATE_ITEM_LIST";
    public static final String ACTION_DELETE_ITEM = "com.google.android.gms.actions.DELETE_ITEM";
    public static final String ACTION_DELETE_ITEM_LIST = "com.google.android.gms.actions.DELETE_ITEM_LIST";
    public static final String ACTION_REJECT_ITEM = "com.google.android.gms.actions.REJECT_ITEM";
    public static final String EXTRA_ITEM_NAME = "com.google.android.gms.actions.extra.ITEM_NAME";
    public static final String EXTRA_ITEM_NAMES = "com.google.android.gms.actions.extra.ITEM_NAMES";
    public static final String EXTRA_ITEM_QUERY = "com.google.android.gms.actions.extra.ITEM_QUERY";
    public static final String EXTRA_LIST_NAME = "com.google.android.gms.actions.extra.LIST_NAME";
    public static final String EXTRA_LIST_QUERY = "com.google.android.gms.actions.extra.LIST_QUERY";

    private ItemListIntents() {
    }
}
