package com.google.android.gms.actions;

/* JADX INFO: compiled from: com.google.android.gms:play-services-basement@@18.3.0 */
/* JADX INFO: loaded from: classes9.dex */
public class NoteIntents {
    public static final String ACTION_APPEND_NOTE = "com.google.android.gms.actions.APPEND_NOTE";
    public static final String ACTION_CREATE_NOTE = "com.google.android.gms.actions.CREATE_NOTE";
    public static final String ACTION_DELETE_NOTE = "com.google.android.gms.actions.DELETE_NOTE";
    public static final String EXTRA_NAME = "com.google.android.gms.actions.extra.NAME";
    public static final String EXTRA_NOTE_QUERY = "com.google.android.gms.actions.extra.NOTE_QUERY";
    public static final String EXTRA_TEXT = "com.google.android.gms.actions.extra.TEXT";

    private NoteIntents() {
    }
}
