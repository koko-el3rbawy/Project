package com.example.work;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerFactory;
import androidx.work.WorkerParameters;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CustomWorkerFactory.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\t\b\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\"\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016¨\u0006\f"}, d2 = {"Lcom/example/work/CustomWorkerFactory;", "Landroidx/work/WorkerFactory;", "<init>", "()V", "createWorker", "Landroidx/work/ListenableWorker;", "appContext", "Landroid/content/Context;", "workerClassName", "", "workerParameters", "Landroidx/work/WorkerParameters;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CustomWorkerFactory extends WorkerFactory {
    public static final int $stable = 8;

    @Inject
    public CustomWorkerFactory() {
    }

    @Override // androidx.work.WorkerFactory
    public ListenableWorker createWorker(Context appContext, String workerClassName, WorkerParameters workerParameters) {
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(workerClassName, "workerClassName");
        Intrinsics.checkNotNullParameter(workerParameters, "workerParameters");
        if (Intrinsics.areEqual(workerClassName, DailyReportWorker.class.getName())) {
            return new DailyReportWorker(appContext, workerParameters);
        }
        if (Intrinsics.areEqual(workerClassName, TelegramRetryWorker.class.getName())) {
            return new TelegramRetryWorker(appContext, workerParameters);
        }
        return null;
    }
}
