package com.example.data.local;

import androidx.core.app.NotificationCompat;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: LogDao.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\bg\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0014\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\t0\bH'J\u001c\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\t0\b2\u0006\u0010\u000b\u001a\u00020\fH'J\u001c\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\t2\u0006\u0010\u000b\u001a\u00020\fH§@¢\u0006\u0002\u0010\u000eJ\u0016\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u0011H§@¢\u0006\u0002\u0010\u0012J\u0016\u0010\u0013\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0015H§@¢\u0006\u0002\u0010\u0016J\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00150\tH§@¢\u0006\u0002\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0015H§@¢\u0006\u0002\u0010\u0016¨\u0006\u001aÀ\u0006\u0003"}, d2 = {"Lcom/example/data/local/LogDao;", "", "insertLog", "", "log", "Lcom/example/data/local/LogEntity;", "(Lcom/example/data/local/LogEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRecentLogs", "Lkotlinx/coroutines/flow/Flow;", "", "getLogsByType", "type", "", "getLogsByTypeOnce", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "clearOldLogs", "oldTimestamp", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertPendingMessage", NotificationCompat.CATEGORY_MESSAGE, "Lcom/example/data/local/PendingMessageEntity;", "(Lcom/example/data/local/PendingMessageEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getPendingMessages", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletePendingMessage", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface LogDao {
    Object clearOldLogs(long j, Continuation<? super Unit> continuation);

    Object deletePendingMessage(PendingMessageEntity pendingMessageEntity, Continuation<? super Unit> continuation);

    Flow<List<LogEntity>> getLogsByType(String type);

    Object getLogsByTypeOnce(String str, Continuation<? super List<LogEntity>> continuation);

    Object getPendingMessages(Continuation<? super List<PendingMessageEntity>> continuation);

    Flow<List<LogEntity>> getRecentLogs();

    Object insertLog(LogEntity logEntity, Continuation<? super Unit> continuation);

    Object insertPendingMessage(PendingMessageEntity pendingMessageEntity, Continuation<? super Unit> continuation);
}
