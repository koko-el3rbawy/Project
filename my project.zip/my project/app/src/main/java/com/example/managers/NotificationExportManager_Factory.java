package com.example.managers;

import android.content.Context;
import com.example.data.local.AppDatabase;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class NotificationExportManager_Factory implements Factory<NotificationExportManager> {
    private final Provider<AppDatabase> appDatabaseProvider;
    private final Provider<Context> contextProvider;

    public NotificationExportManager_Factory(Provider<Context> contextProvider, Provider<AppDatabase> appDatabaseProvider) {
        this.contextProvider = contextProvider;
        this.appDatabaseProvider = appDatabaseProvider;
    }

    @Override // javax.inject.Provider
    public NotificationExportManager get() {
        return newInstance(this.contextProvider.get(), this.appDatabaseProvider.get());
    }

    public static NotificationExportManager_Factory create(Provider<Context> contextProvider, Provider<AppDatabase> appDatabaseProvider) {
        return new NotificationExportManager_Factory(contextProvider, appDatabaseProvider);
    }

    public static NotificationExportManager newInstance(Context context, AppDatabase appDatabase) {
        return new NotificationExportManager(context, appDatabase);
    }
}
