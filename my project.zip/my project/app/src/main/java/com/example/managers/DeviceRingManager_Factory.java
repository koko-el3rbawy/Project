package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class DeviceRingManager_Factory implements Factory<DeviceRingManager> {
    private final Provider<Context> contextProvider;

    public DeviceRingManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public DeviceRingManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static DeviceRingManager_Factory create(Provider<Context> contextProvider) {
        return new DeviceRingManager_Factory(contextProvider);
    }

    public static DeviceRingManager newInstance(Context context) {
        return new DeviceRingManager(context);
    }
}
