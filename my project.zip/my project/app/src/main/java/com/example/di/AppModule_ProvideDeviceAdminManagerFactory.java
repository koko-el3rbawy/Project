package com.example.di;

import android.content.Context;
import com.example.utils.DeviceAdminManager;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideDeviceAdminManagerFactory implements Factory<DeviceAdminManager> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideDeviceAdminManagerFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public DeviceAdminManager get() {
        return provideDeviceAdminManager(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideDeviceAdminManagerFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideDeviceAdminManagerFactory(module, contextProvider);
    }

    public static DeviceAdminManager provideDeviceAdminManager(AppModule instance, Context context) {
        return (DeviceAdminManager) Preconditions.checkNotNullFromProvides(instance.provideDeviceAdminManager(context));
    }
}
