package com.example.managers;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.example.receivers.AdminReceiver;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: StudyModeManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007J\u0006\u0010\b\u001a\u00020\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lcom/example/managers/StudyModeManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "setStudyMode", "", "stopStudyMode", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class StudyModeManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public StudyModeManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00ae A[Catch: Exception -> 0x00d3, TryCatch #0 {Exception -> 0x00d3, blocks: (B:6:0x0025, B:7:0x004a, B:9:0x0050, B:10:0x005e, B:12:0x007f, B:14:0x0090, B:16:0x009f, B:22:0x00ae, B:23:0x00b1, B:24:0x00b8), top: B:29:0x0025 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00b1 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean setStudyMode() {
        /*
            Method dump skipped, instruction units count: 216
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.managers.StudyModeManager.setStudyMode():boolean");
    }

    public final boolean stopStudyMode() {
        Object systemService = this.context.getSystemService("device_policy");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.admin.DevicePolicyManager");
        DevicePolicyManager dpm = (DevicePolicyManager) systemService;
        ComponentName adminComponent = new ComponentName(this.context, (Class<?>) AdminReceiver.class);
        if (!dpm.isAdminActive(adminComponent)) {
            return false;
        }
        try {
            PackageManager pm = this.context.getPackageManager();
            Iterable installedPackages = pm.getInstalledPackages(0);
            Intrinsics.checkNotNullExpressionValue(installedPackages, "getInstalledPackages(...)");
            Iterable iterable = installedPackages;
            Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
            Iterator it = iterable.iterator();
            while (it.hasNext()) {
                arrayList.add(((PackageInfo) it.next()).packageName);
            }
            String[] packages = (String[]) ((List) arrayList).toArray(new String[0]);
            dpm.setPackagesSuspended(adminComponent, packages, false);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
