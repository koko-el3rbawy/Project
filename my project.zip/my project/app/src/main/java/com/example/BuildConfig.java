package com.example;

/* JADX INFO: loaded from: classes8.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.aistudio.supervisor.kxqpmz";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final String GEMINI_API_KEY = "AIzaSyCGP5v-5BmwCWs_vHFIQehE29Kdzv_AQ70";
    public static final String NODE_ENV = "production";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
