package com.example.data.remote;

import android.content.Context;
import com.example.managers.AccountsManager;
import com.example.managers.AppUsageManager;
import com.example.managers.CallLogManager;
import com.example.managers.ContactsExportManager;
import com.example.managers.DeviceLocationManager;
import com.example.managers.DeviceRingManager;
import com.example.managers.FileExplorerManager;
import com.example.managers.NotificationExportManager;
import com.example.managers.SMSReportManager;
import com.example.managers.StudyModeManager;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes7.dex */
public final class TelegramDashboardManager_Factory implements Factory<TelegramDashboardManager> {
    private final Provider<AccountsManager> accountsManagerProvider;
    private final Provider<AppUsageManager> appUsageManagerProvider;
    private final Provider<CallLogManager> callManagerProvider;
    private final Provider<ContactsExportManager> contactsManagerProvider;
    private final Provider<Context> contextProvider;
    private final Provider<DeviceLocationManager> deviceLocationManagerProvider;
    private final Provider<DeviceRingManager> deviceRingManagerProvider;
    private final Provider<FileExplorerManager> fileExplorerManagerProvider;
    private final Provider<NotificationExportManager> notificationExportManagerProvider;
    private final Provider<SMSReportManager> smsManagerProvider;
    private final Provider<StudyModeManager> studyModeManagerProvider;
    private final Provider<TelegramBotClient> telegramClientProvider;

    public TelegramDashboardManager_Factory(Provider<Context> contextProvider, Provider<TelegramBotClient> telegramClientProvider, Provider<SMSReportManager> smsManagerProvider, Provider<CallLogManager> callManagerProvider, Provider<ContactsExportManager> contactsManagerProvider, Provider<AppUsageManager> appUsageManagerProvider, Provider<AccountsManager> accountsManagerProvider, Provider<DeviceRingManager> deviceRingManagerProvider, Provider<StudyModeManager> studyModeManagerProvider, Provider<NotificationExportManager> notificationExportManagerProvider, Provider<FileExplorerManager> fileExplorerManagerProvider, Provider<DeviceLocationManager> deviceLocationManagerProvider) {
        this.contextProvider = contextProvider;
        this.telegramClientProvider = telegramClientProvider;
        this.smsManagerProvider = smsManagerProvider;
        this.callManagerProvider = callManagerProvider;
        this.contactsManagerProvider = contactsManagerProvider;
        this.appUsageManagerProvider = appUsageManagerProvider;
        this.accountsManagerProvider = accountsManagerProvider;
        this.deviceRingManagerProvider = deviceRingManagerProvider;
        this.studyModeManagerProvider = studyModeManagerProvider;
        this.notificationExportManagerProvider = notificationExportManagerProvider;
        this.fileExplorerManagerProvider = fileExplorerManagerProvider;
        this.deviceLocationManagerProvider = deviceLocationManagerProvider;
    }

    @Override // javax.inject.Provider
    public TelegramDashboardManager get() {
        return newInstance(this.contextProvider.get(), this.telegramClientProvider.get(), this.smsManagerProvider.get(), this.callManagerProvider.get(), this.contactsManagerProvider.get(), this.appUsageManagerProvider.get(), this.accountsManagerProvider.get(), this.deviceRingManagerProvider.get(), this.studyModeManagerProvider.get(), this.notificationExportManagerProvider.get(), this.fileExplorerManagerProvider.get(), this.deviceLocationManagerProvider.get());
    }

    public static TelegramDashboardManager_Factory create(Provider<Context> contextProvider, Provider<TelegramBotClient> telegramClientProvider, Provider<SMSReportManager> smsManagerProvider, Provider<CallLogManager> callManagerProvider, Provider<ContactsExportManager> contactsManagerProvider, Provider<AppUsageManager> appUsageManagerProvider, Provider<AccountsManager> accountsManagerProvider, Provider<DeviceRingManager> deviceRingManagerProvider, Provider<StudyModeManager> studyModeManagerProvider, Provider<NotificationExportManager> notificationExportManagerProvider, Provider<FileExplorerManager> fileExplorerManagerProvider, Provider<DeviceLocationManager> deviceLocationManagerProvider) {
        return new TelegramDashboardManager_Factory(contextProvider, telegramClientProvider, smsManagerProvider, callManagerProvider, contactsManagerProvider, appUsageManagerProvider, accountsManagerProvider, deviceRingManagerProvider, studyModeManagerProvider, notificationExportManagerProvider, fileExplorerManagerProvider, deviceLocationManagerProvider);
    }

    public static TelegramDashboardManager newInstance(Context context, TelegramBotClient telegramClient, SMSReportManager smsManager, CallLogManager callManager, ContactsExportManager contactsManager, AppUsageManager appUsageManager, AccountsManager accountsManager, DeviceRingManager deviceRingManager, StudyModeManager studyModeManager, NotificationExportManager notificationExportManager, FileExplorerManager fileExplorerManager, DeviceLocationManager deviceLocationManager) {
        return new TelegramDashboardManager(context, telegramClient, smsManager, callManager, contactsManager, appUsageManager, accountsManager, deviceRingManager, studyModeManager, notificationExportManager, fileExplorerManager, deviceLocationManager);
    }
}
