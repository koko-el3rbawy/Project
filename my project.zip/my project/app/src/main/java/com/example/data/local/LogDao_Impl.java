package com.example.data.local;

import androidx.core.app.NotificationCompat;
import androidx.room.EntityDeleteOrUpdateAdapter;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.SQLiteStatementUtil;
import androidx.sqlite.SQLiteConnection;
import androidx.sqlite.SQLiteStatement;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KClass;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: LogDao_Impl.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0003\b\u0007\u0018\u0000 #2\u00020\u0001:\u0001#B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u0010J\u0016\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u0013J\u0016\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u0013J\u0014\u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00170\u0016H\u0016J\u001c\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00170\u00162\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\u001c\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\b0\u00172\u0006\u0010\u0019\u001a\u00020\u001aH\u0096@¢\u0006\u0002\u0010\u001cJ\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\n0\u0017H\u0096@¢\u0006\u0002\u0010\u001eJ\u0016\u0010\u001f\u001a\u00020\u000e2\u0006\u0010 \u001a\u00020!H\u0096@¢\u0006\u0002\u0010\"R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"}, d2 = {"Lcom/example/data/local/LogDao_Impl;", "Lcom/example/data/local/LogDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfLogEntity", "Landroidx/room/EntityInsertAdapter;", "Lcom/example/data/local/LogEntity;", "__insertAdapterOfPendingMessageEntity", "Lcom/example/data/local/PendingMessageEntity;", "__deleteAdapterOfPendingMessageEntity", "Landroidx/room/EntityDeleteOrUpdateAdapter;", "insertLog", "", "log", "(Lcom/example/data/local/LogEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertPendingMessage", NotificationCompat.CATEGORY_MESSAGE, "(Lcom/example/data/local/PendingMessageEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletePendingMessage", "getRecentLogs", "Lkotlinx/coroutines/flow/Flow;", "", "getLogsByType", "type", "", "getLogsByTypeOnce", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getPendingMessages", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "clearOldLogs", "oldTimestamp", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class LogDao_Impl implements LogDao {
    private final RoomDatabase __db;
    private final EntityDeleteOrUpdateAdapter<PendingMessageEntity> __deleteAdapterOfPendingMessageEntity;
    private final EntityInsertAdapter<LogEntity> __insertAdapterOfLogEntity;
    private final EntityInsertAdapter<PendingMessageEntity> __insertAdapterOfPendingMessageEntity;

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;

    public LogDao_Impl(RoomDatabase __db) {
        Intrinsics.checkNotNullParameter(__db, "__db");
        this.__db = __db;
        this.__insertAdapterOfLogEntity = new EntityInsertAdapter<LogEntity>() { // from class: com.example.data.local.LogDao_Impl.1
            @Override // androidx.room.EntityInsertAdapter
            protected String createQuery() {
                return "INSERT OR ABORT INTO `logs` (`id`,`timestamp`,`type`,`content`) VALUES (nullif(?, 0),?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(SQLiteStatement statement, LogEntity entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo6928bindLong(1, entity.getId());
                statement.mo6928bindLong(2, entity.getTimestamp());
                statement.mo6930bindText(3, entity.getType());
                statement.mo6930bindText(4, entity.getContent());
            }
        };
        this.__insertAdapterOfPendingMessageEntity = new EntityInsertAdapter<PendingMessageEntity>() { // from class: com.example.data.local.LogDao_Impl.2
            @Override // androidx.room.EntityInsertAdapter
            protected String createQuery() {
                return "INSERT OR ABORT INTO `pending_messages` (`id`,`text`,`parseMode`,`timestamp`) VALUES (nullif(?, 0),?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(SQLiteStatement statement, PendingMessageEntity entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo6928bindLong(1, entity.getId());
                statement.mo6930bindText(2, entity.getText());
                statement.mo6930bindText(3, entity.getParseMode());
                statement.mo6928bindLong(4, entity.getTimestamp());
            }
        };
        this.__deleteAdapterOfPendingMessageEntity = new EntityDeleteOrUpdateAdapter<PendingMessageEntity>() { // from class: com.example.data.local.LogDao_Impl.3
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            protected String createQuery() {
                return "DELETE FROM `pending_messages` WHERE `id` = ?";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            public void bind(SQLiteStatement statement, PendingMessageEntity entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo6928bindLong(1, entity.getId());
            }
        };
    }

    @Override // com.example.data.local.LogDao
    public Object insertLog(final LogEntity log, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.insertLog$lambda$0(this.f$0, log, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit insertLog$lambda$0(LogDao_Impl this$0, LogEntity $log, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        this$0.__insertAdapterOfLogEntity.insert(_connection, $log);
        return Unit.INSTANCE;
    }

    @Override // com.example.data.local.LogDao
    public Object insertPendingMessage(final PendingMessageEntity msg, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.insertPendingMessage$lambda$1(this.f$0, msg, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit insertPendingMessage$lambda$1(LogDao_Impl this$0, PendingMessageEntity $msg, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        this$0.__insertAdapterOfPendingMessageEntity.insert(_connection, $msg);
        return Unit.INSTANCE;
    }

    @Override // com.example.data.local.LogDao
    public Object deletePendingMessage(final PendingMessageEntity msg, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.deletePendingMessage$lambda$2(this.f$0, msg, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit deletePendingMessage$lambda$2(LogDao_Impl this$0, PendingMessageEntity $msg, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        this$0.__deleteAdapterOfPendingMessageEntity.handle(_connection, $msg);
        return Unit.INSTANCE;
    }

    @Override // com.example.data.local.LogDao
    public Flow<List<LogEntity>> getRecentLogs() {
        final String _sql = "SELECT * FROM logs ORDER BY timestamp DESC LIMIT 100";
        return FlowUtil.createFlow(this.__db, false, new String[]{"logs"}, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.getRecentLogs$lambda$3(_sql, (SQLiteConnection) obj);
            }
        });
    }

    static final List getRecentLogs$lambda$3(String $_sql, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfTimestamp = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "timestamp");
            int _columnIndexOfType = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "type");
            int _columnIndexOfContent = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "content");
            List _result = new ArrayList();
            while (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                long _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp);
                String _tmpType = _stmt.getText(_columnIndexOfType);
                String _tmpContent = _stmt.getText(_columnIndexOfContent);
                LogEntity _item = new LogEntity(_tmpId, _tmpTimestamp, _tmpType, _tmpContent);
                _result.add(_item);
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.local.LogDao
    public Flow<List<LogEntity>> getLogsByType(final String type) {
        Intrinsics.checkNotNullParameter(type, "type");
        final String _sql = "SELECT * FROM logs WHERE type = ? ORDER BY timestamp DESC LIMIT 50";
        return FlowUtil.createFlow(this.__db, false, new String[]{"logs"}, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.getLogsByType$lambda$4(_sql, type, (SQLiteConnection) obj);
            }
        });
    }

    static final List getLogsByType$lambda$4(String $_sql, String $type, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo6930bindText(1, $type);
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfTimestamp = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "timestamp");
            int _columnIndexOfType = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "type");
            int _columnIndexOfContent = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "content");
            List _result = new ArrayList();
            while (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                long _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp);
                String _tmpType = _stmt.getText(_columnIndexOfType);
                String _tmpContent = _stmt.getText(_columnIndexOfContent);
                LogEntity _item = new LogEntity(_tmpId, _tmpTimestamp, _tmpType, _tmpContent);
                _result.add(_item);
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.local.LogDao
    public Object getLogsByTypeOnce(final String type, Continuation<? super List<LogEntity>> continuation) {
        final String _sql = "SELECT * FROM logs WHERE type = ? ORDER BY timestamp DESC LIMIT 100";
        return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.getLogsByTypeOnce$lambda$5(_sql, type, (SQLiteConnection) obj);
            }
        }, continuation);
    }

    static final List getLogsByTypeOnce$lambda$5(String $_sql, String $type, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo6930bindText(1, $type);
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfTimestamp = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "timestamp");
            int _columnIndexOfType = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "type");
            int _columnIndexOfContent = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "content");
            List _result = new ArrayList();
            while (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                long _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp);
                String _tmpType = _stmt.getText(_columnIndexOfType);
                String _tmpContent = _stmt.getText(_columnIndexOfContent);
                LogEntity _item = new LogEntity(_tmpId, _tmpTimestamp, _tmpType, _tmpContent);
                _result.add(_item);
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.local.LogDao
    public Object getPendingMessages(Continuation<? super List<PendingMessageEntity>> continuation) {
        final String _sql = "SELECT * FROM pending_messages ORDER BY timestamp ASC";
        return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.getPendingMessages$lambda$6(_sql, (SQLiteConnection) obj);
            }
        }, continuation);
    }

    static final List getPendingMessages$lambda$6(String $_sql, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfText = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "text");
            int _columnIndexOfParseMode = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "parseMode");
            int _columnIndexOfTimestamp = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "timestamp");
            List _result = new ArrayList();
            while (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                String _tmpText = _stmt.getText(_columnIndexOfText);
                String _tmpParseMode = _stmt.getText(_columnIndexOfParseMode);
                long _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp);
                PendingMessageEntity _item = new PendingMessageEntity(_tmpId, _tmpText, _tmpParseMode, _tmpTimestamp);
                _result.add(_item);
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.local.LogDao
    public Object clearOldLogs(final long oldTimestamp, Continuation<? super Unit> continuation) {
        final String _sql = "DELETE FROM logs WHERE timestamp < ?";
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.local.LogDao_Impl$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LogDao_Impl.clearOldLogs$lambda$7(_sql, oldTimestamp, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit clearOldLogs$lambda$7(String $_sql, long $oldTimestamp, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo6928bindLong(1, $oldTimestamp);
            _stmt.step();
            _stmt.close();
            return Unit.INSTANCE;
        } catch (Throwable th) {
            _stmt.close();
            throw th;
        }
    }

    /* JADX INFO: compiled from: LogDao_Impl.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/example/data/local/LogDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final List<KClass<?>> getRequiredConverters() {
            return CollectionsKt.emptyList();
        }
    }
}
