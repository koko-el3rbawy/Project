package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class CallLogManager_Factory implements Factory<CallLogManager> {
    private final Provider<Context> contextProvider;

    public CallLogManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public CallLogManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static CallLogManager_Factory create(Provider<Context> contextProvider) {
        return new CallLogManager_Factory(contextProvider);
    }

    public static CallLogManager newInstance(Context context) {
        return new CallLogManager(context);
    }
}
