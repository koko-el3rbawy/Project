package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class SMSReportManager_Factory implements Factory<SMSReportManager> {
    private final Provider<Context> contextProvider;

    public SMSReportManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public SMSReportManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static SMSReportManager_Factory create(Provider<Context> contextProvider) {
        return new SMSReportManager_Factory(contextProvider);
    }

    public static SMSReportManager newInstance(Context context) {
        return new SMSReportManager(context);
    }
}
