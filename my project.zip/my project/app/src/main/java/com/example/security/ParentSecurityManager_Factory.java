package com.example.security;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes11.dex */
public final class ParentSecurityManager_Factory implements Factory<ParentSecurityManager> {
    private final Provider<Context> contextProvider;

    public ParentSecurityManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public ParentSecurityManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static ParentSecurityManager_Factory create(Provider<Context> contextProvider) {
        return new ParentSecurityManager_Factory(contextProvider);
    }

    public static ParentSecurityManager newInstance(Context context) {
        return new ParentSecurityManager(context);
    }
}
