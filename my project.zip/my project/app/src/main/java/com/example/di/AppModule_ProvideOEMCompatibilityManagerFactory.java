package com.example.di;

import android.content.Context;
import com.example.managers.OEMCompatibilityManager;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideOEMCompatibilityManagerFactory implements Factory<OEMCompatibilityManager> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideOEMCompatibilityManagerFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public OEMCompatibilityManager get() {
        return provideOEMCompatibilityManager(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideOEMCompatibilityManagerFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideOEMCompatibilityManagerFactory(module, contextProvider);
    }

    public static OEMCompatibilityManager provideOEMCompatibilityManager(AppModule instance, Context context) {
        return (OEMCompatibilityManager) Preconditions.checkNotNullFromProvides(instance.provideOEMCompatibilityManager(context));
    }
}
