package com.example.managers;

import android.content.Context;
import android.database.Cursor;
import android.provider.CallLog;
import androidx.compose.material3.internal.CalendarModelKt;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CallLogManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/example/managers/CallLogManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "generateReport", "Ljava/io/File;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CallLogManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public CallLogManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final File generateReport() {
        Cursor cursor;
        Throwable th;
        String str;
        File reportFile = new File(this.context.getCacheDir(), "call_log_report_" + System.currentTimeMillis() + ".txt");
        StringBuilder sb = new StringBuilder();
        sb.append("CALL LOG REPORT (Last 24 Hours)\n");
        sb.append("========================\n\n");
        long timeLimit = System.currentTimeMillis() - CalendarModelKt.MillisecondsIn24Hours;
        try {
            cursor = this.context.getContentResolver().query(CallLog.Calls.CONTENT_URI, null, "date >= ?", new String[]{String.valueOf(timeLimit)}, "date DESC");
        } catch (Exception e) {
            e = e;
        }
        try {
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor cursor3 = cursor2;
                    int columnIndex = cursor3.getColumnIndex("number");
                    int columnIndex2 = cursor3.getColumnIndex("type");
                    int columnIndex3 = cursor3.getColumnIndex("date");
                    int columnIndex4 = cursor3.getColumnIndex("duration");
                    while (cursor3.moveToNext()) {
                        String string = cursor3.getString(columnIndex);
                        int i = cursor3.getInt(columnIndex2);
                        long j = cursor3.getLong(columnIndex3);
                        String string2 = cursor3.getString(columnIndex4);
                        Cursor cursor4 = cursor3;
                        long timeLimit2 = timeLimit;
                        try {
                            String str2 = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(j));
                            switch (i) {
                                case 1:
                                    str = "INCOMING";
                                    break;
                                case 2:
                                    str = "OUTGOING";
                                    break;
                                case 3:
                                    str = "MISSED";
                                    break;
                                default:
                                    str = "OTHER";
                                    break;
                            }
                            sb.append("[" + str2 + "] " + str + " - " + string + "\n");
                            sb.append("Duration: " + string2 + " seconds\n");
                            sb.append("------------------------\n");
                            cursor3 = cursor4;
                            timeLimit = timeLimit2;
                        } catch (Throwable th2) {
                            th = th2;
                            try {
                                throw th;
                            } catch (Throwable th3) {
                                CloseableKt.closeFinally(cursor2, th);
                                throw th3;
                            }
                        }
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, null);
                } catch (Throwable th4) {
                    th = th4;
                }
            }
            String string3 = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string3, "toString(...)");
            FilesKt.writeText$default(reportFile, string3, null, 2, null);
            return reportFile;
        } catch (Exception e2) {
            e = e2;
            e.printStackTrace();
            return null;
        }
    }
}
