package com.example.di;

import android.content.Context;
import dagger.internal.Factory;
import dagger.internal.Preconditions;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideContextFactory implements Factory<Context> {
    private final AppModule module;

    public AppModule_ProvideContextFactory(AppModule module) {
        this.module = module;
    }

    @Override // javax.inject.Provider
    public Context get() {
        return provideContext(this.module);
    }

    public static AppModule_ProvideContextFactory create(AppModule module) {
        return new AppModule_ProvideContextFactory(module);
    }

    public static Context provideContext(AppModule instance) {
        return (Context) Preconditions.checkNotNullFromProvides(instance.getContext());
    }
}
