package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class FileExplorerManager_Factory implements Factory<FileExplorerManager> {
    private final Provider<Context> contextProvider;

    public FileExplorerManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public FileExplorerManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static FileExplorerManager_Factory create(Provider<Context> contextProvider) {
        return new FileExplorerManager_Factory(contextProvider);
    }

    public static FileExplorerManager newInstance(Context context) {
        return new FileExplorerManager(context);
    }
}
