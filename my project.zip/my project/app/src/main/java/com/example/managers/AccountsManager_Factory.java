package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class AccountsManager_Factory implements Factory<AccountsManager> {
    private final Provider<Context> contextProvider;

    public AccountsManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public AccountsManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static AccountsManager_Factory create(Provider<Context> contextProvider) {
        return new AccountsManager_Factory(contextProvider);
    }

    public static AccountsManager newInstance(Context context) {
        return new AccountsManager(context);
    }
}
