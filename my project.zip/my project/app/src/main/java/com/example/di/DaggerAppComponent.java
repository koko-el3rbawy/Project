package com.example.di;

import android.content.Context;
import com.example.ParentalApp;
import com.example.ParentalApp_MembersInjector;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import com.example.data.repository.SettingsRepository;
import com.example.managers.AccountsManager;
import com.example.managers.AccountsManager_Factory;
import com.example.managers.AppUsageManager;
import com.example.managers.AppUsageManager_Factory;
import com.example.managers.CallLogManager;
import com.example.managers.CallLogManager_Factory;
import com.example.managers.ContactsExportManager;
import com.example.managers.ContactsExportManager_Factory;
import com.example.managers.DeviceLocationManager;
import com.example.managers.DeviceLocationManager_Factory;
import com.example.managers.DeviceRingManager;
import com.example.managers.DeviceRingManager_Factory;
import com.example.managers.FileExplorerManager;
import com.example.managers.FileExplorerManager_Factory;
import com.example.managers.NotificationExportManager;
import com.example.managers.NotificationExportManager_Factory;
import com.example.managers.OEMCompatibilityManager;
import com.example.managers.SMSReportManager;
import com.example.managers.SMSReportManager_Factory;
import com.example.managers.StudyModeManager;
import com.example.managers.StudyModeManager_Factory;
import com.example.security.ParentSecurityManager;
import com.example.services.LocationForegroundService;
import com.example.services.LocationForegroundService_MembersInjector;
import com.example.services.ParentNotificationListener;
import com.example.services.ParentNotificationListener_MembersInjector;
import com.example.utils.BatteryOptimizationHelper;
import com.example.utils.DeviceAdminManager;
import com.example.utils.NotificationPermissionHelper;
import com.example.work.CustomWorkerFactory;
import com.example.work.DailyReportWorker;
import com.example.work.DailyReportWorker_MembersInjector;
import com.example.work.TelegramRetryWorker;
import com.example.work.TelegramRetryWorker_MembersInjector;
import dagger.internal.DoubleCheck;
import dagger.internal.Preconditions;
import dagger.internal.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class DaggerAppComponent {
    private DaggerAppComponent() {
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private AppModule appModule;

        private Builder() {
        }

        public Builder appModule(AppModule appModule) {
            this.appModule = (AppModule) Preconditions.checkNotNull(appModule);
            return this;
        }

        public AppComponent build() {
            Preconditions.checkBuilderRequirement(this.appModule, AppModule.class);
            return new AppComponentImpl(this.appModule);
        }
    }

    private static final class AppComponentImpl implements AppComponent {
        private Provider<AccountsManager> accountsManagerProvider;
        private final AppComponentImpl appComponentImpl;
        private Provider<AppUsageManager> appUsageManagerProvider;
        private Provider<CallLogManager> callLogManagerProvider;
        private Provider<ContactsExportManager> contactsExportManagerProvider;
        private Provider<DeviceLocationManager> deviceLocationManagerProvider;
        private Provider<DeviceRingManager> deviceRingManagerProvider;
        private Provider<FileExplorerManager> fileExplorerManagerProvider;
        private Provider<NotificationExportManager> notificationExportManagerProvider;
        private Provider<AppDatabase> provideAppDatabaseProvider;
        private Provider<BatteryOptimizationHelper> provideBatteryOptimizationHelperProvider;
        private Provider<Context> provideContextProvider;
        private Provider<DeviceAdminManager> provideDeviceAdminManagerProvider;
        private Provider<NotificationPermissionHelper> provideNotificationPermissionHelperProvider;
        private Provider<OEMCompatibilityManager> provideOEMCompatibilityManagerProvider;
        private Provider<ParentSecurityManager> provideParentSecurityManagerProvider;
        private Provider<SettingsRepository> provideSettingsRepositoryProvider;
        private Provider<TelegramBotClient> provideTelegramBotClientProvider;
        private Provider<TelegramDashboardManager> provideTelegramDashboardManagerProvider;
        private Provider<SMSReportManager> sMSReportManagerProvider;
        private Provider<StudyModeManager> studyModeManagerProvider;

        private AppComponentImpl(AppModule appModuleParam) {
            this.appComponentImpl = this;
            initialize(appModuleParam);
        }

        private void initialize(final AppModule appModuleParam) {
            this.provideContextProvider = DoubleCheck.provider(AppModule_ProvideContextFactory.create(appModuleParam));
            this.provideSettingsRepositoryProvider = DoubleCheck.provider(AppModule_ProvideSettingsRepositoryFactory.create(appModuleParam, this.provideContextProvider));
            this.provideTelegramBotClientProvider = DoubleCheck.provider(AppModule_ProvideTelegramBotClientFactory.create(appModuleParam, this.provideSettingsRepositoryProvider));
            this.sMSReportManagerProvider = DoubleCheck.provider(SMSReportManager_Factory.create(this.provideContextProvider));
            this.callLogManagerProvider = DoubleCheck.provider(CallLogManager_Factory.create(this.provideContextProvider));
            this.contactsExportManagerProvider = DoubleCheck.provider(ContactsExportManager_Factory.create(this.provideContextProvider));
            this.appUsageManagerProvider = DoubleCheck.provider(AppUsageManager_Factory.create(this.provideContextProvider));
            this.accountsManagerProvider = DoubleCheck.provider(AccountsManager_Factory.create(this.provideContextProvider));
            this.deviceRingManagerProvider = DoubleCheck.provider(DeviceRingManager_Factory.create(this.provideContextProvider));
            this.studyModeManagerProvider = DoubleCheck.provider(StudyModeManager_Factory.create(this.provideContextProvider));
            this.provideAppDatabaseProvider = DoubleCheck.provider(AppModule_ProvideAppDatabaseFactory.create(appModuleParam, this.provideContextProvider));
            this.notificationExportManagerProvider = DoubleCheck.provider(NotificationExportManager_Factory.create(this.provideContextProvider, this.provideAppDatabaseProvider));
            this.fileExplorerManagerProvider = DoubleCheck.provider(FileExplorerManager_Factory.create(this.provideContextProvider));
            this.deviceLocationManagerProvider = DoubleCheck.provider(DeviceLocationManager_Factory.create(this.provideContextProvider));
            this.provideTelegramDashboardManagerProvider = DoubleCheck.provider(AppModule_ProvideTelegramDashboardManagerFactory.create(appModuleParam, this.provideContextProvider, this.provideTelegramBotClientProvider, this.sMSReportManagerProvider, this.callLogManagerProvider, this.contactsExportManagerProvider, this.appUsageManagerProvider, this.accountsManagerProvider, this.deviceRingManagerProvider, this.studyModeManagerProvider, this.notificationExportManagerProvider, this.fileExplorerManagerProvider, this.deviceLocationManagerProvider));
            this.provideDeviceAdminManagerProvider = DoubleCheck.provider(AppModule_ProvideDeviceAdminManagerFactory.create(appModuleParam, this.provideContextProvider));
            this.provideParentSecurityManagerProvider = DoubleCheck.provider(AppModule_ProvideParentSecurityManagerFactory.create(appModuleParam, this.provideContextProvider));
            this.provideNotificationPermissionHelperProvider = DoubleCheck.provider(AppModule_ProvideNotificationPermissionHelperFactory.create(appModuleParam, this.provideContextProvider));
            this.provideOEMCompatibilityManagerProvider = DoubleCheck.provider(AppModule_ProvideOEMCompatibilityManagerFactory.create(appModuleParam, this.provideContextProvider));
            this.provideBatteryOptimizationHelperProvider = DoubleCheck.provider(AppModule_ProvideBatteryOptimizationHelperFactory.create(appModuleParam, this.provideContextProvider));
        }

        @Override // com.example.di.AppComponent
        public void inject(ParentalApp app) {
            injectParentalApp(app);
        }

        @Override // com.example.di.AppComponent
        public void inject(LocationForegroundService service) {
            injectLocationForegroundService(service);
        }

        @Override // com.example.di.AppComponent
        public void inject(ParentNotificationListener service) {
            injectParentNotificationListener(service);
        }

        @Override // com.example.di.AppComponent
        public void inject(DailyReportWorker worker) {
            injectDailyReportWorker(worker);
        }

        @Override // com.example.di.AppComponent
        public void inject(TelegramRetryWorker worker) {
            injectTelegramRetryWorker(worker);
        }

        @Override // com.example.di.AppComponent
        public SettingsRepository getSettingsRepository() {
            return this.provideSettingsRepositoryProvider.get();
        }

        @Override // com.example.di.AppComponent
        public TelegramBotClient getTelegramBotClient() {
            return this.provideTelegramBotClientProvider.get();
        }

        @Override // com.example.di.AppComponent
        public TelegramDashboardManager getTelegramDashboardManager() {
            return this.provideTelegramDashboardManagerProvider.get();
        }

        @Override // com.example.di.AppComponent
        public AppDatabase getAppDatabase() {
            return this.provideAppDatabaseProvider.get();
        }

        @Override // com.example.di.AppComponent
        public DeviceAdminManager getDeviceAdminManager() {
            return this.provideDeviceAdminManagerProvider.get();
        }

        @Override // com.example.di.AppComponent
        public ParentSecurityManager getParentSecurityManager() {
            return this.provideParentSecurityManagerProvider.get();
        }

        @Override // com.example.di.AppComponent
        public NotificationPermissionHelper getNotificationPermissionHelper() {
            return this.provideNotificationPermissionHelperProvider.get();
        }

        @Override // com.example.di.AppComponent
        public OEMCompatibilityManager getOEMCompatibilityManager() {
            return this.provideOEMCompatibilityManagerProvider.get();
        }

        @Override // com.example.di.AppComponent
        public BatteryOptimizationHelper getBatteryOptimizationHelper() {
            return this.provideBatteryOptimizationHelperProvider.get();
        }

        private ParentalApp injectParentalApp(ParentalApp instance) {
            ParentalApp_MembersInjector.injectWorkerFactory(instance, new CustomWorkerFactory());
            return instance;
        }

        private LocationForegroundService injectLocationForegroundService(LocationForegroundService instance) {
            LocationForegroundService_MembersInjector.injectTelegramClient(instance, this.provideTelegramBotClientProvider.get());
            LocationForegroundService_MembersInjector.injectDashboardManager(instance, this.provideTelegramDashboardManagerProvider.get());
            LocationForegroundService_MembersInjector.injectDb(instance, this.provideAppDatabaseProvider.get());
            return instance;
        }

        private ParentNotificationListener injectParentNotificationListener(ParentNotificationListener instance) {
            ParentNotificationListener_MembersInjector.injectTelegramClient(instance, this.provideTelegramBotClientProvider.get());
            ParentNotificationListener_MembersInjector.injectDb(instance, this.provideAppDatabaseProvider.get());
            ParentNotificationListener_MembersInjector.injectSettings(instance, this.provideSettingsRepositoryProvider.get());
            return instance;
        }

        private DailyReportWorker injectDailyReportWorker(DailyReportWorker instance) {
            DailyReportWorker_MembersInjector.injectTelegramClient(instance, this.provideTelegramBotClientProvider.get());
            DailyReportWorker_MembersInjector.injectDb(instance, this.provideAppDatabaseProvider.get());
            return instance;
        }

        private TelegramRetryWorker injectTelegramRetryWorker(TelegramRetryWorker instance) {
            TelegramRetryWorker_MembersInjector.injectTelegramClient(instance, this.provideTelegramBotClientProvider.get());
            TelegramRetryWorker_MembersInjector.injectDb(instance, this.provideAppDatabaseProvider.get());
            return instance;
        }
    }
}
