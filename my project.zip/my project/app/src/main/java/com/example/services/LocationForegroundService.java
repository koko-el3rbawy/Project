package com.example.services;

import android.R;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import androidx.work.PeriodicWorkRequest;
import com.example.MainActivity;
import com.example.ParentalApp;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;

/* JADX INFO: compiled from: LocationForegroundService.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u001c\u001a\u00020\u001dH\u0016J\"\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010!2\u0006\u0010\"\u001a\u00020\u001f2\u0006\u0010#\u001a\u00020\u001fH\u0016J\b\u0010$\u001a\u00020\u001dH\u0002J\b\u0010%\u001a\u00020\u001dH\u0002J\b\u0010&\u001a\u00020'H\u0002J\b\u0010(\u001a\u00020\u001dH\u0016J\u0012\u0010)\u001a\u0004\u0018\u00010*2\u0006\u0010 \u001a\u00020!H\u0016R\u001e\u0010\u0004\u001a\u00020\u00058\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001e\u0010\n\u001a\u00020\u000b8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001e\u0010\u0010\u001a\u00020\u00118\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006+"}, d2 = {"Lcom/example/services/LocationForegroundService;", "Landroid/app/Service;", "<init>", "()V", "telegramClient", "Lcom/example/data/remote/TelegramBotClient;", "getTelegramClient", "()Lcom/example/data/remote/TelegramBotClient;", "setTelegramClient", "(Lcom/example/data/remote/TelegramBotClient;)V", "dashboardManager", "Lcom/example/data/remote/TelegramDashboardManager;", "getDashboardManager", "()Lcom/example/data/remote/TelegramDashboardManager;", "setDashboardManager", "(Lcom/example/data/remote/TelegramDashboardManager;)V", "db", "Lcom/example/data/local/AppDatabase;", "getDb", "()Lcom/example/data/local/AppDatabase;", "setDb", "(Lcom/example/data/local/AppDatabase;)V", "fusedLocationClient", "Lcom/google/android/gms/location/FusedLocationProviderClient;", "locationCallback", "Lcom/google/android/gms/location/LocationCallback;", "serviceScope", "Lkotlinx/coroutines/CoroutineScope;", "onCreate", "", "onStartCommand", "", "intent", "Landroid/content/Intent;", "flags", "startId", "requestLocationUpdates", "createNotificationChannel", "createNotification", "Landroid/app/Notification;", "onDestroy", "onBind", "Landroid/os/IBinder;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class LocationForegroundService extends Service {
    public static final int $stable = 8;

    @Inject
    public TelegramDashboardManager dashboardManager;

    @Inject
    public AppDatabase db;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private final CoroutineScope serviceScope = CoroutineScopeKt.CoroutineScope(Dispatchers.getIO().plus(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null)));

    @Inject
    public TelegramBotClient telegramClient;

    public final TelegramBotClient getTelegramClient() {
        TelegramBotClient telegramBotClient = this.telegramClient;
        if (telegramBotClient != null) {
            return telegramBotClient;
        }
        Intrinsics.throwUninitializedPropertyAccessException("telegramClient");
        return null;
    }

    public final void setTelegramClient(TelegramBotClient telegramBotClient) {
        Intrinsics.checkNotNullParameter(telegramBotClient, "<set-?>");
        this.telegramClient = telegramBotClient;
    }

    public final TelegramDashboardManager getDashboardManager() {
        TelegramDashboardManager telegramDashboardManager = this.dashboardManager;
        if (telegramDashboardManager != null) {
            return telegramDashboardManager;
        }
        Intrinsics.throwUninitializedPropertyAccessException("dashboardManager");
        return null;
    }

    public final void setDashboardManager(TelegramDashboardManager telegramDashboardManager) {
        Intrinsics.checkNotNullParameter(telegramDashboardManager, "<set-?>");
        this.dashboardManager = telegramDashboardManager;
    }

    public final AppDatabase getDb() {
        AppDatabase appDatabase = this.db;
        if (appDatabase != null) {
            return appDatabase;
        }
        Intrinsics.throwUninitializedPropertyAccessException("db");
        return null;
    }

    public final void setDb(AppDatabase appDatabase) {
        Intrinsics.checkNotNullParameter(appDatabase, "<set-?>");
        this.db = appDatabase;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Context applicationContext = getApplicationContext();
        Intrinsics.checkNotNull(applicationContext, "null cannot be cast to non-null type com.example.ParentalApp");
        ((ParentalApp) applicationContext).getAppComponent().inject(this);
        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        Intrinsics.checkNotNullExpressionValue(fusedLocationProviderClient, "getFusedLocationProviderClient(...)");
        this.fusedLocationClient = fusedLocationProviderClient;
        this.locationCallback = new LocationCallback() { // from class: com.example.services.LocationForegroundService.onCreate.1
            @Override // com.google.android.gms.location.LocationCallback
            public void onLocationResult(LocationResult locationResult) {
                Intrinsics.checkNotNullParameter(locationResult, "locationResult");
                for (Location location : locationResult.getLocations()) {
                    String link = "https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
                    BuildersKt__Builders_commonKt.launch$default(LocationForegroundService.this.serviceScope, null, null, new LocationForegroundService$onCreate$1$onLocationResult$1(LocationForegroundService.this, link, null), 3, null);
                }
            }
        };
        BuildersKt__Builders_commonKt.launch$default(this.serviceScope, null, null, new AnonymousClass2(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.services.LocationForegroundService$onCreate$2, reason: invalid class name */
    /* JADX INFO: compiled from: LocationForegroundService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.services.LocationForegroundService$onCreate$2", f = "LocationForegroundService.kt", i = {}, l = {62}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return LocationForegroundService.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (LocationForegroundService.this.getDashboardManager().startPolling(this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Intrinsics.areEqual(intent != null ? intent.getAction() : null, "ACTION_STOP")) {
            stopSelf();
            return 2;
        }
        createNotificationChannel();
        try {
            if (Build.VERSION.SDK_INT >= 34 || Build.VERSION.SDK_INT >= 30) {
                startForeground(1, createNotification(), 73);
            } else if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, createNotification(), 9);
            } else {
                startForeground(1, createNotification());
            }
            requestLocationUpdates();
        } catch (Exception e) {
            e.printStackTrace();
            stopSelf();
        }
        return 1;
    }

    private final void requestLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest.Builder(102, PeriodicWorkRequest.MIN_PERIODIC_INTERVAL_MILLIS).build();
        Intrinsics.checkNotNullExpressionValue(locationRequest, "build(...)");
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
            LocationCallback locationCallback = null;
            if (fusedLocationProviderClient == null) {
                Intrinsics.throwUninitializedPropertyAccessException("fusedLocationClient");
                fusedLocationProviderClient = null;
            }
            LocationCallback locationCallback2 = this.locationCallback;
            if (locationCallback2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("locationCallback");
            } else {
                locationCallback = locationCallback2;
            }
            fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        }
    }

    private final void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("parental_monitor_channel", "Parental Monitor Service", 2);
            NotificationManager manager = (NotificationManager) getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private final Notification createNotification() {
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) MainActivity.class), AccessibilityEventCompat.TYPE_VIEW_TARGETED_BY_SCROLL);
        Notification notificationBuild = new NotificationCompat.Builder(this, "parental_monitor_channel").setContentTitle("Parental Monitoring Active").setContentText("This device is currently supervised by a parent/guardian.").setSmallIcon(R.drawable.ic_menu_compass).setContentIntent(pendingIntent).setOngoing(true).setForegroundServiceBehavior(1).build();
        Intrinsics.checkNotNullExpressionValue(notificationBuild, "build(...)");
        return notificationBuild;
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
        if (fusedLocationProviderClient == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fusedLocationClient");
            fusedLocationProviderClient = null;
        }
        LocationCallback locationCallback = this.locationCallback;
        if (locationCallback == null) {
            Intrinsics.throwUninitializedPropertyAccessException("locationCallback");
            locationCallback = null;
        }
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
        CoroutineScopeKt.cancel$default(this.serviceScope, null, 1, null);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Intrinsics.checkNotNullParameter(intent, "intent");
        return null;
    }
}
