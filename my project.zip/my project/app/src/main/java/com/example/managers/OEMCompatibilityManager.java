package com.example.managers;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import java.util.Locale;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: OEMCompatibilityManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\n\u001a\u00020\u000bJ\u0006\u0010\f\u001a\u00020\rJ\u0006\u0010\u000e\u001a\u00020\rR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\b\b\u0010\t¨\u0006\u000f"}, d2 = {"Lcom/example/managers/OEMCompatibilityManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "manufacturer", "", "getManufacturer", "()Ljava/lang/String;", "hasAutoStartRequirement", "", "openAutoStartSettings", "", "openBatteryWhitelist", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class OEMCompatibilityManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public OEMCompatibilityManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final String getManufacturer() {
        String MANUFACTURER = Build.MANUFACTURER;
        Intrinsics.checkNotNullExpressionValue(MANUFACTURER, "MANUFACTURER");
        return MANUFACTURER;
    }

    public final boolean hasAutoStartRequirement() {
        String m = getManufacturer().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(m, "toLowerCase(...)");
        return StringsKt.contains$default((CharSequence) m, (CharSequence) "xiaomi", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) m, (CharSequence) "oppo", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) m, (CharSequence) "vivo", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) m, (CharSequence) "huawei", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) m, (CharSequence) "samsung", false, 2, (Object) null);
    }

    public final void openAutoStartSettings() {
        try {
            Intent intent = new Intent();
            String MANUFACTURER = Build.MANUFACTURER;
            Intrinsics.checkNotNullExpressionValue(MANUFACTURER, "MANUFACTURER");
            String manufacturer = MANUFACTURER.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(manufacturer, "toLowerCase(...)");
            if (StringsKt.contains$default((CharSequence) manufacturer, (CharSequence) "xiaomi", false, 2, (Object) null)) {
                intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            } else if (StringsKt.contains$default((CharSequence) manufacturer, (CharSequence) "oppo", false, 2, (Object) null)) {
                intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
            } else if (StringsKt.contains$default((CharSequence) manufacturer, (CharSequence) "vivo", false, 2, (Object) null)) {
                intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
            } else if (StringsKt.contains$default((CharSequence) manufacturer, (CharSequence) "huawei", false, 2, (Object) null)) {
                intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
            } else if (StringsKt.contains$default((CharSequence) manufacturer, (CharSequence) "samsung", false, 2, (Object) null)) {
                intent.setComponent(new ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.ui.ram.AutoRunActivity"));
            } else {
                intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", this.context.getPackageName(), null));
            }
            intent.addFlags(268435456);
            this.context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                Intent fallbackIntent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                fallbackIntent.setData(Uri.parse("package:" + this.context.getPackageName()));
                fallbackIntent.addFlags(268435456);
                this.context.startActivity(fallbackIntent);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public final void openBatteryWhitelist() {
        try {
            Intent intent = new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
            intent.addFlags(268435456);
            this.context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
