package com.example.managers;

import android.content.Context;
import com.example.data.local.AppDatabase;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: NotificationExportManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0019\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\b\u001a\u0004\u0018\u00010\tH\u0086@¢\u0006\u0002\u0010\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/example/managers/NotificationExportManager;", "", "context", "Landroid/content/Context;", "appDatabase", "Lcom/example/data/local/AppDatabase;", "<init>", "(Landroid/content/Context;Lcom/example/data/local/AppDatabase;)V", "generateReport", "Ljava/io/File;", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NotificationExportManager {
    public static final int $stable = 8;
    private final AppDatabase appDatabase;
    private final Context context;

    /* JADX INFO: renamed from: com.example.managers.NotificationExportManager$generateReport$1, reason: invalid class name */
    /* JADX INFO: compiled from: NotificationExportManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.managers.NotificationExportManager", f = "NotificationExportManager.kt", i = {0, 0}, l = {24}, m = "generateReport", n = {"reportFile", "sb"}, s = {"L$0", "L$1"})
    static final class AnonymousClass1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return NotificationExportManager.this.generateReport(this);
        }
    }

    @Inject
    public NotificationExportManager(Context context, AppDatabase appDatabase) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(appDatabase, "appDatabase");
        this.context = context;
        this.appDatabase = appDatabase;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x009d A[Catch: Exception -> 0x003c, LOOP:0: B:23:0x0097->B:25:0x009d, LOOP_END, TryCatch #1 {Exception -> 0x003c, blocks: (B:13:0x0037, B:22:0x0091, B:23:0x0097, B:25:0x009d, B:26:0x0102), top: B:34:0x0037 }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object generateReport(kotlin.coroutines.Continuation<? super java.io.File> r14) {
        /*
            Method dump skipped, instruction units count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.managers.NotificationExportManager.generateReport(kotlin.coroutines.Continuation):java.lang.Object");
    }
}
