package com.example;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.TextUnitKt;
import com.example.ui.theme.ColorKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
public final class ComposableSingletons$MainActivityKt {
    public static final ComposableSingletons$MainActivityKt INSTANCE = new ComposableSingletons$MainActivityKt();

    /* JADX INFO: renamed from: lambda$-1992305012, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f90lambda$1992305012 = ComposableLambdaKt.composableLambdaInstance(-1992305012, false, new Function2() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainActivityKt.lambda__1992305012$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1182648757 = ComposableLambdaKt.composableLambdaInstance(1182648757, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda_1182648757$lambda$1((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1413280596 = ComposableLambdaKt.composableLambdaInstance(1413280596, false, new Function2() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainActivityKt.lambda_1413280596$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-539564725, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f93lambda$539564725 = ComposableLambdaKt.composableLambdaInstance(-539564725, false, new Function2() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainActivityKt.lambda__539564725$lambda$3((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-1735940539, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f89lambda$1735940539 = ComposableLambdaKt.composableLambdaInstance(-1735940539, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda__1735940539$lambda$4((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$928595982 = ComposableLambdaKt.composableLambdaInstance(928595982, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda_928595982$lambda$5((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-4752315, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f92lambda$4752315 = ComposableLambdaKt.composableLambdaInstance(-4752315, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda__4752315$lambda$6((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$204786346 = ComposableLambdaKt.composableLambdaInstance(204786346, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda_204786346$lambda$7((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-300793658, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f91lambda$300793658 = ComposableLambdaKt.composableLambdaInstance(-300793658, false, new Function3() { // from class: com.example.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainActivityKt.lambda__300793658$lambda$8((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1735940539$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6948getLambda$1735940539$app() {
        return f89lambda$1735940539;
    }

    /* JADX INFO: renamed from: getLambda$-1992305012$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6949getLambda$1992305012$app() {
        return f90lambda$1992305012;
    }

    /* JADX INFO: renamed from: getLambda$-300793658$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6950getLambda$300793658$app() {
        return f91lambda$300793658;
    }

    /* JADX INFO: renamed from: getLambda$-4752315$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6951getLambda$4752315$app() {
        return f92lambda$4752315;
    }

    /* JADX INFO: renamed from: getLambda$-539564725$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6952getLambda$539564725$app() {
        return f93lambda$539564725;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1182648757$app() {
        return lambda$1182648757;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1413280596$app() {
        return lambda$1413280596;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$204786346$app() {
        return lambda$204786346;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$928595982$app() {
        return lambda$928595982;
    }

    static final Unit lambda__1992305012$lambda$0(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C117@4571L34:MainActivity.kt#to5c3");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1992305012, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$-1992305012.<anonymous> (MainActivity.kt:117)");
            }
            TextKt.m2693Text4IGK_g("Password", (Modifier) null, ColorKt.getSlate400(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 390, 0, 131066);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1182648757$lambda$1(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C147@5774L97:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1182648757, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$1182648757.<anonymous> (MainActivity.kt:147)");
            }
            TextKt.m2693Text4IGK_g("Unlock Dashboard", (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(15), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200070, 0, 131026);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1413280596$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C295@11998L62:MainActivity.kt#to5c3");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1413280596, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$1413280596.<anonymous> (MainActivity.kt:295)");
            }
            TextKt.m2693Text4IGK_g("Telegram Bot Token", (Modifier) null, ColorKt.getSlate500(), TextUnitKt.getSp(14), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3462, 0, 131058);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__539564725$lambda$3(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C311@12727L60:MainActivity.kt#to5c3");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-539564725, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$-539564725.<anonymous> (MainActivity.kt:311)");
            }
            TextKt.m2693Text4IGK_g("Telegram Chat ID", (Modifier) null, ColorKt.getSlate500(), TextUnitKt.getSp(14), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3462, 0, 131058);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1735940539$lambda$4(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C340@14059L68:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1735940539, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$-1735940539.<anonymous> (MainActivity.kt:340)");
            }
            TextKt.m2693Text4IGK_g("Grant Required Permissions", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 196614, 0, 131038);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_928595982$lambda$5(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C376@15945L72:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(928595982, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$928595982.<anonymous> (MainActivity.kt:376)");
            }
            TextKt.m2693Text4IGK_g("Usage Access", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__4752315$lambda$6(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C392@16729L73:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-4752315, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$-4752315.<anonymous> (MainActivity.kt:392)");
            }
            TextKt.m2693Text4IGK_g("Notifications", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_204786346$lambda$7(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C426@18613L88:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(204786346, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$204786346.<anonymous> (MainActivity.kt:426)");
            }
            TextKt.m2693Text4IGK_g("Disable Battery Optimization", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__300793658$lambda$8(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C456@20292L61:MainActivity.kt#to5c3");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-300793658, $changed, -1, "com.example.ComposableSingletons$MainActivityKt.lambda$-300793658.<anonymous> (MainActivity.kt:456)");
            }
            TextKt.m2693Text4IGK_g("Enable Device Admin", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 196614, 0, 131038);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
