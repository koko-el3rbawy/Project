package com.example.services;

import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import dagger.MembersInjector;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes5.dex */
public final class LocationForegroundService_MembersInjector implements MembersInjector<LocationForegroundService> {
    private final Provider<TelegramDashboardManager> dashboardManagerProvider;
    private final Provider<AppDatabase> dbProvider;
    private final Provider<TelegramBotClient> telegramClientProvider;

    public LocationForegroundService_MembersInjector(Provider<TelegramBotClient> telegramClientProvider, Provider<TelegramDashboardManager> dashboardManagerProvider, Provider<AppDatabase> dbProvider) {
        this.telegramClientProvider = telegramClientProvider;
        this.dashboardManagerProvider = dashboardManagerProvider;
        this.dbProvider = dbProvider;
    }

    public static MembersInjector<LocationForegroundService> create(Provider<TelegramBotClient> telegramClientProvider, Provider<TelegramDashboardManager> dashboardManagerProvider, Provider<AppDatabase> dbProvider) {
        return new LocationForegroundService_MembersInjector(telegramClientProvider, dashboardManagerProvider, dbProvider);
    }

    @Override // dagger.MembersInjector
    public void injectMembers(LocationForegroundService instance) {
        injectTelegramClient(instance, this.telegramClientProvider.get());
        injectDashboardManager(instance, this.dashboardManagerProvider.get());
        injectDb(instance, this.dbProvider.get());
    }

    public static void injectTelegramClient(LocationForegroundService instance, TelegramBotClient telegramClient) {
        instance.telegramClient = telegramClient;
    }

    public static void injectDashboardManager(LocationForegroundService instance, TelegramDashboardManager dashboardManager) {
        instance.dashboardManager = dashboardManager;
    }

    public static void injectDb(LocationForegroundService instance, AppDatabase db) {
        instance.db = db;
    }
}
