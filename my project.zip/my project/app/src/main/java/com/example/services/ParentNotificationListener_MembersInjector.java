package com.example.services;

import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.repository.SettingsRepository;
import dagger.MembersInjector;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes5.dex */
public final class ParentNotificationListener_MembersInjector implements MembersInjector<ParentNotificationListener> {
    private final Provider<AppDatabase> dbProvider;
    private final Provider<SettingsRepository> settingsProvider;
    private final Provider<TelegramBotClient> telegramClientProvider;

    public ParentNotificationListener_MembersInjector(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider, Provider<SettingsRepository> settingsProvider) {
        this.telegramClientProvider = telegramClientProvider;
        this.dbProvider = dbProvider;
        this.settingsProvider = settingsProvider;
    }

    public static MembersInjector<ParentNotificationListener> create(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider, Provider<SettingsRepository> settingsProvider) {
        return new ParentNotificationListener_MembersInjector(telegramClientProvider, dbProvider, settingsProvider);
    }

    @Override // dagger.MembersInjector
    public void injectMembers(ParentNotificationListener instance) {
        injectTelegramClient(instance, this.telegramClientProvider.get());
        injectDb(instance, this.dbProvider.get());
        injectSettings(instance, this.settingsProvider.get());
    }

    public static void injectTelegramClient(ParentNotificationListener instance, TelegramBotClient telegramClient) {
        instance.telegramClient = telegramClient;
    }

    public static void injectDb(ParentNotificationListener instance, AppDatabase db) {
        instance.db = db;
    }

    public static void injectSettings(ParentNotificationListener instance, SettingsRepository settings) {
        instance.settings = settings;
    }
}
