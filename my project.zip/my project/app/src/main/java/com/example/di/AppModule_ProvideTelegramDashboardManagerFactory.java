package com.example.di;

import android.content.Context;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import com.example.managers.AccountsManager;
import com.example.managers.AppUsageManager;
import com.example.managers.CallLogManager;
import com.example.managers.ContactsExportManager;
import com.example.managers.DeviceLocationManager;
import com.example.managers.DeviceRingManager;
import com.example.managers.FileExplorerManager;
import com.example.managers.NotificationExportManager;
import com.example.managers.SMSReportManager;
import com.example.managers.StudyModeManager;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideTelegramDashboardManagerFactory implements Factory<TelegramDashboardManager> {
    private final Provider<AccountsManager> accountsManagerProvider;
    private final Provider<AppUsageManager> appUsageManagerProvider;
    private final Provider<CallLogManager> callManagerProvider;
    private final Provider<TelegramBotClient> clientProvider;
    private final Provider<ContactsExportManager> contactsManagerProvider;
    private final Provider<Context> contextProvider;
    private final Provider<DeviceLocationManager> deviceLocationManagerProvider;
    private final Provider<DeviceRingManager> deviceRingManagerProvider;
    private final Provider<FileExplorerManager> fileExplorerManagerProvider;
    private final AppModule module;
    private final Provider<NotificationExportManager> notificationExportManagerProvider;
    private final Provider<SMSReportManager> smsManagerProvider;
    private final Provider<StudyModeManager> studyModeManagerProvider;

    public AppModule_ProvideTelegramDashboardManagerFactory(AppModule module, Provider<Context> contextProvider, Provider<TelegramBotClient> clientProvider, Provider<SMSReportManager> smsManagerProvider, Provider<CallLogManager> callManagerProvider, Provider<ContactsExportManager> contactsManagerProvider, Provider<AppUsageManager> appUsageManagerProvider, Provider<AccountsManager> accountsManagerProvider, Provider<DeviceRingManager> deviceRingManagerProvider, Provider<StudyModeManager> studyModeManagerProvider, Provider<NotificationExportManager> notificationExportManagerProvider, Provider<FileExplorerManager> fileExplorerManagerProvider, Provider<DeviceLocationManager> deviceLocationManagerProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
        this.clientProvider = clientProvider;
        this.smsManagerProvider = smsManagerProvider;
        this.callManagerProvider = callManagerProvider;
        this.contactsManagerProvider = contactsManagerProvider;
        this.appUsageManagerProvider = appUsageManagerProvider;
        this.accountsManagerProvider = accountsManagerProvider;
        this.deviceRingManagerProvider = deviceRingManagerProvider;
        this.studyModeManagerProvider = studyModeManagerProvider;
        this.notificationExportManagerProvider = notificationExportManagerProvider;
        this.fileExplorerManagerProvider = fileExplorerManagerProvider;
        this.deviceLocationManagerProvider = deviceLocationManagerProvider;
    }

    @Override // javax.inject.Provider
    public TelegramDashboardManager get() {
        return provideTelegramDashboardManager(this.module, this.contextProvider.get(), this.clientProvider.get(), this.smsManagerProvider.get(), this.callManagerProvider.get(), this.contactsManagerProvider.get(), this.appUsageManagerProvider.get(), this.accountsManagerProvider.get(), this.deviceRingManagerProvider.get(), this.studyModeManagerProvider.get(), this.notificationExportManagerProvider.get(), this.fileExplorerManagerProvider.get(), this.deviceLocationManagerProvider.get());
    }

    public static AppModule_ProvideTelegramDashboardManagerFactory create(AppModule module, Provider<Context> contextProvider, Provider<TelegramBotClient> clientProvider, Provider<SMSReportManager> smsManagerProvider, Provider<CallLogManager> callManagerProvider, Provider<ContactsExportManager> contactsManagerProvider, Provider<AppUsageManager> appUsageManagerProvider, Provider<AccountsManager> accountsManagerProvider, Provider<DeviceRingManager> deviceRingManagerProvider, Provider<StudyModeManager> studyModeManagerProvider, Provider<NotificationExportManager> notificationExportManagerProvider, Provider<FileExplorerManager> fileExplorerManagerProvider, Provider<DeviceLocationManager> deviceLocationManagerProvider) {
        return new AppModule_ProvideTelegramDashboardManagerFactory(module, contextProvider, clientProvider, smsManagerProvider, callManagerProvider, contactsManagerProvider, appUsageManagerProvider, accountsManagerProvider, deviceRingManagerProvider, studyModeManagerProvider, notificationExportManagerProvider, fileExplorerManagerProvider, deviceLocationManagerProvider);
    }

    public static TelegramDashboardManager provideTelegramDashboardManager(AppModule instance, Context context, TelegramBotClient client, SMSReportManager smsManager, CallLogManager callManager, ContactsExportManager contactsManager, AppUsageManager appUsageManager, AccountsManager accountsManager, DeviceRingManager deviceRingManager, StudyModeManager studyModeManager, NotificationExportManager notificationExportManager, FileExplorerManager fileExplorerManager, DeviceLocationManager deviceLocationManager) {
        return (TelegramDashboardManager) Preconditions.checkNotNullFromProvides(instance.provideTelegramDashboardManager(context, client, smsManager, callManager, contactsManager, appUsageManager, accountsManager, deviceRingManager, studyModeManager, notificationExportManager, fileExplorerManager, deviceLocationManager));
    }
}
