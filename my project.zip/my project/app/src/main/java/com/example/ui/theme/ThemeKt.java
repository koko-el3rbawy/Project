package com.example.ui.theme;

import androidx.compose.foundation.DarkThemeKt;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.graphics.Color;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a4\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\u0011\u0010\u0007\u001a\r\u0012\u0004\u0012\u00020\u00030\b¢\u0006\u0002\b\tH\u0007¢\u0006\u0002\u0010\n\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"LightColorScheme", "Landroidx/compose/material3/ColorScheme;", "MyApplicationTheme", "", "darkTheme", "", "dynamicColor", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ThemeKt {
    private static final ColorScheme LightColorScheme = ColorSchemeKt.m1936lightColorSchemeCXl9yA$default(ColorKt.getBlue600(), Color.INSTANCE.m4196getWhite0d7_KjU(), Color.INSTANCE.m4196getWhite0d7_KjU(), ColorKt.getSlate900(), 0, ColorKt.getEmerald600(), 0, 0, 0, 0, 0, 0, 0, ColorKt.getGray100(), ColorKt.getSlate900(), Color.INSTANCE.m4196getWhite0d7_KjU(), ColorKt.getSlate900(), Color.INSTANCE.m4196getWhite0d7_KjU(), ColorKt.getSlate500(), 0, 0, 0, 0, 0, 0, 0, ColorKt.getSlate200(), 0, 0, 0, 0, 0, 0, 0, 0, 0, -67625008, 15, null);

    static final Unit MyApplicationTheme$lambda$0(boolean z, boolean z2, Function2 function2, int i, int i2, Composer composer, int i3) {
        MyApplicationTheme(z, z2, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    public static final void MyApplicationTheme(boolean darkTheme, boolean dynamicColor, final Function2<? super Composer, ? super Integer, Unit> content, Composer $composer, final int $changed, final int i) {
        boolean darkTheme2;
        boolean dynamicColor2;
        int $dirty;
        boolean darkTheme3;
        Composer $composer2;
        final boolean darkTheme4;
        final boolean dynamicColor3;
        Intrinsics.checkNotNullParameter(content, "content");
        Composer $composer3 = $composer.startRestartGroup(548420513);
        ComposerKt.sourceInformation($composer3, "C(MyApplicationTheme)P(1,2)37@1150L84:Theme.kt#75kw8w");
        int $dirty2 = $changed;
        if (($changed & 384) == 0) {
            $dirty2 |= $composer3.changedInstance(content) ? 256 : 128;
        }
        if (($dirty2 & 129) == 128 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            dynamicColor3 = dynamicColor;
            $composer2 = $composer3;
            darkTheme4 = darkTheme;
        } else {
            $composer3.startDefaults();
            ComposerKt.sourceInformation($composer3, "30@968L21");
            if (($changed & 1) == 0 || $composer3.getDefaultsInvalid()) {
                if ((i & 1) != 0) {
                    darkTheme2 = DarkThemeKt.isSystemInDarkTheme($composer3, 0);
                    $dirty2 &= -15;
                } else {
                    darkTheme2 = darkTheme;
                }
                if ((i & 2) != 0) {
                    $dirty = $dirty2;
                    darkTheme3 = darkTheme2;
                    dynamicColor2 = false;
                } else {
                    dynamicColor2 = dynamicColor;
                    $dirty = $dirty2;
                    darkTheme3 = darkTheme2;
                }
            } else {
                $composer3.skipToGroupEnd();
                if ((i & 1) != 0) {
                    $dirty2 &= -15;
                }
                darkTheme3 = darkTheme;
                dynamicColor2 = dynamicColor;
                $dirty = $dirty2;
            }
            $composer3.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(548420513, $dirty, -1, "com.example.ui.theme.MyApplicationTheme (Theme.kt:34)");
            }
            ColorScheme colorScheme = LightColorScheme;
            MaterialThemeKt.MaterialTheme(colorScheme, null, TypeKt.getTypography(), content, $composer3, (($dirty << 3) & 7168) | 390, 2);
            $composer2 = $composer3;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            darkTheme4 = darkTheme3;
            dynamicColor3 = dynamicColor2;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ThemeKt.MyApplicationTheme$lambda$0(darkTheme4, dynamicColor3, content, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }
}
