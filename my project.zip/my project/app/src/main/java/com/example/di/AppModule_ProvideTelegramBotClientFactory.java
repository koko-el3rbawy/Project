package com.example.di;

import com.example.data.remote.TelegramBotClient;
import com.example.data.repository.SettingsRepository;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideTelegramBotClientFactory implements Factory<TelegramBotClient> {
    private final AppModule module;
    private final Provider<SettingsRepository> settingsRepositoryProvider;

    public AppModule_ProvideTelegramBotClientFactory(AppModule module, Provider<SettingsRepository> settingsRepositoryProvider) {
        this.module = module;
        this.settingsRepositoryProvider = settingsRepositoryProvider;
    }

    @Override // javax.inject.Provider
    public TelegramBotClient get() {
        return provideTelegramBotClient(this.module, this.settingsRepositoryProvider.get());
    }

    public static AppModule_ProvideTelegramBotClientFactory create(AppModule module, Provider<SettingsRepository> settingsRepositoryProvider) {
        return new AppModule_ProvideTelegramBotClientFactory(module, settingsRepositoryProvider);
    }

    public static TelegramBotClient provideTelegramBotClient(AppModule instance, SettingsRepository settingsRepository) {
        return (TelegramBotClient) Preconditions.checkNotNullFromProvides(instance.provideTelegramBotClient(settingsRepository));
    }
}
