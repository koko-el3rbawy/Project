package com.example.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import java.io.IOException;
import java.security.GeneralSecurityException;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: SettingsRepository.kt */
/* JADX INFO: loaded from: classes8.dex */
@Singleton
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R(\u0010\f\u001a\u0004\u0018\u00010\u000b2\b\u0010\n\u001a\u0004\u0018\u00010\u000b8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R(\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\b\u0010\n\u001a\u0004\u0018\u00010\u000b8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0012\u0010\u000e\"\u0004\b\u0013\u0010\u0010R$\u0010\u0015\u001a\u00020\u00142\u0006\u0010\n\u001a\u00020\u00148F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018¨\u0006\u0019"}, d2 = {"Lcom/example/data/repository/SettingsRepository;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "masterKey", "Landroidx/security/crypto/MasterKey;", "sharedPrefs", "Landroid/content/SharedPreferences;", "value", "", "botToken", "getBotToken", "()Ljava/lang/String;", "setBotToken", "(Ljava/lang/String;)V", "chatId", "getChatId", "setChatId", "", "isMonitoringActive", "()Z", "setMonitoringActive", "(Z)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class SettingsRepository {
    public static final int $stable = 8;
    private final MasterKey masterKey;
    private final SharedPreferences sharedPrefs;

    @Inject
    public SettingsRepository(Context context) throws GeneralSecurityException, IOException {
        Intrinsics.checkNotNullParameter(context, "context");
        MasterKey masterKeyBuild = new MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        Intrinsics.checkNotNullExpressionValue(masterKeyBuild, "build(...)");
        this.masterKey = masterKeyBuild;
        SharedPreferences sharedPreferencesCreate = EncryptedSharedPreferences.create(context, "secure_settings", this.masterKey, EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        Intrinsics.checkNotNullExpressionValue(sharedPreferencesCreate, "create(...)");
        this.sharedPrefs = sharedPreferencesCreate;
    }

    public final String getBotToken() {
        return this.sharedPrefs.getString("botToken", null);
    }

    public final void setBotToken(String value) {
        this.sharedPrefs.edit().putString("botToken", value).apply();
    }

    public final String getChatId() {
        return this.sharedPrefs.getString("chatId", null);
    }

    public final void setChatId(String value) {
        this.sharedPrefs.edit().putString("chatId", value).apply();
    }

    public final boolean isMonitoringActive() {
        return this.sharedPrefs.getBoolean("isMonitoringActive", false);
    }

    public final void setMonitoringActive(boolean value) {
        this.sharedPrefs.edit().putBoolean("isMonitoringActive", value).apply();
    }
}
