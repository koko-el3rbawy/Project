package com.example.di;

import android.content.Context;
import com.example.utils.BatteryOptimizationHelper;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideBatteryOptimizationHelperFactory implements Factory<BatteryOptimizationHelper> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideBatteryOptimizationHelperFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public BatteryOptimizationHelper get() {
        return provideBatteryOptimizationHelper(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideBatteryOptimizationHelperFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideBatteryOptimizationHelperFactory(module, contextProvider);
    }

    public static BatteryOptimizationHelper provideBatteryOptimizationHelper(AppModule instance, Context context) {
        return (BatteryOptimizationHelper) Preconditions.checkNotNullFromProvides(instance.provideBatteryOptimizationHelper(context));
    }
}
