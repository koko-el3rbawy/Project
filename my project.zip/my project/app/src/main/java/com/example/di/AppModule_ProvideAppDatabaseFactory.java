package com.example.di;

import android.content.Context;
import com.example.data.local.AppDatabase;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideAppDatabaseFactory implements Factory<AppDatabase> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideAppDatabaseFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public AppDatabase get() {
        return provideAppDatabase(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideAppDatabaseFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideAppDatabaseFactory(module, contextProvider);
    }

    public static AppDatabase provideAppDatabase(AppModule instance, Context context) {
        return (AppDatabase) Preconditions.checkNotNullFromProvides(instance.provideAppDatabase(context));
    }
}
