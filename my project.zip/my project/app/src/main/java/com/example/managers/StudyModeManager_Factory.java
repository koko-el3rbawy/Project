package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class StudyModeManager_Factory implements Factory<StudyModeManager> {
    private final Provider<Context> contextProvider;

    public StudyModeManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public StudyModeManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static StudyModeManager_Factory create(Provider<Context> contextProvider) {
        return new StudyModeManager_Factory(contextProvider);
    }

    public static StudyModeManager newInstance(Context context) {
        return new StudyModeManager(context);
    }
}
