package com.example.di;

import android.content.Context;
import com.example.data.repository.SettingsRepository;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideSettingsRepositoryFactory implements Factory<SettingsRepository> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideSettingsRepositoryFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public SettingsRepository get() {
        return provideSettingsRepository(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideSettingsRepositoryFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideSettingsRepositoryFactory(module, contextProvider);
    }

    public static SettingsRepository provideSettingsRepository(AppModule instance, Context context) {
        return (SettingsRepository) Preconditions.checkNotNullFromProvides(instance.provideSettingsRepository(context));
    }
}
