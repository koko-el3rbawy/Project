package com.example.managers;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import androidx.compose.material3.internal.CalendarModelKt;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: SMSReportManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/example/managers/SMSReportManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "generateReport", "Ljava/io/File;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class SMSReportManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public SMSReportManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final File generateReport() {
        File reportFile = new File(this.context.getCacheDir(), "sms_report_" + System.currentTimeMillis() + ".txt");
        StringBuilder sb = new StringBuilder();
        sb.append("SMS REPORT\n");
        sb.append("========================\n\n");
        long timeLimit = System.currentTimeMillis() - CalendarModelKt.MillisecondsIn24Hours;
        try {
            Cursor cursor = this.context.getContentResolver().query(Uri.parse("content://sms"), new String[]{"address", "date", "type", "body"}, "date >= ?", new String[]{String.valueOf(timeLimit)}, "date DESC");
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor cursor3 = cursor2;
                    int columnIndex = cursor3.getColumnIndex("address");
                    int columnIndex2 = cursor3.getColumnIndex("date");
                    int columnIndex3 = cursor3.getColumnIndex("type");
                    int columnIndex4 = cursor3.getColumnIndex("body");
                    while (cursor3.moveToNext()) {
                        String string = cursor3.getString(columnIndex);
                        long j = cursor3.getLong(columnIndex2);
                        int i = cursor3.getInt(columnIndex3);
                        String string2 = cursor3.getString(columnIndex4);
                        int i2 = columnIndex4;
                        int i3 = columnIndex3;
                        String str = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault()).format(new Date(j));
                        String str2 = i == 1 ? "Incoming" : "Outgoing";
                        sb.append("From: " + string + "\n");
                        sb.append("Time: " + str + "\n");
                        sb.append("Message Type: " + str2 + "\n");
                        sb.append("Content: " + string2 + "\n");
                        sb.append("========================\n\n");
                        columnIndex2 = columnIndex2;
                        columnIndex4 = i2;
                        columnIndex3 = i3;
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, null);
                } finally {
                }
            }
            String string3 = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string3, "toString(...)");
            FilesKt.writeText$default(reportFile, string3, null, 2, null);
            return reportFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
