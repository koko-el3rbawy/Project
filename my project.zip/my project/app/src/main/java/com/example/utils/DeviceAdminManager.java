package com.example.utils;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import com.example.receivers.AdminReceiver;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: DeviceAdminManager.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\n\u001a\u00020\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/example/utils/DeviceAdminManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "dpm", "Landroid/app/admin/DevicePolicyManager;", "componentName", "Landroid/content/ComponentName;", "isAdminActive", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class DeviceAdminManager {
    public static final int $stable = 8;
    private final ComponentName componentName;
    private final Context context;
    private final DevicePolicyManager dpm;

    public DeviceAdminManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        Object systemService = this.context.getSystemService("device_policy");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.admin.DevicePolicyManager");
        this.dpm = (DevicePolicyManager) systemService;
        this.componentName = new ComponentName(this.context, (Class<?>) AdminReceiver.class);
    }

    public final boolean isAdminActive() {
        return this.dpm.isAdminActive(this.componentName);
    }
}
