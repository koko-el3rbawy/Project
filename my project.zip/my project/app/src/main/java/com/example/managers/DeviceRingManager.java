package com.example.managers;

import android.content.Context;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: DeviceRingManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0086@¢\u0006\u0002\u0010\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/example/managers/DeviceRingManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "ringDevice", "", "durationSeconds", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class DeviceRingManager {
    public static final int $stable = 8;
    private final Context context;

    /* JADX INFO: renamed from: com.example.managers.DeviceRingManager$ringDevice$1, reason: invalid class name */
    /* JADX INFO: compiled from: DeviceRingManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.managers.DeviceRingManager", f = "DeviceRingManager.kt", i = {0, 0, 0, 0, 0, 0}, l = {25}, m = "ringDevice", n = {"audioManager", "uri", "ringtone", "durationSeconds", "originalVolume", "maxVolume"}, s = {"L$0", "L$1", "L$2", "I$0", "I$1", "I$2"})
    static final class AnonymousClass1 extends ContinuationImpl {
        int I$0;
        int I$1;
        int I$2;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return DeviceRingManager.this.ringDevice(0, this);
        }
    }

    @Inject
    public DeviceRingManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public static /* synthetic */ Object ringDevice$default(DeviceRingManager deviceRingManager, int i, Continuation continuation, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = 15;
        }
        return deviceRingManager.ringDevice(i, continuation);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object ringDevice(int r19, kotlin.coroutines.Continuation<? super kotlin.Unit> r20) {
        /*
            r18 = this;
            r1 = r18
            r2 = r19
            r3 = r20
            boolean r0 = r3 instanceof com.example.managers.DeviceRingManager.AnonymousClass1
            if (r0 == 0) goto L1a
            r0 = r3
            com.example.managers.DeviceRingManager$ringDevice$1 r0 = (com.example.managers.DeviceRingManager.AnonymousClass1) r0
            int r4 = r0.label
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r4 & r5
            if (r4 == 0) goto L1a
            int r4 = r0.label
            int r4 = r4 - r5
            r0.label = r4
            goto L1f
        L1a:
            com.example.managers.DeviceRingManager$ringDevice$1 r0 = new com.example.managers.DeviceRingManager$ringDevice$1
            r0.<init>(r3)
        L1f:
            r4 = r0
            java.lang.Object r5 = r4.result
            java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r6 = r4.label
            r7 = 0
            r8 = 2
            switch(r6) {
                case 0: goto L4d;
                case 1: goto L35;
                default: goto L2d;
            }
        L2d:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r4)
            throw r0
        L35:
            int r0 = r4.I$2
            int r6 = r4.I$1
            int r2 = r4.I$0
            java.lang.Object r9 = r4.L$2
            android.media.Ringtone r9 = (android.media.Ringtone) r9
            java.lang.Object r10 = r4.L$1
            android.net.Uri r10 = (android.net.Uri) r10
            java.lang.Object r11 = r4.L$0
            android.media.AudioManager r11 = (android.media.AudioManager) r11
            kotlin.ResultKt.throwOnFailure(r5)     // Catch: java.lang.Exception -> L4b
            goto L9b
        L4b:
            r0 = move-exception
            goto La4
        L4d:
            kotlin.ResultKt.throwOnFailure(r5)
            android.content.Context r6 = r1.context     // Catch: java.lang.Exception -> La3
            java.lang.String r9 = "audio"
            java.lang.Object r6 = r6.getSystemService(r9)     // Catch: java.lang.Exception -> La3
            java.lang.String r9 = "null cannot be cast to non-null type android.media.AudioManager"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6, r9)     // Catch: java.lang.Exception -> La3
            android.media.AudioManager r6 = (android.media.AudioManager) r6     // Catch: java.lang.Exception -> La3
            r11 = r6
            int r6 = r11.getStreamVolume(r8)     // Catch: java.lang.Exception -> La3
            int r9 = r11.getStreamMaxVolume(r8)     // Catch: java.lang.Exception -> La3
            r11.setStreamVolume(r8, r9, r7)     // Catch: java.lang.Exception -> La3
            r10 = 1
            android.net.Uri r12 = android.media.RingtoneManager.getDefaultUri(r10)     // Catch: java.lang.Exception -> La3
            android.content.Context r13 = r1.context     // Catch: java.lang.Exception -> La3
            android.media.Ringtone r13 = android.media.RingtoneManager.getRingtone(r13, r12)     // Catch: java.lang.Exception -> La3
            r13.play()     // Catch: java.lang.Exception -> La3
            long r14 = (long) r2     // Catch: java.lang.Exception -> La3
            r16 = 1000(0x3e8, double:4.94E-321)
            long r14 = r14 * r16
            r4.L$0 = r11     // Catch: java.lang.Exception -> La3
            java.lang.Object r7 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(r12)     // Catch: java.lang.Exception -> La3
            r4.L$1 = r7     // Catch: java.lang.Exception -> La3
            r4.L$2 = r13     // Catch: java.lang.Exception -> La3
            r4.I$0 = r2     // Catch: java.lang.Exception -> La3
            r4.I$1 = r6     // Catch: java.lang.Exception -> La3
            r4.I$2 = r9     // Catch: java.lang.Exception -> La3
            r4.label = r10     // Catch: java.lang.Exception -> La3
            java.lang.Object r7 = kotlinx.coroutines.DelayKt.delay(r14, r4)     // Catch: java.lang.Exception -> La3
            if (r7 != r0) goto L98
            return r0
        L98:
            r0 = r9
            r10 = r12
            r9 = r13
        L9b:
            r9.stop()     // Catch: java.lang.Exception -> L4b
            r7 = 0
            r11.setStreamVolume(r8, r6, r7)     // Catch: java.lang.Exception -> L4b
            goto La7
        La3:
            r0 = move-exception
        La4:
            r0.printStackTrace()
        La7:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.managers.DeviceRingManager.ringDevice(int, kotlin.coroutines.Continuation):java.lang.Object");
    }
}
