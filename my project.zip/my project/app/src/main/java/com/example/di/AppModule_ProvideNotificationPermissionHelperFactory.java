package com.example.di;

import android.content.Context;
import com.example.utils.NotificationPermissionHelper;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideNotificationPermissionHelperFactory implements Factory<NotificationPermissionHelper> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideNotificationPermissionHelperFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public NotificationPermissionHelper get() {
        return provideNotificationPermissionHelper(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideNotificationPermissionHelperFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideNotificationPermissionHelperFactory(module, contextProvider);
    }

    public static NotificationPermissionHelper provideNotificationPermissionHelper(AppModule instance, Context context) {
        return (NotificationPermissionHelper) Preconditions.checkNotNullFromProvides(instance.provideNotificationPermissionHelper(context));
    }
}
