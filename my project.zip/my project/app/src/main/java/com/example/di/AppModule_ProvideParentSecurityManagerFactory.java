package com.example.di;

import android.content.Context;
import com.example.security.ParentSecurityManager;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class AppModule_ProvideParentSecurityManagerFactory implements Factory<ParentSecurityManager> {
    private final Provider<Context> contextProvider;
    private final AppModule module;

    public AppModule_ProvideParentSecurityManagerFactory(AppModule module, Provider<Context> contextProvider) {
        this.module = module;
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public ParentSecurityManager get() {
        return provideParentSecurityManager(this.module, this.contextProvider.get());
    }

    public static AppModule_ProvideParentSecurityManagerFactory create(AppModule module, Provider<Context> contextProvider) {
        return new AppModule_ProvideParentSecurityManagerFactory(module, contextProvider);
    }

    public static ParentSecurityManager provideParentSecurityManager(AppModule instance, Context context) {
        return (ParentSecurityManager) Preconditions.checkNotNullFromProvides(instance.provideParentSecurityManager(context));
    }
}
