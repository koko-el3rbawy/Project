package com.example;

import android.app.Application;
import androidx.work.Configuration;
import com.example.di.AppComponent;
import com.example.di.AppModule;
import com.example.di.DaggerAppComponent;
import com.example.utils.ReliableWorkerManager;
import com.example.work.CustomWorkerFactory;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ParentalApp.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\b\u0010\u0011\u001a\u00020\u0012H\u0016R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001e\u0010\u000b\u001a\u00020\f8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0013\u001a\u00020\u00148VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Lcom/example/ParentalApp;", "Landroid/app/Application;", "Landroidx/work/Configuration$Provider;", "<init>", "()V", "appComponent", "Lcom/example/di/AppComponent;", "getAppComponent", "()Lcom/example/di/AppComponent;", "setAppComponent", "(Lcom/example/di/AppComponent;)V", "workerFactory", "Lcom/example/work/CustomWorkerFactory;", "getWorkerFactory", "()Lcom/example/work/CustomWorkerFactory;", "setWorkerFactory", "(Lcom/example/work/CustomWorkerFactory;)V", "onCreate", "", "workManagerConfiguration", "Landroidx/work/Configuration;", "getWorkManagerConfiguration", "()Landroidx/work/Configuration;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ParentalApp extends Application implements Configuration.Provider {
    public static final int $stable = 8;
    public AppComponent appComponent;

    @Inject
    public CustomWorkerFactory workerFactory;

    public final AppComponent getAppComponent() {
        AppComponent appComponent = this.appComponent;
        if (appComponent != null) {
            return appComponent;
        }
        Intrinsics.throwUninitializedPropertyAccessException("appComponent");
        return null;
    }

    public final void setAppComponent(AppComponent appComponent) {
        Intrinsics.checkNotNullParameter(appComponent, "<set-?>");
        this.appComponent = appComponent;
    }

    public final CustomWorkerFactory getWorkerFactory() {
        CustomWorkerFactory customWorkerFactory = this.workerFactory;
        if (customWorkerFactory != null) {
            return customWorkerFactory;
        }
        Intrinsics.throwUninitializedPropertyAccessException("workerFactory");
        return null;
    }

    public final void setWorkerFactory(CustomWorkerFactory customWorkerFactory) {
        Intrinsics.checkNotNullParameter(customWorkerFactory, "<set-?>");
        this.workerFactory = customWorkerFactory;
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        AppComponent appComponentBuild = DaggerAppComponent.builder().appModule(new AppModule(this)).build();
        Intrinsics.checkNotNullExpressionValue(appComponentBuild, "build(...)");
        setAppComponent(appComponentBuild);
        getAppComponent().inject(this);
        new ReliableWorkerManager(this).setupReliableWorkers();
    }

    @Override // androidx.work.Configuration.Provider
    public Configuration getWorkManagerConfiguration() {
        return new Configuration.Builder().setWorkerFactory(getWorkerFactory()).build();
    }
}
