package com.example.data.repository;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes8.dex */
public final class SettingsRepository_Factory implements Factory<SettingsRepository> {
    private final Provider<Context> contextProvider;

    public SettingsRepository_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public SettingsRepository get() {
        return newInstance(this.contextProvider.get());
    }

    public static SettingsRepository_Factory create(Provider<Context> contextProvider) {
        return new SettingsRepository_Factory(contextProvider);
    }

    public static SettingsRepository newInstance(Context context) {
        return new SettingsRepository(context);
    }
}
