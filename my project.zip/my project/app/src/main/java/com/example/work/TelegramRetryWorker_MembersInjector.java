package com.example.work;

import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import dagger.MembersInjector;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class TelegramRetryWorker_MembersInjector implements MembersInjector<TelegramRetryWorker> {
    private final Provider<AppDatabase> dbProvider;
    private final Provider<TelegramBotClient> telegramClientProvider;

    public TelegramRetryWorker_MembersInjector(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider) {
        this.telegramClientProvider = telegramClientProvider;
        this.dbProvider = dbProvider;
    }

    public static MembersInjector<TelegramRetryWorker> create(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider) {
        return new TelegramRetryWorker_MembersInjector(telegramClientProvider, dbProvider);
    }

    @Override // dagger.MembersInjector
    public void injectMembers(TelegramRetryWorker instance) {
        injectTelegramClient(instance, this.telegramClientProvider.get());
        injectDb(instance, this.dbProvider.get());
    }

    public static void injectTelegramClient(TelegramRetryWorker instance, TelegramBotClient telegramClient) {
        instance.telegramClient = telegramClient;
    }

    public static void injectDb(TelegramRetryWorker instance, AppDatabase db) {
        instance.db = db;
    }
}
