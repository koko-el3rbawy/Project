package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class OEMCompatibilityManager_Factory implements Factory<OEMCompatibilityManager> {
    private final Provider<Context> contextProvider;

    public OEMCompatibilityManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public OEMCompatibilityManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static OEMCompatibilityManager_Factory create(Provider<Context> contextProvider) {
        return new OEMCompatibilityManager_Factory(contextProvider);
    }

    public static OEMCompatibilityManager newInstance(Context context) {
        return new OEMCompatibilityManager(context);
    }
}
