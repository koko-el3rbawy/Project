package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class ContactsExportManager_Factory implements Factory<ContactsExportManager> {
    private final Provider<Context> contextProvider;

    public ContactsExportManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public ContactsExportManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static ContactsExportManager_Factory create(Provider<Context> contextProvider) {
        return new ContactsExportManager_Factory(contextProvider);
    }

    public static ContactsExportManager newInstance(Context context) {
        return new ContactsExportManager(context);
    }
}
