package com.example.ui.theme;

import kotlin.Metadata;

/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001c\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003¨\u0006\u001d"}, d2 = {"Slate900", "Landroidx/compose/ui/graphics/Color;", "getSlate900", "()J", "J", "Slate800", "getSlate800", "Slate700", "getSlate700", "Slate500", "getSlate500", "Slate400", "getSlate400", "Slate200", "getSlate200", "Slate100", "getSlate100", "Gray100", "getGray100", "Blue500", "getBlue500", "Blue600", "getBlue600", "Emerald500", "getEmerald500", "Emerald600", "getEmerald600", "Rose500", "getRose500", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ColorKt {
    private static final long Slate900 = androidx.compose.ui.graphics.ColorKt.Color(4279179050L);
    private static final long Slate800 = androidx.compose.ui.graphics.ColorKt.Color(4280166715L);
    private static final long Slate700 = androidx.compose.ui.graphics.ColorKt.Color(4281549141L);
    private static final long Slate500 = androidx.compose.ui.graphics.ColorKt.Color(4284773515L);
    private static final long Slate400 = androidx.compose.ui.graphics.ColorKt.Color(4287931320L);
    private static final long Slate200 = androidx.compose.ui.graphics.ColorKt.Color(4293060848L);
    private static final long Slate100 = androidx.compose.ui.graphics.ColorKt.Color(4294047225L);
    private static final long Gray100 = androidx.compose.ui.graphics.ColorKt.Color(4294178038L);
    private static final long Blue500 = androidx.compose.ui.graphics.ColorKt.Color(4282090230L);
    private static final long Blue600 = androidx.compose.ui.graphics.ColorKt.Color(4280640491L);
    private static final long Emerald500 = androidx.compose.ui.graphics.ColorKt.Color(4279286145L);
    private static final long Emerald600 = androidx.compose.ui.graphics.ColorKt.Color(4278556265L);
    private static final long Rose500 = androidx.compose.ui.graphics.ColorKt.Color(4294197086L);

    public static final long getSlate900() {
        return Slate900;
    }

    public static final long getSlate800() {
        return Slate800;
    }

    public static final long getSlate700() {
        return Slate700;
    }

    public static final long getSlate500() {
        return Slate500;
    }

    public static final long getSlate400() {
        return Slate400;
    }

    public static final long getSlate200() {
        return Slate200;
    }

    public static final long getSlate100() {
        return Slate100;
    }

    public static final long getGray100() {
        return Gray100;
    }

    public static final long getBlue500() {
        return Blue500;
    }

    public static final long getBlue600() {
        return Blue600;
    }

    public static final long getEmerald500() {
        return Emerald500;
    }

    public static final long getEmerald600() {
        return Emerald600;
    }

    public static final long getRose500() {
        return Rose500;
    }
}
