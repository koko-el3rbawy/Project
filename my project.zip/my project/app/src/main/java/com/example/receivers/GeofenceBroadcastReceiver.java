package com.example.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.example.ParentalApp;
import com.example.data.remote.TelegramBotClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;

/* JADX INFO: compiled from: GeofenceBroadcastReceiver.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/example/receivers/GeofenceBroadcastReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "()V", "scope", "Lkotlinx/coroutines/CoroutineScope;", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class GeofenceBroadcastReceiver extends BroadcastReceiver {
    public static final int $stable = 8;
    private final CoroutineScope scope = CoroutineScopeKt.CoroutineScope(Dispatchers.getIO().plus(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null)));

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(intent, "intent");
        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
        if (geofencingEvent == null || geofencingEvent.hasError()) {
            return;
        }
        int geofenceTransition = geofencingEvent.getGeofenceTransition();
        Context applicationContext = context.getApplicationContext();
        Intrinsics.checkNotNull(applicationContext, "null cannot be cast to non-null type com.example.ParentalApp");
        TelegramBotClient telegramClient = ((ParentalApp) applicationContext).getAppComponent().getTelegramBotClient();
        switch (geofenceTransition) {
            case 1:
            case 2:
                Iterable triggeringGeofences = geofencingEvent.getTriggeringGeofences();
                String state = geofenceTransition == 1 ? "ENTERED" : "EXITED";
                if (triggeringGeofences != null) {
                    Iterator it = triggeringGeofences.iterator();
                    while (it.hasNext()) {
                        GeofencingEvent geofencingEvent2 = geofencingEvent;
                        BuildersKt__Builders_commonKt.launch$default(this.scope, null, null, new GeofenceBroadcastReceiver$onReceive$1$1(telegramClient, "Alert! Device has " + state + " geofence: " + ((Geofence) it.next()).getRequestId(), null), 3, null);
                        geofencingEvent = geofencingEvent2;
                    }
                }
                break;
        }
    }
}
