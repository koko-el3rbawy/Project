package com.example.work;

import android.content.Context;
import androidx.core.app.NotificationCompat;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: TelegramRetryWorker.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u0014\u001a\u00020\u0015H\u0096@¢\u0006\u0002\u0010\u0016R\u001e\u0010\b\u001a\u00020\t8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001e\u0010\u000e\u001a\u00020\u000f8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013¨\u0006\u0017"}, d2 = {"Lcom/example/work/TelegramRetryWorker;", "Landroidx/work/CoroutineWorker;", "appContext", "Landroid/content/Context;", "workerParams", "Landroidx/work/WorkerParameters;", "<init>", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "telegramClient", "Lcom/example/data/remote/TelegramBotClient;", "getTelegramClient", "()Lcom/example/data/remote/TelegramBotClient;", "setTelegramClient", "(Lcom/example/data/remote/TelegramBotClient;)V", "db", "Lcom/example/data/local/AppDatabase;", "getDb", "()Lcom/example/data/local/AppDatabase;", "setDb", "(Lcom/example/data/local/AppDatabase;)V", "doWork", "Landroidx/work/ListenableWorker$Result;", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class TelegramRetryWorker extends CoroutineWorker {
    public static final int $stable = 8;

    @Inject
    public AppDatabase db;

    @Inject
    public TelegramBotClient telegramClient;

    /* JADX INFO: renamed from: com.example.work.TelegramRetryWorker$doWork$1, reason: invalid class name */
    /* JADX INFO: compiled from: TelegramRetryWorker.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.work.TelegramRetryWorker", f = "TelegramRetryWorker.kt", i = {1, 1, 1, 2, 2, 2, 2}, l = {22, 27, 29}, m = "doWork", n = {"pending", NotificationCompat.CATEGORY_MESSAGE, "allSent", "pending", NotificationCompat.CATEGORY_MESSAGE, "allSent", "success"}, s = {"L$0", "L$2", "I$0", "L$0", "L$2", "I$0", "Z$0"})
    static final class AnonymousClass1 extends ContinuationImpl {
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return TelegramRetryWorker.this.doWork(this);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TelegramRetryWorker(Context appContext, WorkerParameters workerParams) {
        super(appContext, workerParams);
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(workerParams, "workerParams");
    }

    public final TelegramBotClient getTelegramClient() {
        TelegramBotClient telegramBotClient = this.telegramClient;
        if (telegramBotClient != null) {
            return telegramBotClient;
        }
        Intrinsics.throwUninitializedPropertyAccessException("telegramClient");
        return null;
    }

    public final void setTelegramClient(TelegramBotClient telegramBotClient) {
        Intrinsics.checkNotNullParameter(telegramBotClient, "<set-?>");
        this.telegramClient = telegramBotClient;
    }

    public final AppDatabase getDb() {
        AppDatabase appDatabase = this.db;
        if (appDatabase != null) {
            return appDatabase;
        }
        Intrinsics.throwUninitializedPropertyAccessException("db");
        return null;
    }

    public final void setDb(AppDatabase appDatabase) {
        Intrinsics.checkNotNullParameter(appDatabase, "<set-?>");
        this.db = appDatabase;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x0102 -> B:35:0x0106). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x010a -> B:23:0x00a2). Please report as a decompilation issue!!! */
    @Override // androidx.work.CoroutineWorker
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object doWork(kotlin.coroutines.Continuation<? super androidx.work.ListenableWorker.Result> r14) {
        /*
            Method dump skipped, instruction units count: 302
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.work.TelegramRetryWorker.doWork(kotlin.coroutines.Continuation):java.lang.Object");
    }
}
