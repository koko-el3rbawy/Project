package com.example.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: BatteryOptimizationHelper.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007J\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/example/utils/BatteryOptimizationHelper;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "isIgnoringBatteryOptimizations", "", "requestDisableBatteryOptimization", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class BatteryOptimizationHelper {
    public static final int $stable = 8;
    private final Context context;

    public BatteryOptimizationHelper(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final boolean isIgnoringBatteryOptimizations() {
        Object systemService = this.context.getSystemService("power");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.PowerManager");
        PowerManager powerManager = (PowerManager) systemService;
        return powerManager.isIgnoringBatteryOptimizations(this.context.getPackageName());
    }

    public final void requestDisableBatteryOptimization() {
        if (!isIgnoringBatteryOptimizations()) {
            try {
                Intent intent = new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                intent.setData(Uri.parse("package:" + this.context.getPackageName()));
                intent.addFlags(268435456);
                this.context.startActivity(intent);
            } catch (Exception e) {
                try {
                    Intent intent2 = new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
                    intent2.addFlags(268435456);
                    this.context.startActivity(intent2);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
