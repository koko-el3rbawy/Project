package com.example.managers;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.util.Arrays;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: FileExplorerManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J(\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/example/managers/FileExplorerManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "generateReport", "Ljava/io/File;", "scanFolder", "", "folder", "sb", "Ljava/lang/StringBuilder;", "depth", "", "maxDepth", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class FileExplorerManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public FileExplorerManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final File generateReport() {
        File reportFile = new File(this.context.getCacheDir(), "files_report_" + System.currentTimeMillis() + ".txt");
        StringBuilder sb = new StringBuilder();
        sb.append("FILE EXPLORER REPORT (ROOT FOLDERS)\n");
        sb.append("========================\n\n");
        try {
            File externalDir = Environment.getExternalStorageDirectory();
            if (externalDir.exists() && externalDir.isDirectory()) {
                List<String> foldersToScan = CollectionsKt.listOf((Object[]) new String[]{"Download", "DCIM", "Pictures", "Documents", "WhatsApp", "Android/media/com.whatsapp/WhatsApp/Media"});
                for (String folderName : foldersToScan) {
                    File folder = new File(externalDir, folderName);
                    sb.append("📂 [" + folder.getName() + "]\n");
                    if (folder.exists() && folder.isDirectory()) {
                        scanFolder(folder, sb, 0, 2);
                    } else {
                        sb.append("  (Not Exists or Empty)\n");
                    }
                    sb.append("\n------------------------\n\n");
                }
            } else {
                sb.append("External storage not accessible.\n");
            }
            String string = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            FilesKt.writeText$default(reportFile, string, null, 2, null);
            return reportFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private final void scanFolder(File folder, StringBuilder sb, int depth, int maxDepth) {
        File[] files;
        int i = depth;
        int i2 = maxDepth;
        if (i < i2 && (files = folder.listFiles()) != null) {
            String indent = StringsKt.repeat("  ", i + 1);
            for (File file : CollectionsKt.take(ArraysKt.sortedWith(files, ComparisonsKt.compareBy(new Function1() { // from class: com.example.managers.FileExplorerManager$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    File file2 = (File) obj;
                    return Boolean.valueOf(!file2.isDirectory());
                }
            }, new Function1() { // from class: com.example.managers.FileExplorerManager$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return ((File) obj).getName();
                }
            })), 50)) {
                if (file.isDirectory()) {
                    sb.append(indent + "📁 " + file.getName() + "/\n");
                    Intrinsics.checkNotNull(file);
                    scanFolder(file, sb, i + 1, i2);
                } else {
                    StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                    String str = String.format("%.2f MB", Arrays.copyOf(new Object[]{Double.valueOf(file.length() / 1048576.0d)}, 1));
                    Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                    sb.append(indent + "📄 " + file.getName() + " (" + str + ")\n");
                }
                i = depth;
                i2 = maxDepth;
            }
            if (files.length > 50) {
                sb.append(indent + "... and " + (files.length - 50) + " more items ...\n");
            }
        }
    }
}
