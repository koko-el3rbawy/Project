package com.example.data.remote;

import com.example.data.repository.SettingsRepository;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes7.dex */
public final class TelegramBotClient_Factory implements Factory<TelegramBotClient> {
    private final Provider<SettingsRepository> settingsProvider;

    public TelegramBotClient_Factory(Provider<SettingsRepository> settingsProvider) {
        this.settingsProvider = settingsProvider;
    }

    @Override // javax.inject.Provider
    public TelegramBotClient get() {
        return newInstance(this.settingsProvider.get());
    }

    public static TelegramBotClient_Factory create(Provider<SettingsRepository> settingsProvider) {
        return new TelegramBotClient_Factory(settingsProvider);
    }

    public static TelegramBotClient newInstance(SettingsRepository settings) {
        return new TelegramBotClient(settings);
    }
}
