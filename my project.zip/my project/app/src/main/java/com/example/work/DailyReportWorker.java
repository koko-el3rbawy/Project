package com.example.work;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: DailyReportWorker.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u0014\u001a\u00020\u0015H\u0096@¢\u0006\u0002\u0010\u0016R\u001e\u0010\b\u001a\u00020\t8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001e\u0010\u000e\u001a\u00020\u000f8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013¨\u0006\u0017"}, d2 = {"Lcom/example/work/DailyReportWorker;", "Landroidx/work/CoroutineWorker;", "appContext", "Landroid/content/Context;", "workerParams", "Landroidx/work/WorkerParameters;", "<init>", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "telegramClient", "Lcom/example/data/remote/TelegramBotClient;", "getTelegramClient", "()Lcom/example/data/remote/TelegramBotClient;", "setTelegramClient", "(Lcom/example/data/remote/TelegramBotClient;)V", "db", "Lcom/example/data/local/AppDatabase;", "getDb", "()Lcom/example/data/local/AppDatabase;", "setDb", "(Lcom/example/data/local/AppDatabase;)V", "doWork", "Landroidx/work/ListenableWorker$Result;", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class DailyReportWorker extends CoroutineWorker {
    public static final int $stable = 8;

    @Inject
    public AppDatabase db;

    @Inject
    public TelegramBotClient telegramClient;

    /* JADX INFO: renamed from: com.example.work.DailyReportWorker$doWork$1, reason: invalid class name */
    /* JADX INFO: compiled from: DailyReportWorker.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.work.DailyReportWorker", f = "DailyReportWorker.kt", i = {0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1}, l = {49, 55}, m = "doWork", n = {"usm", "cal", "stats", "report", "totalTime", "endTime", "startTime", "usm", "cal", "stats", "report", "totalTime", "notifications", "endTime", "startTime"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "J$0", "J$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "J$0", "J$1"})
    static final class AnonymousClass1 extends ContinuationImpl {
        long J$0;
        long J$1;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return DailyReportWorker.this.doWork(this);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DailyReportWorker(Context appContext, WorkerParameters workerParams) {
        super(appContext, workerParams);
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(workerParams, "workerParams");
    }

    public final TelegramBotClient getTelegramClient() {
        TelegramBotClient telegramBotClient = this.telegramClient;
        if (telegramBotClient != null) {
            return telegramBotClient;
        }
        Intrinsics.throwUninitializedPropertyAccessException("telegramClient");
        return null;
    }

    public final void setTelegramClient(TelegramBotClient telegramBotClient) {
        Intrinsics.checkNotNullParameter(telegramBotClient, "<set-?>");
        this.telegramClient = telegramBotClient;
    }

    public final AppDatabase getDb() {
        AppDatabase appDatabase = this.db;
        if (appDatabase != null) {
            return appDatabase;
        }
        Intrinsics.throwUninitializedPropertyAccessException("db");
        return null;
    }

    public final void setDb(AppDatabase appDatabase) {
        Intrinsics.checkNotNullParameter(appDatabase, "<set-?>");
        this.db = appDatabase;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0272 A[LOOP:0: B:48:0x026c->B:50:0x0272, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x02f1 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x02f2  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0304  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x030b  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0018  */
    /* JADX WARN: Type inference failed for: r0v42, types: [T, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v8, types: [T, java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v13, types: [T, java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v20, types: [T, java.lang.String] */
    @Override // androidx.work.CoroutineWorker
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object doWork(kotlin.coroutines.Continuation<? super androidx.work.ListenableWorker.Result> r31) {
        /*
            Method dump skipped, instruction units count: 800
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.work.DailyReportWorker.doWork(kotlin.coroutines.Continuation):java.lang.Object");
    }
}
