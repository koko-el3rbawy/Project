package com.example.utils;

import android.content.Context;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ListenableWorker;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.example.work.DailyReportWorker;
import com.example.work.TelegramRetryWorker;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ReliableWorkerManager.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/example/utils/ReliableWorkerManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "setupReliableWorkers", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ReliableWorkerManager {
    public static final int $stable = 8;
    private final Context context;

    public ReliableWorkerManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final void setupReliableWorkers() {
        WorkManager workManager = WorkManager.INSTANCE.getInstance(this.context);
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest retryRequest = new PeriodicWorkRequest.Builder((Class<? extends ListenableWorker>) TelegramRetryWorker.class, 15L, TimeUnit.MINUTES).setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1L, TimeUnit.MINUTES).build();
        PeriodicWorkRequest dailyRequest = new PeriodicWorkRequest.Builder((Class<? extends ListenableWorker>) DailyReportWorker.class, 1L, TimeUnit.DAYS).setConstraints(constraints).build();
        workManager.enqueueUniquePeriodicWork("telegram_sync", ExistingPeriodicWorkPolicy.KEEP, retryRequest);
        workManager.enqueueUniquePeriodicWork("daily_report", ExistingPeriodicWorkPolicy.KEEP, dailyRequest);
    }
}
