package com.example.managers;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AppUsageManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/example/managers/AppUsageManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "generateReport", "Ljava/io/File;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AppUsageManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public AppUsageManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final File generateReport() {
        File reportFile = new File(this.context.getCacheDir(), "app_usage_report_" + System.currentTimeMillis() + ".txt");
        StringBuilder sb = new StringBuilder();
        sb.append("APP USAGE REPORT (Last 24 Hours)\n");
        sb.append("========================\n\n");
        try {
            Object systemService = this.context.getSystemService("usagestats");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.usage.UsageStatsManager");
            UsageStatsManager usm = (UsageStatsManager) systemService;
            Calendar cal = Calendar.getInstance();
            long endTime = cal.getTimeInMillis();
            cal.add(6, -1);
            long startTime = cal.getTimeInMillis();
            Iterable iterableQueryUsageStats = usm.queryUsageStats(0, startTime, endTime);
            if (iterableQueryUsageStats != null) {
                Collection arrayList = new ArrayList();
                for (Object obj : iterableQueryUsageStats) {
                    if (((UsageStats) obj).getTotalTimeInForeground() > 0) {
                        arrayList.add(obj);
                    }
                }
                Iterable<UsageStats> iterableSortedWith = CollectionsKt.sortedWith((List) arrayList, new Comparator() { // from class: com.example.managers.AppUsageManager$generateReport$$inlined$sortedByDescending$1
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t, T t2) {
                        return ComparisonsKt.compareValues(Long.valueOf(((UsageStats) t2).getTotalTimeInForeground()), Long.valueOf(((UsageStats) t).getTotalTimeInForeground()));
                    }
                });
                if (iterableSortedWith != null) {
                    int i = 0;
                    for (UsageStats usageStats : iterableSortedWith) {
                        long totalTimeInForeground = usageStats.getTotalTimeInForeground() / 60000;
                        String str = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault()).format(new Date(usageStats.getLastTimeUsed()));
                        sb.append("App: " + usageStats.getPackageName() + "\n");
                        sb.append("Usage Time: " + (totalTimeInForeground / 60) + "h " + (totalTimeInForeground % 60) + "m\n");
                        sb.append("Last Used: " + str + "\n");
                        sb.append("------------------------\n");
                        i = i;
                        cal = cal;
                        usm = usm;
                    }
                }
            }
            String string = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            FilesKt.writeText$default(reportFile, string, null, 2, null);
            return reportFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
