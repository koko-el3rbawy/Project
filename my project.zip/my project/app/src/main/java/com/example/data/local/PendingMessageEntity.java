package com.example.data.local;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: PendingMessageEntity.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\bHÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001b\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001c"}, d2 = {"Lcom/example/data/local/PendingMessageEntity;", "", "id", "", "text", "", "parseMode", "timestamp", "", "<init>", "(ILjava/lang/String;Ljava/lang/String;J)V", "getId", "()I", "getText", "()Ljava/lang/String;", "getParseMode", "getTimestamp", "()J", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class PendingMessageEntity {
    public static final int $stable = 0;
    private final int id;
    private final String parseMode;
    private final String text;
    private final long timestamp;

    public static /* synthetic */ PendingMessageEntity copy$default(PendingMessageEntity pendingMessageEntity, int i, String str, String str2, long j, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = pendingMessageEntity.id;
        }
        if ((i2 & 2) != 0) {
            str = pendingMessageEntity.text;
        }
        if ((i2 & 4) != 0) {
            str2 = pendingMessageEntity.parseMode;
        }
        if ((i2 & 8) != 0) {
            j = pendingMessageEntity.timestamp;
        }
        String str3 = str2;
        return pendingMessageEntity.copy(i, str, str3, j);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getText() {
        return this.text;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getParseMode() {
        return this.parseMode;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    public final PendingMessageEntity copy(int id, String text, String parseMode, long timestamp) {
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(parseMode, "parseMode");
        return new PendingMessageEntity(id, text, parseMode, timestamp);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PendingMessageEntity)) {
            return false;
        }
        PendingMessageEntity pendingMessageEntity = (PendingMessageEntity) other;
        return this.id == pendingMessageEntity.id && Intrinsics.areEqual(this.text, pendingMessageEntity.text) && Intrinsics.areEqual(this.parseMode, pendingMessageEntity.parseMode) && this.timestamp == pendingMessageEntity.timestamp;
    }

    public int hashCode() {
        return (((((Integer.hashCode(this.id) * 31) + this.text.hashCode()) * 31) + this.parseMode.hashCode()) * 31) + Long.hashCode(this.timestamp);
    }

    public String toString() {
        return "PendingMessageEntity(id=" + this.id + ", text=" + this.text + ", parseMode=" + this.parseMode + ", timestamp=" + this.timestamp + ")";
    }

    public PendingMessageEntity(int id, String text, String parseMode, long timestamp) {
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(parseMode, "parseMode");
        this.id = id;
        this.text = text;
        this.parseMode = parseMode;
        this.timestamp = timestamp;
    }

    public /* synthetic */ PendingMessageEntity(int i, String str, String str2, long j, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0 : i, str, (i2 & 4) != 0 ? "HTML" : str2, j);
    }

    public final int getId() {
        return this.id;
    }

    public final String getText() {
        return this.text;
    }

    public final String getParseMode() {
        return this.parseMode;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }
}
