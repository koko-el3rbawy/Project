package com.example.security;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.autofill.HintConstants;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import androidx.work.PeriodicWorkRequest;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* JADX INFO: compiled from: ParentSecurityManager.kt */
/* JADX INFO: loaded from: classes11.dex */
@Singleton
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bH\u0002J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\f\u001a\u00020\u000bJ\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\f\u001a\u00020\u000bJ\b\u0010\u0011\u001a\u00020\u000eH\u0002J\b\u0010\u0012\u001a\u00020\u000eH\u0002J\u0006\u0010\u0013\u001a\u00020\u0010J\u0006\u0010\u0014\u001a\u00020\u0015R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/example/security/ParentSecurityManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "masterKey", "Landroidx/security/crypto/MasterKey;", "prefs", "Landroid/content/SharedPreferences;", "hashPassword", "", HintConstants.AUTOFILL_HINT_PASSWORD, "setPassword", "", "verifyPassword", "", "recordFailedAttempt", "resetFailedAttempts", "isLockedOut", "getLockoutRemainingSeconds", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ParentSecurityManager {
    public static final int $stable = 8;
    private final MasterKey masterKey;
    private final SharedPreferences prefs;

    @Inject
    public ParentSecurityManager(Context context) throws GeneralSecurityException, IOException {
        Intrinsics.checkNotNullParameter(context, "context");
        MasterKey masterKeyBuild = new MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        Intrinsics.checkNotNullExpressionValue(masterKeyBuild, "build(...)");
        this.masterKey = masterKeyBuild;
        SharedPreferences sharedPreferencesCreate = EncryptedSharedPreferences.create(context, "parent_security_prefs", this.masterKey, EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        Intrinsics.checkNotNullExpressionValue(sharedPreferencesCreate, "create(...)");
        this.prefs = sharedPreferencesCreate;
        if (this.prefs.contains("parent_password_hash")) {
            return;
        }
        setPassword("keroroma862023");
    }

    private final String hashPassword(String password) throws NoSuchAlgorithmException {
        byte[] bytes = password.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(bytes);
        Intrinsics.checkNotNull(digest);
        String str = "";
        for (byte b : digest) {
            String str2 = String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(b)}, 1));
            Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
            str = str + str2;
        }
        return str;
    }

    public final void setPassword(String password) {
        Intrinsics.checkNotNullParameter(password, "password");
        this.prefs.edit().putString("parent_password_hash", hashPassword(password)).apply();
    }

    public final boolean verifyPassword(String password) throws NoSuchAlgorithmException {
        Intrinsics.checkNotNullParameter(password, "password");
        String storedHash = this.prefs.getString("parent_password_hash", null);
        if (storedHash == null) {
            return false;
        }
        String inputHash = hashPassword(password);
        boolean isSuccess = Intrinsics.areEqual(storedHash, inputHash);
        if (!isSuccess) {
            recordFailedAttempt();
        } else {
            resetFailedAttempts();
        }
        return isSuccess;
    }

    private final void recordFailedAttempt() {
        int attempts = this.prefs.getInt("failed_attempts", 0) + 1;
        this.prefs.edit().putInt("failed_attempts", attempts).apply();
        if (attempts >= 5) {
            this.prefs.edit().putLong("lockout_until", System.currentTimeMillis() + PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS).apply();
        }
    }

    private final void resetFailedAttempts() {
        this.prefs.edit().putInt("failed_attempts", 0).apply();
        this.prefs.edit().putLong("lockout_until", 0L).apply();
    }

    public final boolean isLockedOut() {
        long lockoutTime = this.prefs.getLong("lockout_until", 0L);
        return System.currentTimeMillis() < lockoutTime;
    }

    public final long getLockoutRemainingSeconds() {
        long lockoutTime = this.prefs.getLong("lockout_until", 0L);
        long remaining = (lockoutTime - System.currentTimeMillis()) / 1000;
        if (remaining > 0) {
            return remaining;
        }
        return 0L;
    }
}
