package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class AppUsageManager_Factory implements Factory<AppUsageManager> {
    private final Provider<Context> contextProvider;

    public AppUsageManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public AppUsageManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static AppUsageManager_Factory create(Provider<Context> contextProvider) {
        return new AppUsageManager_Factory(contextProvider);
    }

    public static AppUsageManager newInstance(Context context) {
        return new AppUsageManager(context);
    }
}
