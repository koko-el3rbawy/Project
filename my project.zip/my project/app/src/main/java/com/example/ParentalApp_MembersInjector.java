package com.example;

import com.example.work.CustomWorkerFactory;
import dagger.MembersInjector;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes8.dex */
public final class ParentalApp_MembersInjector implements MembersInjector<ParentalApp> {
    private final Provider<CustomWorkerFactory> workerFactoryProvider;

    public ParentalApp_MembersInjector(Provider<CustomWorkerFactory> workerFactoryProvider) {
        this.workerFactoryProvider = workerFactoryProvider;
    }

    public static MembersInjector<ParentalApp> create(Provider<CustomWorkerFactory> workerFactoryProvider) {
        return new ParentalApp_MembersInjector(workerFactoryProvider);
    }

    @Override // dagger.MembersInjector
    public void injectMembers(ParentalApp instance) {
        injectWorkerFactory(instance, this.workerFactoryProvider.get());
    }

    public static void injectWorkerFactory(ParentalApp instance, CustomWorkerFactory workerFactory) {
        instance.workerFactory = workerFactory;
    }
}
