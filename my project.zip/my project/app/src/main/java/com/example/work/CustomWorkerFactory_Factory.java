package com.example.work;

import dagger.internal.Factory;

/* JADX INFO: loaded from: classes3.dex */
public final class CustomWorkerFactory_Factory implements Factory<CustomWorkerFactory> {
    @Override // javax.inject.Provider
    public CustomWorkerFactory get() {
        return newInstance();
    }

    public static CustomWorkerFactory_Factory create() {
        return InstanceHolder.INSTANCE;
    }

    public static CustomWorkerFactory newInstance() {
        return new CustomWorkerFactory();
    }

    private static final class InstanceHolder {
        private static final CustomWorkerFactory_Factory INSTANCE = new CustomWorkerFactory_Factory();

        private InstanceHolder() {
        }
    }
}
