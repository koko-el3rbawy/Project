package com.example.di;

import androidx.core.app.NotificationCompat;
import com.example.ParentalApp;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.remote.TelegramDashboardManager;
import com.example.data.repository.SettingsRepository;
import com.example.managers.OEMCompatibilityManager;
import com.example.security.ParentSecurityManager;
import com.example.services.LocationForegroundService;
import com.example.services.ParentNotificationListener;
import com.example.utils.BatteryOptimizationHelper;
import com.example.utils.DeviceAdminManager;
import com.example.utils.NotificationPermissionHelper;
import com.example.work.DailyReportWorker;
import com.example.work.TelegramRetryWorker;
import dagger.Component;
import javax.inject.Singleton;
import kotlin.Metadata;

/* JADX INFO: compiled from: AppComponent.kt */
/* JADX INFO: loaded from: classes3.dex */
@Component(modules = {AppModule.class})
@Singleton
@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\bg\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0007H&J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\bH&J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH&J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u000bH&J\b\u0010\f\u001a\u00020\rH&J\b\u0010\u000e\u001a\u00020\u000fH&J\b\u0010\u0010\u001a\u00020\u0011H&J\b\u0010\u0012\u001a\u00020\u0013H&J\b\u0010\u0014\u001a\u00020\u0015H&J\b\u0010\u0016\u001a\u00020\u0017H&J\b\u0010\u0018\u001a\u00020\u0019H&J\b\u0010\u001a\u001a\u00020\u001bH&J\b\u0010\u001c\u001a\u00020\u001dH&¨\u0006\u0004À\u0006\u0003"}, d2 = {"Lcom/example/di/AppComponent;", "", "inject", "", "app", "Lcom/example/ParentalApp;", NotificationCompat.CATEGORY_SERVICE, "Lcom/example/services/LocationForegroundService;", "Lcom/example/services/ParentNotificationListener;", "worker", "Lcom/example/work/DailyReportWorker;", "Lcom/example/work/TelegramRetryWorker;", "getSettingsRepository", "Lcom/example/data/repository/SettingsRepository;", "getTelegramBotClient", "Lcom/example/data/remote/TelegramBotClient;", "getTelegramDashboardManager", "Lcom/example/data/remote/TelegramDashboardManager;", "getAppDatabase", "Lcom/example/data/local/AppDatabase;", "getDeviceAdminManager", "Lcom/example/utils/DeviceAdminManager;", "getParentSecurityManager", "Lcom/example/security/ParentSecurityManager;", "getNotificationPermissionHelper", "Lcom/example/utils/NotificationPermissionHelper;", "getOEMCompatibilityManager", "Lcom/example/managers/OEMCompatibilityManager;", "getBatteryOptimizationHelper", "Lcom/example/utils/BatteryOptimizationHelper;"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface AppComponent {
    AppDatabase getAppDatabase();

    BatteryOptimizationHelper getBatteryOptimizationHelper();

    DeviceAdminManager getDeviceAdminManager();

    NotificationPermissionHelper getNotificationPermissionHelper();

    OEMCompatibilityManager getOEMCompatibilityManager();

    ParentSecurityManager getParentSecurityManager();

    SettingsRepository getSettingsRepository();

    TelegramBotClient getTelegramBotClient();

    TelegramDashboardManager getTelegramDashboardManager();

    void inject(ParentalApp app);

    void inject(LocationForegroundService service);

    void inject(ParentNotificationListener service);

    void inject(DailyReportWorker worker);

    void inject(TelegramRetryWorker worker);
}
