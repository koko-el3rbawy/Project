package com.example.managers;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import java.io.File;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ContactsExportManager.kt */
/* JADX INFO: loaded from: classes12.dex */
@Singleton
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/example/managers/ContactsExportManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "generateReport", "Ljava/io/File;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ContactsExportManager {
    public static final int $stable = 8;
    private final Context context;

    @Inject
    public ContactsExportManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final File generateReport() {
        File reportFile = new File(this.context.getCacheDir(), "contacts_report_" + System.currentTimeMillis() + ".txt");
        StringBuilder sb = new StringBuilder();
        sb.append("CONTACTS LIST EXPORT\n");
        sb.append("========================\n\n");
        try {
            Cursor cursor = this.context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, "display_name ASC");
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor cursor3 = cursor2;
                    int columnIndex = cursor3.getColumnIndex("display_name");
                    int columnIndex2 = cursor3.getColumnIndex("data1");
                    while (cursor3.moveToNext()) {
                        sb.append(cursor3.getString(columnIndex) + ": " + cursor3.getString(columnIndex2) + "\n");
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, null);
                } finally {
                }
            }
            String string = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            FilesKt.writeText$default(reportFile, string, null, 2, null);
            return reportFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
