package com.example.work;

import com.example.data.local.AppDatabase;
import com.example.data.remote.TelegramBotClient;
import dagger.MembersInjector;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final class DailyReportWorker_MembersInjector implements MembersInjector<DailyReportWorker> {
    private final Provider<AppDatabase> dbProvider;
    private final Provider<TelegramBotClient> telegramClientProvider;

    public DailyReportWorker_MembersInjector(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider) {
        this.telegramClientProvider = telegramClientProvider;
        this.dbProvider = dbProvider;
    }

    public static MembersInjector<DailyReportWorker> create(Provider<TelegramBotClient> telegramClientProvider, Provider<AppDatabase> dbProvider) {
        return new DailyReportWorker_MembersInjector(telegramClientProvider, dbProvider);
    }

    @Override // dagger.MembersInjector
    public void injectMembers(DailyReportWorker instance) {
        injectTelegramClient(instance, this.telegramClientProvider.get());
        injectDb(instance, this.dbProvider.get());
    }

    public static void injectTelegramClient(DailyReportWorker instance, TelegramBotClient telegramClient) {
        instance.telegramClient = telegramClient;
    }

    public static void injectDb(DailyReportWorker instance, AppDatabase db) {
        instance.db = db;
    }
}
