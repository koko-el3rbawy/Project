package com.example.utils;

import android.app.AppOpsManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.service.notification.NotificationListenerService;
import androidx.core.app.NotificationManagerCompat;
import com.example.services.ParentNotificationListener;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: NotificationPermissionHelper.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\u0007J\u0006\u0010\u000b\u001a\u00020\tJ\u0006\u0010\f\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Lcom/example/utils/NotificationPermissionHelper;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "hasUsageStatsPermission", "", "openUsageAccessSettings", "", "isNotificationServiceEnabled", "openNotificationSettings", "forceNotificationListenerReconnect", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NotificationPermissionHelper {
    public static final int $stable = 8;
    private final Context context;

    public NotificationPermissionHelper(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public final boolean hasUsageStatsPermission() {
        Object systemService = this.context.getSystemService("appops");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.AppOpsManager");
        AppOpsManager appOps = (AppOpsManager) systemService;
        int mode = appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), this.context.getPackageName());
        return mode == 0;
    }

    public final void openUsageAccessSettings() {
        Intent intent = new Intent("android.settings.USAGE_ACCESS_SETTINGS");
        intent.addFlags(268435456);
        this.context.startActivity(intent);
    }

    public final boolean isNotificationServiceEnabled() {
        Set<String> enabledListenerPackages = NotificationManagerCompat.getEnabledListenerPackages(this.context);
        Intrinsics.checkNotNullExpressionValue(enabledListenerPackages, "getEnabledListenerPackages(...)");
        return enabledListenerPackages.contains(this.context.getPackageName());
    }

    public final void openNotificationSettings() {
        try {
            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            intent.addFlags(268435456);
            this.context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                Intent intent2 = new Intent("android.settings.SECURITY_SETTINGS");
                intent2.addFlags(268435456);
                this.context.startActivity(intent2);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public final void forceNotificationListenerReconnect() {
        ComponentName componentName = new ComponentName(this.context, (Class<?>) ParentNotificationListener.class);
        NotificationListenerService.requestRebind(componentName);
    }
}
