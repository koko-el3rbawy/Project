package com.example.ui;

import androidx.autofill.HintConstants;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.viewmodel.CreationExtras;
import com.example.data.repository.SettingsRepository;
import com.example.managers.OEMCompatibilityManager;
import com.example.security.ParentSecurityManager;
import com.example.utils.BatteryOptimizationHelper;
import com.example.utils.DeviceAdminManager;
import com.example.utils.NotificationPermissionHelper;
import java.security.NoSuchAlgorithmException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KClass;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: MainViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\r\b\u0007\u0018\u00002\u00020\u0001:\u00014B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u000e\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u001aJ\u000e\u0010*\u001a\u00020(2\u0006\u0010+\u001a\u00020\u001aJ\u000e\u0010,\u001a\u00020(2\u0006\u0010-\u001a\u00020#J\u0006\u0010.\u001a\u00020(J\u000e\u00101\u001a\u00020#2\u0006\u00102\u001a\u00020\u001aJ\u0006\u00103\u001a\u00020(R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001a0\u001c¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001a0\u001c¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u001eR\u0014\u0010\"\u001a\b\u0012\u0004\u0012\u00020#0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010$\u001a\b\u0012\u0004\u0012\u00020#0\u001c¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001eR\u0014\u0010%\u001a\b\u0012\u0004\u0012\u00020#0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010&\u001a\b\u0012\u0004\u0012\u00020#0\u001c¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u001eR\u0014\u0010/\u001a\b\u0012\u0004\u0012\u00020#0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00100\u001a\b\u0012\u0004\u0012\u00020#0\u001c¢\u0006\b\n\u0000\u001a\u0004\b0\u0010\u001e¨\u00065"}, d2 = {"Lcom/example/ui/MainViewModel;", "Landroidx/lifecycle/ViewModel;", "settings", "Lcom/example/data/repository/SettingsRepository;", "deviceAdminManager", "Lcom/example/utils/DeviceAdminManager;", "securityManager", "Lcom/example/security/ParentSecurityManager;", "notificationHelper", "Lcom/example/utils/NotificationPermissionHelper;", "oemManager", "Lcom/example/managers/OEMCompatibilityManager;", "batteryHelper", "Lcom/example/utils/BatteryOptimizationHelper;", "<init>", "(Lcom/example/data/repository/SettingsRepository;Lcom/example/utils/DeviceAdminManager;Lcom/example/security/ParentSecurityManager;Lcom/example/utils/NotificationPermissionHelper;Lcom/example/managers/OEMCompatibilityManager;Lcom/example/utils/BatteryOptimizationHelper;)V", "getSecurityManager", "()Lcom/example/security/ParentSecurityManager;", "getNotificationHelper", "()Lcom/example/utils/NotificationPermissionHelper;", "getOemManager", "()Lcom/example/managers/OEMCompatibilityManager;", "getBatteryHelper", "()Lcom/example/utils/BatteryOptimizationHelper;", "_botToken", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "botToken", "Lkotlinx/coroutines/flow/StateFlow;", "getBotToken", "()Lkotlinx/coroutines/flow/StateFlow;", "_chatId", "chatId", "getChatId", "_isMonitoring", "", "isMonitoring", "_isAdminActive", "isAdminActive", "updateToken", "", "token", "updateChatId", "id", "setMonitoring", "active", "refreshAdminState", "_isAuthenticated", "isAuthenticated", "authenticate", HintConstants.AUTOFILL_HINT_PASSWORD, "lock", "Factory", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MainViewModel extends ViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<String> _botToken;
    private final MutableStateFlow<String> _chatId;
    private final MutableStateFlow<Boolean> _isAdminActive;
    private final MutableStateFlow<Boolean> _isAuthenticated;
    private final MutableStateFlow<Boolean> _isMonitoring;
    private final BatteryOptimizationHelper batteryHelper;
    private final StateFlow<String> botToken;
    private final StateFlow<String> chatId;
    private final DeviceAdminManager deviceAdminManager;
    private final StateFlow<Boolean> isAdminActive;
    private final StateFlow<Boolean> isAuthenticated;
    private final StateFlow<Boolean> isMonitoring;
    private final NotificationPermissionHelper notificationHelper;
    private final OEMCompatibilityManager oemManager;
    private final ParentSecurityManager securityManager;
    private final SettingsRepository settings;

    public final ParentSecurityManager getSecurityManager() {
        return this.securityManager;
    }

    public final NotificationPermissionHelper getNotificationHelper() {
        return this.notificationHelper;
    }

    public final OEMCompatibilityManager getOemManager() {
        return this.oemManager;
    }

    public final BatteryOptimizationHelper getBatteryHelper() {
        return this.batteryHelper;
    }

    public MainViewModel(SettingsRepository settings, DeviceAdminManager deviceAdminManager, ParentSecurityManager securityManager, NotificationPermissionHelper notificationHelper, OEMCompatibilityManager oemManager, BatteryOptimizationHelper batteryHelper) {
        Intrinsics.checkNotNullParameter(settings, "settings");
        Intrinsics.checkNotNullParameter(deviceAdminManager, "deviceAdminManager");
        Intrinsics.checkNotNullParameter(securityManager, "securityManager");
        Intrinsics.checkNotNullParameter(notificationHelper, "notificationHelper");
        Intrinsics.checkNotNullParameter(oemManager, "oemManager");
        Intrinsics.checkNotNullParameter(batteryHelper, "batteryHelper");
        this.settings = settings;
        this.deviceAdminManager = deviceAdminManager;
        this.securityManager = securityManager;
        this.notificationHelper = notificationHelper;
        this.oemManager = oemManager;
        this.batteryHelper = batteryHelper;
        String botToken = this.settings.getBotToken();
        this._botToken = StateFlowKt.MutableStateFlow(botToken == null ? "" : botToken);
        this.botToken = FlowKt.asStateFlow(this._botToken);
        String chatId = this.settings.getChatId();
        this._chatId = StateFlowKt.MutableStateFlow(chatId != null ? chatId : "");
        this.chatId = FlowKt.asStateFlow(this._chatId);
        this._isMonitoring = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.settings.isMonitoringActive()));
        this.isMonitoring = FlowKt.asStateFlow(this._isMonitoring);
        this._isAdminActive = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.deviceAdminManager.isAdminActive()));
        this.isAdminActive = FlowKt.asStateFlow(this._isAdminActive);
        this._isAuthenticated = StateFlowKt.MutableStateFlow(false);
        this.isAuthenticated = FlowKt.asStateFlow(this._isAuthenticated);
    }

    public final StateFlow<String> getBotToken() {
        return this.botToken;
    }

    public final StateFlow<String> getChatId() {
        return this.chatId;
    }

    public final StateFlow<Boolean> isMonitoring() {
        return this.isMonitoring;
    }

    public final StateFlow<Boolean> isAdminActive() {
        return this.isAdminActive;
    }

    public final void updateToken(String token) {
        Intrinsics.checkNotNullParameter(token, "token");
        this._botToken.setValue(token);
        this.settings.setBotToken(token);
    }

    public final void updateChatId(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        this._chatId.setValue(id);
        this.settings.setChatId(id);
    }

    public final void setMonitoring(boolean active) {
        this._isMonitoring.setValue(Boolean.valueOf(active));
        this.settings.setMonitoringActive(active);
    }

    public final void refreshAdminState() {
        this._isAdminActive.setValue(Boolean.valueOf(this.deviceAdminManager.isAdminActive()));
    }

    public final StateFlow<Boolean> isAuthenticated() {
        return this.isAuthenticated;
    }

    public final boolean authenticate(String password) throws NoSuchAlgorithmException {
        Intrinsics.checkNotNullParameter(password, "password");
        boolean success = this.securityManager.verifyPassword(password);
        if (success) {
            this._isAuthenticated.setValue(true);
        }
        return success;
    }

    public final void lock() {
        this._isAuthenticated.setValue(false);
    }

    /* JADX INFO: compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ%\u0010\u0010\u001a\u0002H\u0011\"\b\b\u0000\u0010\u0011*\u00020\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u00110\u0014H\u0016¢\u0006\u0002\u0010\u0015R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/example/ui/MainViewModel$Factory;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "settings", "Lcom/example/data/repository/SettingsRepository;", "deviceAdminManager", "Lcom/example/utils/DeviceAdminManager;", "securityManager", "Lcom/example/security/ParentSecurityManager;", "notificationHelper", "Lcom/example/utils/NotificationPermissionHelper;", "oemManager", "Lcom/example/managers/OEMCompatibilityManager;", "batteryHelper", "Lcom/example/utils/BatteryOptimizationHelper;", "<init>", "(Lcom/example/data/repository/SettingsRepository;Lcom/example/utils/DeviceAdminManager;Lcom/example/security/ParentSecurityManager;Lcom/example/utils/NotificationPermissionHelper;Lcom/example/managers/OEMCompatibilityManager;Lcom/example/utils/BatteryOptimizationHelper;)V", "create", "T", "Landroidx/lifecycle/ViewModel;", "modelClass", "Ljava/lang/Class;", "(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Factory implements ViewModelProvider.Factory {
        public static final int $stable = 8;
        private final BatteryOptimizationHelper batteryHelper;
        private final DeviceAdminManager deviceAdminManager;
        private final NotificationPermissionHelper notificationHelper;
        private final OEMCompatibilityManager oemManager;
        private final ParentSecurityManager securityManager;
        private final SettingsRepository settings;

        public Factory(SettingsRepository settings, DeviceAdminManager deviceAdminManager, ParentSecurityManager securityManager, NotificationPermissionHelper notificationHelper, OEMCompatibilityManager oemManager, BatteryOptimizationHelper batteryHelper) {
            Intrinsics.checkNotNullParameter(settings, "settings");
            Intrinsics.checkNotNullParameter(deviceAdminManager, "deviceAdminManager");
            Intrinsics.checkNotNullParameter(securityManager, "securityManager");
            Intrinsics.checkNotNullParameter(notificationHelper, "notificationHelper");
            Intrinsics.checkNotNullParameter(oemManager, "oemManager");
            Intrinsics.checkNotNullParameter(batteryHelper, "batteryHelper");
            this.settings = settings;
            this.deviceAdminManager = deviceAdminManager;
            this.securityManager = securityManager;
            this.notificationHelper = notificationHelper;
            this.oemManager = oemManager;
            this.batteryHelper = batteryHelper;
        }

        @Override // androidx.lifecycle.ViewModelProvider.Factory
        public <T extends ViewModel> T create(Class<T> cls, CreationExtras creationExtras) {
            return (T) super.create(cls, creationExtras);
        }

        @Override // androidx.lifecycle.ViewModelProvider.Factory
        public <T extends ViewModel> T create(KClass<T> kClass, CreationExtras creationExtras) {
            return (T) super.create(kClass, creationExtras);
        }

        @Override // androidx.lifecycle.ViewModelProvider.Factory
        public <T extends ViewModel> T create(Class<T> modelClass) {
            Intrinsics.checkNotNullParameter(modelClass, "modelClass");
            return new MainViewModel(this.settings, this.deviceAdminManager, this.securityManager, this.notificationHelper, this.oemManager, this.batteryHelper);
        }
    }
}
