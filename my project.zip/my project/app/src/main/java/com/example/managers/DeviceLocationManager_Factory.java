package com.example.managers;

import android.content.Context;
import dagger.internal.Factory;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes12.dex */
public final class DeviceLocationManager_Factory implements Factory<DeviceLocationManager> {
    private final Provider<Context> contextProvider;

    public DeviceLocationManager_Factory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider
    public DeviceLocationManager get() {
        return newInstance(this.contextProvider.get());
    }

    public static DeviceLocationManager_Factory create(Provider<Context> contextProvider) {
        return new DeviceLocationManager_Factory(contextProvider);
    }

    public static DeviceLocationManager newInstance(Context context) {
        return new DeviceLocationManager(context);
    }
}
